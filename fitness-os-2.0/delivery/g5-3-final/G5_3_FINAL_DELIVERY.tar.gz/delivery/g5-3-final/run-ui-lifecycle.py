"""Supplemental command evidence; leaves frozen main suite and runner unchanged."""
from pathlib import Path
import datetime, hashlib, json, os, re, shutil, subprocess
from zoneinfo import ZoneInfo
app=Path(__file__).resolve().parents[2];out=app/'delivery/g5-3-final';p=json.loads(Path('/tmp/fitness-g53-final-plan.json').read_text());private=Path(p['private']);c=json.loads((private/'local-audit-config.json').read_text())
assert c['productionCredentialsLoaded'] is False and c['apiUrl']=='http://127.0.0.1:59321'
run=out/'runs'/(datetime.datetime.now(ZoneInfo('Asia/Shanghai')).strftime('%Y%m%dT%H%M%S%f')+'-ui-lifecycle');run.mkdir()
files=json.loads((out/'SOURCE_MANIFEST.json').read_text())['files']+[{ 'path':str(f.relative_to(app)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in [Path(__file__).resolve(),out/'browser-session-lifecycle.mjs']]
def hashes():
 result={}
 for f in files:
  value=hashlib.sha256((app/f['path']).read_bytes()).hexdigest();assert value==f['sha256'];result[f['path']]=value
 return result
before=hashes()
for f in files:
 target=run/'source'/f['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(app/f['path'],target)
env={k:os.environ[k] for k in ('PATH','HOME','USER','LANG','LC_ALL','TZ','TMPDIR','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','DOCKER_CONFIG') if k in os.environ}
env.update({'FITNESS_ACL_AUDIT_CONFIG':str(private/'local-audit-config.json'),'FITNESS_SOURCE_MANIFEST':str(out/'SOURCE_MANIFEST.json'),'FITNESS_SUITE_RESULT':str(run/'SUITE_RESULT.json'),'FITNESS_CHILD_RESULTS':str(run/'CHILD_RESULTS.json'),'NEXT_PUBLIC_SUPABASE_URL':c['apiUrl']})
command=['node','delivery/g5-3-final/browser-session-lifecycle.mjs'];record={'mode':'ui-lifecycle','command':command,'cwd':str(app),'started_at':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'source_hashes_before':before,'status':'RUNNING','supplemental_source_hashes_are_included':True}
(run/'COMMAND.json').write_text(json.dumps(record,indent=2)+'\n')
r=subprocess.run(command,cwd=app,env=env,text=True,capture_output=True,timeout=240)
def clean(s):
 for k in ('anonKey','serviceRoleKey','workerToken'):s=s.replace(c[k],'[REDACTED]')
 return re.sub(r'\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+','[REDACTED_JWT]',s)
for name,value in [('stdout.log',r.stdout),('stderr.log',r.stderr)]:(run/name).write_text(clean(value))
after=hashes();record.update({'ended_at':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'exit_code':r.returncode,'source_hashes_after':after,'status':'PASS' if r.returncode==0 and after==before else 'FAIL','driver_exit_code':0 if r.returncode==0 and after==before else 1})
if (run/'SUITE_RESULT.json').exists():
 s=json.loads((run/'SUITE_RESULT.json').read_text());record.update({'checks':s['assertions'],'suite_status':s['status'],'cleanup_status':s['cleanup']['status']})
(run/'COMMAND.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'mode':record['mode'],'status':record['status'],'exit_code':r.returncode,'checks':record.get('checks'),'cleanup_status':record.get('cleanup_status'),'evidence':str(run/'COMMAND.json')}));raise SystemExit(record['driver_exit_code'])
