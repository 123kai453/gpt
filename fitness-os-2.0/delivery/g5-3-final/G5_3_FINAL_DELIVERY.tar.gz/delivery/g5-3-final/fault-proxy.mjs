/** Transparent LOOPBACK test proxy. Faults drop/hold real responses, never fake DB/API success. */
import http from 'node:http';
import { readFileSync, writeFileSync, appendFileSync } from 'node:fs';
const control=process.argv[2], events=process.argv[3];
if (!control?.startsWith('/tmp/fitness-g53-final-') || !events?.startsWith('/tmp/fitness-g53-final-')) throw new Error('Private G5.3 control paths required');
const event=(id,phase,status)=>appendFileSync(events,JSON.stringify({id,phase,status,time:Date.now()})+'\n',{mode:0o600});
const read=()=>{try{return JSON.parse(readFileSync(control,'utf8'));}catch{return {rules:[],release:[]};}};
const delay=(ms)=>new Promise(r=>setTimeout(r,ms));
async function hold(id,res){for(let i=0;i<600&&!res.destroyed;i++){if(read().release?.includes(id))return true;await delay(50);}return false;}
const server=http.createServer(async(req,res)=>{
  const chunks=[];let action=null;
  const rules=read();
  const candidates=(rules.rules??[]).filter(r=>r.remaining>0&&r.method===req.method&&req.url.startsWith(r.path));
  let body=null;
  if(candidates.some(r=>r.rpcAction)){
    for await(const b of req)chunks.push(b);
    body=Buffer.concat(chunks);
  }
  for(const r of candidates){
    if(r.rpcAction){let parsed;try{parsed=JSON.parse(body);}catch{continue;}if(parsed.p_action!==r.rpcAction)continue;}
    r.remaining--;action=r;writeFileSync(control,JSON.stringify(rules),{mode:0o600});break;
  }
  if(action?.action==='hold-before'){
    event(action.id,'held');
    if(!await hold(action.id,res)){event(action.id,'cancelled');return res.destroy();}
  }
  if(res.destroyed)return;
  const upstream=http.request({hostname:'127.0.0.1',port:59321,path:req.url,method:req.method,
    headers:{...req.headers,host:'127.0.0.1:59321'}},(reply)=>{
    if(action?.action==='drop-after'||action?.action==='hold-after'){
      const bytes=[];reply.on('data',b=>bytes.push(b));
      reply.on('end',async()=>{
        event(action.id,'upstream-complete',reply.statusCode);
        if(action.action==='drop-after'){event(action.id,'dropped',reply.statusCode);return res.destroy();}
        event(action.id,'held',reply.statusCode);
        if(!await hold(action.id,res))return res.destroy();
        if(!res.destroyed){res.writeHead(reply.statusCode,reply.headers);res.end(Buffer.concat(bytes));}
      });
    }else{res.writeHead(reply.statusCode,reply.headers);reply.pipe(res);}
  });
  upstream.on('error',()=>{if(!res.headersSent)res.writeHead(502);res.end();});
  res.on('close',()=>upstream.destroy());
  if(body)upstream.end(body);else req.pipe(upstream);
});
server.listen(59421,'127.0.0.1',()=>console.log(JSON.stringify({proxy:'READY',listen:'127.0.0.1:59421',target:'127.0.0.1:59321'})));
