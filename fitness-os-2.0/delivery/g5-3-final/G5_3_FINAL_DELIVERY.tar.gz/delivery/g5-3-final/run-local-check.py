"""Compatibility entry for the owned Next restart; delegates to durable evidence runner."""
from pathlib import Path
import os,sys
script=Path(__file__).with_name('run-command.py')
os.execv(sys.executable,[sys.executable,str(script),*sys.argv[1:]])
