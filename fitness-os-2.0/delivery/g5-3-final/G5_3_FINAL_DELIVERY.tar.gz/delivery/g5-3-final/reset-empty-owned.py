"""Development verification only: remove THIS RUN's empty application fixture.
Preserves all other containers, managed schemas and all source/history files.
Storage buckets are removed through the actual Storage API, never direct DML.
"""
from pathlib import Path
import json
import os
import subprocess
import urllib.request

p=json.loads(Path('/tmp/fitness-g53-final-plan.json').read_text())
c=json.loads((Path(p['private'])/'local-audit-config.json').read_text())
assert c['apiUrl']=='http://127.0.0.1:59321' and c['productionCredentialsLoaded'] is False
env={k:v for k,v in os.environ.items() if not k.startswith(('SUPABASE_','NEXT_PUBLIC_','PG','POSTGRES_','SMTP_'))
 and k not in ('DATABASE_URL','DIRECT_URL','DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH')}
docker=['docker','--host=unix:///var/run/docker.sock']
a=json.loads(subprocess.check_output(docker+['inspect',c['containerId']],env=env,text=True))[0]
assert a['Config']['Labels']['fitness.g53.run']==p['runId'] and a['Id']==c['containerId'] and a['State']['Running']
def sql(q):
 r=subprocess.run(docker+['exec','-i',c['containerId'],'psql','-X','-w','-U','postgres','-d','postgres','-Atq','-v','ON_ERROR_STOP=1'],env=env,input=q,capture_output=True,text=True,timeout=30)
 if r.returncode: raise RuntimeError('Local empty-fixture reset failed: '+r.stderr[-2000:])
 return r.stdout.strip()
assert sql('select (select count(*) from auth.users)+(select count(*) from storage.objects);')=='0'
http=urllib.request.build_opener(urllib.request.ProxyHandler({}))
for bucket in ['private-media','private-media-staging']:
 req=urllib.request.Request(c['apiUrl']+'/storage/v1/bucket/'+bucket,method='DELETE',headers={'apikey':c['serviceRoleKey'],'Authorization':'Bearer '+c['serviceRoleKey']})
 with http.open(req,timeout=8) as response: assert response.status==200
sql("""begin;
drop trigger fitness_media_storage_guard on storage.objects;
drop trigger fitness_media_auth_delete_guard on auth.users;
drop trigger fitness_os_account_defaults on auth.users;
drop policy fitness_media_select_own on storage.objects;
drop schema app_private cascade;
drop table public.profiles,public.user_preferences,public.user_consents,public.sync_metadata,public.user_data_exports,public.user_media,public.account_deletion_jobs cascade;
do $$declare f record;begin for f in select p.oid::regprocedure::text as signature from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname in ('has_current_auth_session','is_current_account_active','consume_account_rate_limit','apply_account_mutation','request_account_deletion','server_media_write','server_export_write','server_deletion_progress','server_media_reliability') loop execute 'drop function '||f.signature||' cascade';end loop;end;$$;
commit;""")
result={'scope':'ONLY_THIS_RUN_EMPTY_LOCAL_FIXTURE','containerId':c['containerId'],'preAuthUsersAndObjects':0,
 'bucketsRemovedThroughStorageAPI':True,'existingInstancesOrProductionTouched':False,'purpose':'fresh apply final unique initial'}
(Path(p['private'])/'final-candidate-local-reset.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'emptyOwnApplicationReset':'PASS','storageProtectionBypassed':False}))
