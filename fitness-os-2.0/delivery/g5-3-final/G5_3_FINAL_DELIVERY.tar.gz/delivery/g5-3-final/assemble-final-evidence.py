"""Assemble truthful final reports from existing executed evidence; does not run tests/SQL."""
from pathlib import Path
import collections,datetime,hashlib,json,subprocess
from zoneinfo import ZoneInfo
app=Path(__file__).resolve().parents[2];out=app/'delivery/g5-3-final';docs=app/'docs';original=Path('/workspace/fitness-os-phase2')
now=datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
def save(name,j): (out/name).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
baseline=load(out/'WORKSPACE_BASELINE.json')
def git(*args):return subprocess.check_output(['git',*args],cwd=original)
actual={name:sha(original/name) if (original/name).is_file() else None for name in baseline['original_files_sha256']}
differences=[name for name,value in actual.items() if value!=baseline['original_files_sha256'][name]]
preservation={'status':'PASS' if not differences else 'FAIL','observed_at':now,'original_root':str(original),'independent_workspace':str(app),'baseline_file_count':len(actual),'changed_or_missing_files':differences,'branch':git('branch','--show-current').decode().strip(),'head':git('rev-parse','HEAD').decode().strip(),'status_identical':git('status','--short','--untracked-files=all').decode()==baseline['status'],'diff_identical':hashlib.sha256(git('diff','--binary')).hexdigest()==baseline['diff_sha256'],'cached_diff_identical':hashlib.sha256(git('diff','--cached','--binary')).hexdigest()==baseline['cached_diff_sha256'],'all_original_file_hashes':actual,'original_workspace_written':False}
assert preservation['status']=='PASS' and preservation['status_identical'] and preservation['diff_identical'] and preservation['cached_diff_identical'] and preservation['branch']==baseline['branch'] and preservation['head']==baseline['head']
save('ORIGINAL_WORKSPACE_PRESERVATION.json',preservation)
manifest=load(out/'SOURCE_MANIFEST.json');core={x['path']:x['sha256'] for x in manifest['files']};assert all(sha(app/name)==value for name,value in core.items())
attempts=[]
for directory in sorted((out/'runs').iterdir()):
 f=directory/'COMMAND.json'
 if not f.exists():continue
 j=load(f);attempts.append((directory,j))
modes=['unit','roles','http','reliability','extra','boundary','browser','ui-lifecycle','typecheck','lint','build'];selected=[];all_checks=[]
for mode in modes:
 choices=[(d,j) for d,j in attempts if j['mode']==mode and j['status']=='PASS' and not j.get('expected_failure_probe')]
 assert choices,'Missing final passing actual command: '+mode
 directory,j=choices[-1];assert j['exit_code']==j['driver_exit_code']==0
 assert all(j['source_hashes_before'].get(k)==v and j['source_hashes_after'].get(k)==v for k,v in core.items())
 suite=load(directory/'SUITE_RESULT.json') if (directory/'SUITE_RESULT.json').exists() else None
 checks=[]
 if suite:
  assert suite['status']==suite['cleanup']['status']=='PASS' and suite['failure'] is None
  assert not suite['cleanup']['errors'] and not suite['cleanup']['residuals']
  for number,item in enumerate(suite['checks'],1):
   label=item if isinstance(item,str) else item['label'];timing=suite.get('timings',[])[number-1] if suite.get('timings') else {}
   checks.append({'id':mode+'-'+str(number).zfill(3),'name':label,'objective':label,'status':'PASS',**{k:v for k,v in timing.items() if k not in ('name','status')}})
 elif mode=='unit':
  unit=load(directory/'UNIT_RESULTS.json');assert unit['numPassedTests']==unit['numTotalTests']==104 and unit['numFailedTests']==0
  for file in unit['testResults']:
   for test in file['assertionResults']:
    checks.append({'id':'unit-'+str(len(checks)+1).zfill(3),'name':test['fullName'],'objective':test['title'],'status':'PASS','file':str(Path(file['name']).relative_to(app)),'duration_ms':test.get('duration'),'timing_scope':'actual Vitest reported duration'})
 all_checks.extend(checks)
 selected.append({'mode':mode,'status':'PASS','command':j['command'],'cwd':str(app),'started_at':j['started_at'],'ended_at':j['ended_at'],'exit_code':0,'driver_exit_code':0,'assertions_or_unit_tests':len(checks),'evidence_directory':str(directory.relative_to(app)),'cleanup_status':suite['cleanup']['status'] if suite else 'NOT_APPLICABLE','source_hashes':j['source_hashes_before'],'checks':checks})
expected=[(d,j) for d,j in attempts if j.get('expected_failure_probe')][-1];negative=load(expected[0]/'SUITE_RESULT.json');assert expected[1]['exit_code']==expected[1]['driver_exit_code']==1 and negative['status']=='FAIL' and negative['cleanup']['status']=='PASS' and negative['failure']['assertion']=='intentional failure with live A/B files and trigger' and not negative['cleanup']['errors'] and not negative['cleanup']['residuals']
save('META_FAILURE_REPORT.json',{'meta_verification':'PASS','underlying_test_result':'FAIL','actual_exit_code':1,'driver_exit_code':1,'evidence_directory':str(expected[0].relative_to(app)),'intentional_assertion':negative['failure'],'cleanup':negative['cleanup'],'not_counted_as_business_pass':True,'pre_failure_setup_assertions':negative['assertions']})
counts={s['mode']:s['assertions_or_unit_tests'] for s in selected if s['checks']};assert sum(counts.values())==759
development=[];chosen={s['evidence_directory'] for s in selected}
for d,j in attempts:
 if str(d.relative_to(app)) in chosen:continue
 development.append({'evidence_directory':str(d.relative_to(app)),'mode':j['mode'],'status':j['status'],'exit_code':j.get('exit_code'),'driver_exit_code':j.get('driver_exit_code'),'expected_failure_probe':j.get('expected_failure_probe',False),'checks_recorded_before_exit':j.get('checks'),'error':j.get('error'),'started_at':j.get('started_at'),'ended_at':j.get('ended_at'),'classification':'service lifecycle, not a business test' if j['mode'] in ('start','proxy') else 'expected failing control probe' if j.get('expected_failure_probe') else 'development/earlier attempt; never substituted for final run'})
save('DEVELOPMENT_ATTEMPTS.json',{'note':'All original attempt records remain in runs/. Earlier failures and sandbox/instrumentation errors have not been overwritten. Service SIGTERM can be OS exit143 and is not a failed business assertion.','attempts':development})
sql=app/'supabase/reviews/20261110000200_account_upload_reliability.final_proposed.sql';patch=out/'nextjs-upload-reliability.final_proposed.patch';catalog=load(out/'LOCAL_CATALOG_SNAPSHOT.json');versions=load(out/'LOCAL_VERSIONS.json');targets=load(out/'PATCH_TARGETS.json')['changes']
result={'generated_at':now,'outcomes':{'local_code_and_function':'PASS','local_security_and_reliability':'PASS_WITH_DOCUMENTED_FAIL_CLOSED_UNCERTAINTY_BOUNDARY','production_migration_and_backup_restore':'PENDING'},'local_gate':'G5.3 LOCAL REMEDIATION PASS','scope':'Independent local official Supabase services plus real Next.js/Chromium; no hosted connection or deployment','candidate':{'path':str(sql.relative_to(app)),'sha256':sha(sql),'initial_candidate_only':True,'not_a_forward_migration':True},'api_patch':{'path':str(patch.relative_to(app)),'sha256':sha(patch),'original_baseline_check_exit_code':load(out/'PATCH_APPLICABILITY.json')['exit_code']},'source_manifest_sha256':sha(out/'SOURCE_MANIFEST.json'),'core_source_file_count':len(core),'supplemental_ui_sources':{k:v for k,v in selected[[s['mode'] for s in selected].index('ui-lifecycle')]['source_hashes'].items() if k not in core},'counts':counts,'final_business_pass':759,'final_business_fail':0,'final_business_blocked':0,'counting_note':'104 offline unit tests plus 655 registered live integration/browser assertions. Setup/observer assertions included; not 759 distinct business scenarios. Repeat labels have distinct IDs. Forced failure excluded.','expected_failure_control':{'status':'FAIL_AS_INTENDED','actual_exit_code':1,'cleanup':'PASS','failure_count':1,'setup_checks':negative['assertions']},'selected_executions':selected,'versions':versions,'catalog_evidence':'delivery/g5-3-final/LOCAL_CATALOG_SNAPSHOT.json','cleanup':{'auth_users':catalog['auth_users'],'storage_objects':catalog['storage_objects'],'physical_storage':load(out/'PHYSICAL_STORAGE_CHECK.json'),'shutdown':load(out/'LOCAL_SHUTDOWN.json')['status'],'original_workspace':preservation['status']},'production_access':False,'production_migration':'NOT_RUN','hosted_current_state':'PENDING_NEW_AUTHORIZED_READ_ONLY_CHECK','complete_backup_and_restore':'PENDING','development_attempts':'delivery/g5-3-final/DEVELOPMENT_ATTEMPTS.json'}
result['outcomes']['local_security_and_reliability']='PASS'
result['local_security_qualification']='Only the documented tested contract; unknown I/O without terminal proof stays fail-closed/manual'
save('TEST_RESULTS.json',result)
safe=lambda s:str(s).replace('|','\\|').replace('\n',' ')
command_table='| 类别 | 本轮结果 | 数量 | 真实退出码 | 开始时间（北京时间） | 结束时间 | 证据 |\n|---|---|---:|---:|---|---|---|\n'
for s in selected:command_table+='| '+s['mode']+' | PASS | '+str(s['assertions_or_unit_tests'] or '检查命令')+' | 0 | '+s['started_at']+' | '+s['ended_at']+' | `'+s['evidence_directory']+'/COMMAND.json` |\n'
def references(mode,ids):
 s=next(x for x in selected if x['mode']==mode);return '；'.join('`'+s['checks'][i-1]['id']+'` '+s['checks'][i-1]['name'] for i in ids)
mapping='''| 原缺陷 | 本轮直接反例/恢复证据 | 修复位置 |
|---|---|---|
| 上传重试不幂等 | '''+references('reliability',[10,12,13,14,15,18,19,20,21])+''' | `media-reliability.ts` reserve/submitUpload；SQL owner/request UNIQUE、原始摘要冲突和墓碑 |
| pending 无恢复入口 | '''+references('reliability',[25,27,29,35,39,44,46,48,49])+''' | 租约、重试和数据库游标；worker；服务端维护入口 |
| 替换后没有真实摘要验证 | '''+references('reliability',[50,51,56,58,61,63])+''' | snapshot/validateBytes/verifiedDownload；Storage 触发器 |
| 文件丢失仍然 ready | '''+references('reliability',[67,70,72,75,78,79])+''' | 两次可信不存在确认，unavailable/failed 分流和恢复验证 |
'''
environment='''本轮独立目录：`'''+str(app)+'''`。原仓库：`/workspace/fitness-os-phase2`，原分支 `'''+baseline['branch']+'''`，原 HEAD `'''+baseline['head']+'''`。原有 447 个文件、15 项 tracked 修改、143 个 untracked 文件及暂存区状态已保护，最终逐文件哈希、branch/HEAD/status/diff/cached diff 均一致。独立副本基准 commit 为 `cf75281e39fec4db623b163619db2fec5e14da12`，本轮修改未发布。

Cloud 环境 ID：`ccarenv_b64_Y2NhcmVudl85N2MzZGJlZTljZDQ4MTkxOGQzMjk1NTBiNWY1YWQ0YQ`。系统 `'''+versions['os']+'''`；Node `'''+versions['node']+'''`；PostgreSQL `'''+catalog['server_version']+'''`；Auth 2.197.0；Storage 1.88.0；PostgREST 16.5；Docker `'''+versions['docker']+'''`；Next '''+versions['packages']['next']+'''；TypeScript '''+versions['packages']['typescript']+'''；Vitest '''+versions['packages']['vitest']+'''；Sharp '''+versions['packages']['sharp']+'''；Playwright '''+versions['packages']['@playwright/test']+'''；'''+versions['chromium']+'''。

使用已缓存官方镜像手动编排真实 PostgreSQL/Auth/Storage/REST/Kong/Mailpit，并未假称使用完整 Supabase CLI（本机无 CLI/psql）。数据库在本轮独立容器内，以 Unix socket 执行测试 SQL；API 59321、故障代理 59421、Next 3453、Mailpit 59324 均只绑定 127.0.0.1。两用户为 `user-a@example.invalid`、`user-b@example.invalid`，每套重新生成 UUID/测试密码，真实本地 Auth 登录，无外部 SMTP。

所有数据库操作核对容器 ID/名称/标签；SDK 操作额外核对 Kong 身份和绑定；子进程仅继承必要环境，不加载原 `.env.local`、生产密码或生产服务密钥。已有依赖独立复制使用，未安装软件或升级依赖。浏览器和 Node 子进程须在批准的执行器环境运行：沙箱中曾出现子进程 code0 但 stdout 为空，原记录保留；最终构建未跳过类型检查。一次 exec-server transport disconnected 后通过环境状态和真实 pwd 恢复确认，未重建或发布环境。
'''
boundary='''**边界必须保留：**租约到期不等于 Storage 请求已终止。新 I/O 凭证记录未知写入，只有匹配真实已提交对象的 operation marker，或可信服务端取得原请求确定的终止拒绝，才解除屏障；此后仍需读取真实字节验证。未知结果不能靠超时或手工清空字段自动当作成功。无终止回应、无已提交标记的进程崩溃，可能持续阻止删除，需要后续受控人工核实；这是主动保守的可用性限制，不是已经证明跨数据库与 Storage 的分布式事务。

可信 RPC 的信任主体是服务端凭据，不是普通用户的 auth.uid()。保留的旧 `createVerifiedMedia`/`server_media_write(begin/ready)` 是兼容性服务端工具，当前公开上传 API 不调用它；它不是新的可靠性上传入口，不能把它描述成已具备新 I/O 对账协议。拥有服务端/数据库管理凭据的越权操作不在普通客户端隔离保证内。生产接入前应再次核对没有新增公开路径调用旧工具。

Storage 1.88.0 的对象 version、user_metadata 和 version='1' 回滚式 canUpload 探测已经实测；不能推断托管版完全相同。托管版本、触发器兼容性、当前 Schema、正式 worker 调度及生产凭据配置均待独立授权验证。
'''
backup='''本轮未连接生产项目 `lrehapbujedrwpxzhqrt`。历史“未初始化”、Auth/Storage 为零只是历史证据，不能代表当前云端。未执行 db push、dry-run、迁移、部署、Dashboard/生产配置更改或真实邮件。

Windows public-only 归档、SHA256/pg_restore --list 仅有历史用户及报告证据，原文件位于用户私密 Windows 目录，本地不可访问，不能重新计算哈希或宣称恢复通过；9 个 TOC 条目不是完整数据库备份。当前仓库未找到 `hosted_backup_metadata_readonly_v2.sql` 和完整原始 v2 元数据 JSON，现有差异报告不能替代原件。尚需 app_private、迁移 ledger、Auth 自定义触发器/依赖、Storage 桶/策略及真实二进制（如当前存在）、角色权限/默认 ACL、完整对象清单和独立恢复演练。禁止将本轮本地候选的事务回滚演练当作生产备份恢复演练。

新 SQL 是**唯一完整初始候选**，不是前向升级脚本。原迁移、ACL 候选和旧 G5.3 初始 SQL 均保留；不得串行执行这些 initial。只有新只读云端快照证明目标为空、备份/恢复证据齐全并获得用户明确批准后，才能另行审阅执行；若已经初始化，必须按实际对象另外设计前向迁移，不能覆盖已应用历史。本轮生产门禁 PENDING。
'''
evidence='# G5.3 独立执行证据（最终本地修订）\n\n生成时间：'+now+'\n\n本地代码与功能 PASS；本地安全与可靠性 PASS（限下述实测合同）；生产迁移与备份恢复 PENDING。\n\n'+environment+'\n## 结果及计数口径\n\n本轮最终选择的固定源码检查：**759 项通过，0 项业务失败，0 项关键测试阻塞**。其中 104 项离线单元测试、655 项真实集成/浏览器登记断言；包含建夹具、观察数据的断言，不能称为 759 个互不重叠的业务场景。额外故意失败控制：1 个真实失败、退出码1，之前8个夹具断言通过，清理 PASS，未加入业务通过数。开发阶段失败和服务启动/停止记录全部保留在 `DEVELOPMENT_ATTEMPTS.json` 与 runs/。\n\n'+command_table+'\n## 实际命令\n\n'
for s in selected:evidence+='- `'+ ' '.join(s['command'])+'`；cwd `'+str(app)+'`；退出码0；证据 `'+s['evidence_directory']+'`。\n'
evidence+='\n所有主要测试通过 `python3 delivery/g5-3-final/run-command.py <mode>` 以必要白名单环境启动；补充 UI 使用 `python3 delivery/g5-3-final/run-ui-lifecycle.py`。每次命令及子命令退出码、开始/结束、stdout/stderr、SQL输入摘要、失败堆栈与清理均落盘。主套件有124个实际源码/配置/SQL SHA，执行前后与 SOURCE_MANIFEST 比较；补充 UI 再加2个自身源文件，执行前后核对。最终 SQL SHA256 `'+sha(sql)+'`；API补丁SHA256 `'+sha(patch)+'`；SOURCE_MANIFEST SHA256 `'+sha(out/'SOURCE_MANIFEST.json')+'`。源代码快照在各最终 run/source/，不是仅复制配置里预设哈希。\n\n断言时间仅为记录结果的真实时间点，未虚构逐例耗时；`timing_scope=assertion_result_recorded`，HTTP/子进程另有实际起止时间；Vitest 保留实际 duration。\n\n## 四项原始缺陷映射\n\n'+mapping+'\n## 故障注入与核实方式\n\n- 并发：真实 Promise 并发 HTTP、两个真实 worker 进程竞争；观察规范媒体 ID、任务次数、Storage 对象数和租约。\n- 进程崩溃：核对 PID、/proc 启动时间、完整命令行和 cwd 后 SIGKILL 实际 Next；确认 processing 持久化、等待真实30秒租约到期、新 worker 恢复、旧 token 拒绝。\n- 网络：实际本机代理在提交后丢弃 Storage/DB 应答，阻断回应及制造500；实际停止再启动本轮 Storage 容器。事件见 NETWORK_FAULT_EVIDENCE.jsonl；不是切换一个模拟布尔值。\n- 内容：服务端读取真实 Storage 响应字节计算 SHA256，规范化前后分别摘要、真正 Sharp 解码；受控修改仅当前合成对象实际 backend/version 文件，在元数据不变时仍检测损坏。\n- 丢失与不可用：可信 Admin 下载两次明确 not-found 且对象引用稳定才判断缺失；网络、5xx、超时、模糊500保留摘要/引用并设 unavailable/返回503；恢复后重新实际读取和验证。\n- TOCTOU：真实替换对象后校验 id/version/current reference/验证时间；下载只返回已验证的内存快照。不能宣称永远提供最新版本或阻止数据库管理员直接篡改。\n- 孤儿：12个排序实际对象，前11个A删除受故障影响时B后续孤儿仍被处理，B登记媒体不变；随后A恢复清理。对象ID/version、owner、canonical key、删除凭证和重试共同限界。\n- 删除：真实 setLocalStorageDeleteFault；503保留Auth和任务，后台重试；以 Admin404/user_not_found、真实两个桶二进制0、所有所属SQL行0及B保持证明，不仅看HTTP200。\n- 失败控制：故意断言失败前实际创建A/B、文件、故障触发器、函数和序列；原始FAIL及堆栈保留、退出1，清理独立逐项成功，残留列表为空，Next实际退出。\n\n'+boundary+'\n## 离线与集成的区别\n\n104个单元测试包括原有66个、已有G5.3/可信状态28个和新增10个基础设施/资源断言，其中有 fetch 模拟，仅证明分类/边界；不冒充 Supabase 集成。7张public表都有非空A/B行及双向RLS检查，7张private表逐角色检查。权限要求42501/正确HTTP，隐藏Schema严格匹配406/PGRST106；另以实际SQLXX000/HTTP500、缺失RPC和错误参数验证不会误算权限PASS。\n\n## 每项测试名称、目标与实际结果\n\n以下名称从本次最终原始结果自动提取。通用建夹具断言保留，不删减；ID用于区分重复名称。\n'
for s in selected:
 if not s['checks']:continue
 evidence+='\n### '+s['mode']+' — '+str(len(s['checks']))+'\n\n| ID | 实际测试名称（亦为断言目标） | 结果 |\n|---|---|---|\n'
 for x in s['checks']:evidence+='| '+x['id']+' | '+safe(x['name'])+' | PASS |\n'
evidence+='\n## 生产与备份限制\n\n'+backup
(docs/'G5_3_INDEPENDENT_EVIDENCE.md').write_text(evidence)
remediation='# G5.3 完整修复报告\n\n生成时间：'+now+'\n\n**G5.3 LOCAL REMEDIATION PASS；生产迁移与备份恢复 PENDING。** 所有实际修改位于独立副本，原项目未覆盖。\n\n'+environment+'''\n## 本轮发现与修复

| 优先级 | 发现 | 实际修复 | 证据 |
|---|---|---|---|
| 高 | 仅用租约过期判断旧上传已结束，迟到请求可能与删除交叉 | 独立 I/O operation 凭证，原请求终止/匹配提交标记才结算；取消及 Auth 删除独立阻止未知 I/O，即使任务状态已failed | boundary 36、reliability104 |
| 高 | 删除失败不能仅依赖HTTP，自动重试需真实密码授权边界 | 密码复验后发放私有 cleanup authorization；绑定owner/job/1h/max3/租约/退避，后台复用清理流程，独立核实Auth404；用户普通删除RPC不构成后台Auth删除授权 | extra235–268、UI lifecycle |
| 中 | 只扫前10条/进程内游标可能饿死后续任务 | 5种任务数据库UUID游标、revision CAS、11读10处理、跨进程持久化、单项失败继续、尾页归零重扫 | extra大量任务、两个worker |
| 中 | 孤儿和staging清理失败可能丢失重试机会 | 对象ID/version/key绑定claim、失败退避；metadata已消失但claim尚在仍继续真实删除确认；staging由ready扫描重试 | extra staging/orphan实际故障 |
| 中 | SDK先完整缓存恶意大对象、解码并发无界 | Storage GET流式5MiB上限、12s超时、2并发解码槽且无无界队列、16M像素/单帧/实际解码/5s处理超时；处理繁忙/超时返回可重试503 | 离线10与真实内容反例 |
| 中 | 大写UUID可能被错误拒绝 | 请求UUID规范为小写，仍以owner+key+原始字节SHA决定幂等，不允许不同原字节复用 | extra实际UUID/同像素不同编码 |
| 高（证据可信度） | 任意error算权限通过、漏错误/退出码、清理半途失败却PASS | 精确HTTP/SQLSTATE/错误类型、真实内部错误反例；失败阶段/堆栈、实际命令/退出、测试前后源哈希、清理后才能PASS；故意失败验证 | negative meta、角色及extra |
| 中（测试隔离） | child继承全部环境、杀进程身份不足、Docker guard只查一次 | 最小环境白名单、逐次容器核对、进程PID/start_ticks/完整命令/cwd、超时和退出等待 | 实测所有命令与清理 |

原始四项缺陷未用扩大权限解决：保留owner+request唯一记录和墓碑、真实字节读回摘要、双worker租约、unavailable分流和文件消失后的安全失败状态。旧G5.3已有通过的合同重新全部运行；未直接搬用历史PASS。

## 状态与数据权威

- pending：可信意图已持久化；processing：租约工作阶段。未知I/O可能在租约失效后仍保留processing/phase uncertain，不能称为有效worker仍存活；该差异明确记入任务日志。
- ready：服务端真实字节/格式/尺寸/摘要校验，DB对象id/version和引用CAS完成。
- unavailable：暂时不能核实，媒体保留原摘要/对象引用；不是把上传任务伪装成永久failed。
- failed：确定丢失、损坏、变更或普通任务重试耗尽；新的上传使用新UUID。
- deleting：删除屏障建立；普通authenticated不能设置任何可信状态。
- io_pending：与租约独立的未定I/O事实；服务端提交凭证不等于文件内容验证。未知写入不启动第二个worker写入。

## 数据库和兼容性

新完整候选共14表（public7/private7）、15个固定空search_path的SECURITY DEFINER函数、7个触发器、9个RLS策略、2个私有5MiB桶。相对旧G5.3新增 `media_maintenance_state`、`account_cleanup_authorizations`；上传job增加I/O凭证字段及uncertain phase/event；orphan claim增加重试信息。完整差异在 `g53-to-final-sql.review.diff`。

service_role仍无应用表ALL或直接DML；仅4个窄服务端RPC。authenticated只保留自己数据SELECT、同意记录4列INSERT和原有5个用户RPC；没有后台修复/可信finalizer授权。所有函数PUBLIC和anon EXECUTE都关闭。未全局收紧共享Schema默认ACL，当前新建对象逐项REVOKE/GRANT；未来新迁移仍必须审阅每个对象ACL。原始8函数中7个业务实现保持原样，清除头像函数保留临时unavailable时不清空的必要改动。相对旧G5.3共有10个函数实现原样保留。Auth Admin API正常，服务端删除不用直接表DML授权。

锁审查：服务端操作先owner profile、再media/job；Storage触发器相同owner屏障；Auth删除不可避免先锁Auth行再取profile，并由独立触发器拒绝未清理对象/任务/I/O。实际并发、两worker、迟到写和回滚通过；没有宣称对所有负载/托管内部锁顺序作过穷尽证明。冲突事务失败须重试，不可忽略错误继续删除。

唯一候选带自身BEGIN/COMMIT和postgres creator/preexisting-object fail-fast；已经初始化时重复执行明确拒绝。实际本地注入最后COMMIT前division-by-zero，全部应用DDL/桶回滚，管理字段签名保持，再从空fixture应用相同候选通过；未修改任何候选字节。中途注入输入文件是测试专用，不得作为迁移执行。
'''+boundary+'''\n## 功能回归

资料、偏好CAS、同步server时间、同意记录追加/撤回历史、导出、头像、上传/下载、删除请求/密码复验/重试、真实登录与注销均保留。浏览器43路由、深浅主题、手机导航、资料保存、同意记录实际两次追加、上传下载、退出清空IndexedDB及两步账户删除实测。PWA缓存未缓存私人API/账户/Auth/Storage路径；sw仅升级缓存版本，无视觉重构。导出completed含义是服务端完成流式内容生成，不等于用户磁盘保存成功。健康训练等后续功能没有被删除，也没有在本轮假称已完成全部业务实现。

## 修改文件、哈希与补丁

API/测试/配置补丁32文件，加独立SQL候选共33个目标文件，完整字节副本在 delivery/g5-3-final/files/，基准和新SHA在PATCH_TARGETS.json。新API补丁对原始实际工作区 `git apply --check` 退出0，未应用回原项目。原历史SQL、ACL、旧SQL/patch/report均保留，原证据报告还另存于originals/。

| 文件 | SHA256 |
|---|---|
| 新完整SQL | `'''+sha(sql)+'''` |
| 新API补丁 | `'''+sha(patch)+'''` |
| 最终测试源码清单 | `'''+sha(out/'SOURCE_MANIFEST.json')+'''` |

## 给用户的11个直接回答

1. 原先主要风险是重试/恢复不完整、文件变动后的可信状态，以及测试把异常当权限拒绝、删除没有完整核验和清理证据不足；这轮还识别了租约过期不能证明旧请求结束。
2. 已实际修复并在独立副本执行了上表各项，生成新的SQL、API补丁和完整测试证据。
3. 未解决生产端当前状态、完整备份恢复、托管Storage版本兼容和未知I/O无终止凭据时的人工核实；没有权限直接替用户在生产修复，保守阻止删除比误报成功安全。
4. 本地实测合同下普通客户端不能伪造可信状态，文件在服务端实际验证；不能据此保证尚未部署或重新审查的生产系统绝对安全。
5. A/B真实本地用户的表、文件、会话、删除和孤儿清理双向隔离通过。
6. 幂等、并发、实际损坏摘要、恢复与临时停机通过；未知写入结果会停住等待证据，不会假称自动恢复完成。
7. 已实测删除失败不提前删Auth，后台成功后核实Auth404、两个桶真实文件0和SQL级联0；无法确认旧请求终止时不会报告删除成功。
8. 原有接口与本轮覆盖的UI回归通过，未删除功能或进行无关视觉改造；原工作区447文件哈希和Git状态不变。
9. 最终759项登记检查/单元测试通过、0业务失败、0关键阻塞；另1个故意失败控制保持FAIL/退出1/清理PASS，开发阶段失败完整保留，不混入最终通过数。
10. 生产重新只读审查、管理元数据原件、完整备份/恢复、当前已应用历史和托管兼容性均未完成。
11. 先审阅本轮交付；用户另行授权后再做生产只读核实和备份补齐。若已初始化先设计前向迁移，仍须明确批准才能迁移。

## 下一步门禁

'''+backup+'\n停止于G5.3；没有进入G5.4/G5.5/PHASE2.1 BRAND STUDIO或PHASE3。\n'
(docs/'G5_3_FULL_REMEDIATION_REPORT.md').write_text(remediation)
security='# G5.3 安全回归报告\n\n生成时间：'+now+'\n\n**本地安全 PASS；生产 PENDING。**\n\n'+environment+'''\n## 实际权限矩阵

| 对象/操作 | anon | authenticated | service_role |
|---|---|---|---|
| public 7表SELECT | 拒绝 | 仅真实会话自己的行 | 无直接SELECT授权 |
| 同意记录 | 拒绝 | 仅4列INSERT自己的新记录；不能UPDATE/DELETE历史 | 无直接DML |
| 资料/偏好、同步 | 拒绝 | 原有窄用户RPC/CAS；不能伪造服务器时间 | 无表ALL |
| 媒体/导出/删除job可信状态 | 拒绝 | 无直接DML/管理RPC执行 | 4个窄RPC维护；真实验证在服务端 |
| app_private 7表 | 无schema usage | 无schema usage | 无直接schema/table授权 |
| 私有Storage桶 | 不可访问 | 仅own verified ready的SELECT；无直接上传/更新/删除策略 | 服务端Storage操作仍经过DB触发器屏障 |
| 维护HTTP | 拒绝 | Cookie/JWT均不等同维护凭据 | 另用服务端维护token；服务key也不进浏览器 |

所有14表RLS启用，15函数owner=postgres、SECURITY DEFINER、search_path固定空。catalog逐函数完整签名/定义/EXECUTE、表ACL、列ACL、RLS、策略表达式、触发器、索引和约束均在LOCAL_CATALOG_SNAPSHOT.json。真实JWT的anon/authenticated/service_role通过REST验证；仅在表计数/内部Schema观察时用明确标注的postgres observer。没有把管理员直接查询当RLS测试。

7张public表为双方各自非空夹具，分别观察本人与他人、未登录、直接写被拒及数据哈希不变；7张private表三角色均实际42501。普通用户不能ready/completed、改删除job、伪造owner或服务器时间；user_consents追加且历史不能改删。隐藏Schema406/PGRST106只是曝光控制，不能冒充SQLSTATE42501。实际内部异常XX000/HTTP500和不存在RPC不会被分类为权限拒绝。

## 函数执行权限（本轮目录实际核验）

| 完整函数 | owner / SECURITY DEFINER / search_path | PUBLIC | anon | authenticated | service_role |
|---|---|---|---|---|---|
'''
for f in catalog['functions']:
 security+='| `'+f['schema']+'.'+f['name']+'('+f['signature']+')` | postgres / true / empty | '+('有' if f['public_execute'] else '无')+' | '+('有' if f['anon_execute'] else '无')+' | '+('有' if f['authenticated_execute'] else '无')+' | '+('有' if f['service_execute'] else '无')+' |\n'
security+='''\n## Auth、Storage和删除的实际证明

Storage并非只依赖行删除：真实文件后端有正数基准，实际Storage API操作后独立扫描/mnt的owner/两个桶二进制并计数。A的读取/修改/删除B以及B对A都拒绝，禁止操作后真实摘要保持。A的12个孤儿/失败分页不会删B登记对象；仅B自身无登记孤儿才可按明确对象身份清理。

实际删除故障下API503，Auth/任务/凭据/文件均仍在，Auth SQL触发器42501/media_cleanup_required阻止提前删除。GoTrue对该DB异常包装为实际AuthRetryableFetchError/HTTP500；测试同时独立验证原始SQLSTATE，不把一般500算权限通过。故障解除后只靠已密码复验的私有授权后台重试成功，Admin404/user_not_found、SQL级联、真实二进制0，B不变；单纯用户request_account_deletion不能授权后台删Auth。界面注销和密码确认删除、IndexedDB清理也真实通过。

期末Auth用户0、Storage objects0、13张用户相关表0；5行全局维护游标是设计数据，不是用户残留。私有桶保留2个配置，均private/5MiB；实际文件0；测试临时函数/触发器/序列无残留。六个新容器停止、卷保留；其他容器停止阶段身份/状态一致。

## 防资源滥用与凭据

实际图片解码、最大5MiB、16M像素、单帧、PNG/JPEG/WebP；原始MIME与实际格式不符拒绝。流式限制不信任Content-Length，限制真实chunk总字节；2并发槽、无无界解码排队、读/解码超时。部分资源边界用明确标识的离线fetch模拟验证，真实大/损坏/动画图片也经API反例测试。没有宣称进行过生产容量/全负载CPU压力测试。

浏览器静态产物未发现本轮服务端key或维护token，日志按已知值/JWT/Bearer/连接串脱敏。原生产变量不传入测试进程；新本地凭据只在0600私密配置，不进入补丁、源码快照或交付清单。未发送真实邮件，内部Mailpit最终0。

'''+boundary+'\n## 结果来源\n\n'+command_table+'\n原始逐例名称、命令、时间、退出码和清理见 G5_3_INDEPENDENT_EVIDENCE.md / TEST_RESULTS.json。强制失败控制为真实FAIL，整体未伪报PASS。\n\n'+backup
(docs/'G5_3_SECURITY_REGRESSION_REPORT.md').write_text(security)
reliability='# G5.3 上传可靠性最终报告\n\n生成时间：'+now+'\n\n**本地可靠性 PASS（以下合同与边界）；生产 PENDING。**\n\n'+mapping+'''\n## 生命周期闭环

1. 服务器解码原始文件，算原始SHA，生成规范化PNG和第二摘要；owner+UUID幂等键保留原始字节冲突与删除墓碑。
2. 保留唯一意图/任务，30秒租约和token；同用户owner锁阻止重复reserve，两个worker只能一个有效领取，旧token无法提交。
3. 每次真实Storage写入先登记独立I/O凭证。固定canonical key、upsert=false；真实终止回应/已提交marker才结算。文件放私有staging，不能直接浏览器上传。
4. 实际回读和解码字节，核验摘要/大小/MIME/id/version/当前引用，然后通过窄服务RPC发布ready。DB失败保留真实文件，丢回应通过回读既有事实找回，不复制新对象。
5. 后台用5个持久化游标扫due、ready/unavailable、orphan、media_delete、account_cleanup；每批11取10、CAS推进，重启继续，错误单项隔离，尾部重扫。
6. 真实丢失/内容变更标记failed，临时故障unavailable保留证明并复验恢复；下载只返回当次验证的内存字节。
7. 处理staging失败、孤儿claim和丢失删除应答；对象身份、owner、状态屏障、有限上传重试、后台退避共同约束。媒体删除与账户删除均阻止未定I/O。

## 故障结果

| 场景 | 实际结果/证据 |
|---|---|
| 顺序/并发相同key、不同原字节、A/B同key | 单一媒体/对象；不同原字节409；用户范围隔离 |
| Storage提交后丢HTTP应答，DB提交后丢应答 | 实际代理丢回应，稳定身份找回，不产生重复对象 |
| 两worker、真实Next崩溃、租约过期、旧token | durable processing被恢复，未过期不抢占，旧token42501 |
| 失败重试和退避 | 上传最多3次并审计；2/4秒等待；不会紧循环耗尽 |
| >10个pending/ready，重启worker | 持久化数据库游标继续处理后页并检测后页实际损坏 |
| PNG/JPEG/WebP、截断/超大/像素限额、动画、MIME | 真实API反例拒绝，合法文件成功；动画夹具实际确认2帧 |
| 替换大小/MIME/内容、下载间TOCTOU、绕元数据改真实文件 | 不沿用旧ready，真实SHA检测并拒绝损坏内容 |
| 真停Storage、模糊500/网络错误 | unavailable/503，头像引用保留，恢复后重新验证正常 |
| 实际移除ready文件 | 不再保持可下载ready，提供新key重新上传路径 |
| staging/孤儿删除失败，后页B孤儿，A/B登记媒体 | 后台重试成功，后页不饥饿，合法B文件不受影响 |
| Storage删除失败后的账户后台重试 | 不提前删Auth；故障消失后文件0、Admin404、SQL级联0 |
| 过期迟到上传、无任何可见文件但I/O未知 | 删除409/503；Auth独立42501拦截；只有原请求真正终止才解除 |
| 故意失败、资源清理 | 真实FAIL/exit1/堆栈，独立清理PASS且无残留 |
| 完整SQL最后COMMIT前失败 | 全部应用DDL/桶回滚；管理字段不变；重新应用同一候选通过 |

worker单次日志现在明确ONE_BOUNDED_BATCH，不再将一次最多10项描述成全量完成。失败单项有数据库reason/claim/next_attempt，扫描继续；常驻worker有请求超时、重试退避、SIGTERM/INT退出，不会把所有系统故障吞掉当成功。旧API参数nextCursor保留兼容但不作为进度真源，返回cursorAuthority=database。

'''+boundary+'\n## 数量和环境\n\n'+command_table+'\n'+environment+'\n## 残留和后续\n\n真实期末文件与Auth均0，六个新容器停止但卷保留，原工作区哈希和Git未改变。恢复过程的人工边界、托管兼容性、生产worker监控/告警与完整备份恢复仍须后续授权阶段处理；本轮未提供“零故障、所有对象永不丢失”的承诺。\n\n'+backup
(docs/'G5_3_RELIABILITY_FINAL_REPORT.md').write_text(reliability)
(out/'REMAINING_RISKS.md').write_text('# G5.3 剩余限制与生产门禁\n\n'+now+'\n\n'+boundary+'\n'+backup+'''\n- 公开上传实际入口必须继续走新journal协议；未来若复用旧服务端compat工具，要另行设计与验证，不能继承本轮可靠性结论。
- 2并发/5MiB限制是单Node进程边界，尚无生产多实例容量压力证明；正式worker调度/告警/人工处置工具尚未部署。
- 本地期末回滚演练只证明新候选事务行为，不证明Windows备份可恢复或生产数据兼容。
- 所有本轮测试已在固定源码下完成，没有关键本地测试BLOCKED；生产的未知项必须维持PENDING，不能由本地PASS替代。
''')
(out/'README.md').write_text('''# G5.3 最终本地修订交付

先读 docs/G5_3_FULL_REMEDIATION_REPORT.md 和 G5_3_INDEPENDENT_EVIDENCE.md。

- TEST_RESULTS.json：最终选择的真实执行、逐例名称/结果、计数与源哈希。
- runs/：所有开发和最终原始命令、日志、子命令、清理与源快照；旧失败保留。
- META_FAILURE_REPORT.json：故意失败必须保持FAIL/exit1，清理PASS。
- SOURCE_MANIFEST.json：实际被测源码124文件；额外UI2文件单独记录。
- PATCH_TARGETS.json、files/：33个目标（32代码/测试/配置和1新SQL）完整字节副本。
- nextjs-upload-reliability.final_proposed.patch：对实际原工作区检查可应用；未替原项目应用。
- g53-to-final-sql.review.diff：审查差异，不是前向迁移。
- FINAL_MIGRATION_ROLLBACK_REPORT.json：仅本轮本地空fixture的原子/重复执行验证。
- FORCED_ROLLBACK_TEST_INPUT.sql：故意失败输入，绝不可部署。
- LOCAL_CATALOG_SNAPSHOT/LOCAL_VERSIONS/PHYSICAL_STORAGE_CHECK/MAIL_CHECK/LOCAL_SHUTDOWN.json：实际目录/环境/真实文件/邮件和停止证据。
- ORIGINAL_WORKSPACE_PRESERVATION.json：原447文件及Git基准不变。
- ARTIFACT_MANIFEST.json、SHA256SUMS：交付完整性。私密配置、node_modules、.next及本地key不在归档。

只在Linux /proc + Docker Unix socket的独立本地条件可重跑；临时0600配置需自行重新生成，不包含生产密钥。未提供一键生产执行指令。正式初始候选不可与旧initial连续执行，托管状态需重新核实。
''')
print(json.dumps({'final_checks':counts,'business_pass':759,'business_fail':0,'expected_failure_control':'FAIL exit1 with cleanup PASS','original_447_files_unchanged':True,'reports_written':4},ensure_ascii=False))
