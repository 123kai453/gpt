import { chromium, expect } from '@playwright/test';
import { createClient } from '@supabase/supabase-js';
import { randomUUID,createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import sharp from 'sharp';
import { assertLocalAclAuditTarget } from '../helpers/local-acl-observer.mjs';
import { beginEvidence, cleanupFixtures, registerSecret, auditedFetch } from '../helpers/g53-evidence.mjs';
await assertLocalAclAuditTarget();
const cfg=JSON.parse(readFileSync(process.env.FITNESS_ACL_AUDIT_CONFIG,'utf8'));
const admin=createClient(cfg.apiUrl,cfg.serviceRoleKey,{auth:{persistSession:false,autoRefreshToken:false},global:{fetch:auditedFetch}});
const checks=[],actors=[],audit=beginEvidence('real Chromium UI and PWA',checks);let browser;let current='initialization';
const check=(condition,label)=>{current=label;if(!condition)throw new Error(label);checks.push({label,status:'PASS'});};
try{
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const publicContext=await browser.newContext({baseURL:cfg.appUrl});const page=await publicContext.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('/');await expect(page.getByRole('heading',{name:/突破极限，\s*持续进化。/})).toBeVisible();check(true,'desktop Dashboard existing UI renders');
 await page.getByRole('button',{name:'切换主题',exact:true}).click();await expect(page.locator('html')).toHaveAttribute('data-theme','light');check(true,'light theme UI remains functional');
 await page.setViewportSize({width:390,height:844});await page.goto('/modules');await expect(page.getByRole('navigation',{name:'手机导航'})).toBeVisible();check(true,'mobile navigation remains available');
 const slugs=[...readFileSync('src/lib/navigation.ts','utf8').matchAll(/slug: "([^"]+)"/g)].map(m=>m[1]);
 check(slugs.length===43,'all 43 registered modules retained');for(const slug of slugs){const r=await page.request.get('/'+slug);check(r.status()===200,'existing module /'+slug+' reachable');}
 for(const email of ['user-a@example.invalid','user-b@example.invalid']){
  const password='BrowserFinal!'+randomUUID()+'Aa9';registerSecret(password);const c=await admin.auth.admin.createUser({email,password,email_confirm:true});if(c.error)throw c.error;
  actors.push({id:c.data.user.id,email,password});
 }
 async function login(actor){const context=await browser.newContext({baseURL:cfg.appUrl}),p=await context.newPage();p.on('pageerror',e=>errors.push(e.message));await p.goto('/auth/sign-in?next=%2Faccount%2Fprivacy');const form=p.locator('.auth-form:visible');await form.getByRole('textbox',{name:'邮箱地址',exact:true}).fill(actor.email);await form.locator('input[name="password"]').fill(actor.password);await form.getByRole('button',{name:'登录账户',exact:true}).click();await expect(p).toHaveURL(/account\/privacy$/);check(true,'real browser password login '+actor.email);return {context,page:p};}
 const a=await login(actors[0]),b=await login(actors[1]);
 await a.page.goto('/account/profile');await a.page.getByTestId('profile-display-name').fill('Browser final A');await a.page.getByRole('button',{name:'保存个人资料',exact:true}).click();await expect.poll(async()=>{const r=await a.page.request.get('/api/account/snapshot');return (await r.json()).profile.display_name;}).toBe('Browser final A');check(true,'profile UI actually saves to real database');
 await a.page.goto('/account/privacy');await a.page.evaluate(async()=>{await Promise.race([navigator.serviceWorker.ready,new Promise((_,reject)=>setTimeout(()=>reject(new Error('ServiceWorker not ready')),15000))]);});const consent=a.page.getByRole('checkbox',{name:/可选使用分析/});await consent.check();await expect(consent).toBeChecked();await expect(consent).toBeEnabled();await consent.uncheck();await expect(consent).not.toBeChecked();await expect(consent).toBeEnabled();const consentData=await(await a.page.request.get('/api/account/consents')).json();check(consentData.consents.filter(x=>x.scope==='analytics').length===2,'real UI consent appends two actual immutable records');check(consentData.current.analytics.granted===false,'real UI withdrawal actually persists in database');check(true,'consent UI append and withdrawal stay usable');
 const png=await sharp({create:{width:4,height:4,channels:3,background:'green'}}).png().toBuffer();
 await a.page.getByLabel('选择私人图片',{exact:true}).setInputFiles({name:'synthetic.png',mimeType:'image/png',buffer:png});const response=a.page.waitForResponse(r=>r.url().endsWith('/api/account/media')&&r.request().method()==='POST');await a.page.getByRole('button',{name:'上传私人图片',exact:true}).click();const uploaded=await response;check(uploaded.status()===201,'real UI upload uses idempotency key and succeeds');const media=(await uploaded.json()).media;await expect(a.page.getByText(media.id,{exact:true})).toBeVisible();
 const download=await a.page.request.get('/api/account/media/'+media.id);check(download.status()===200,'real browser authenticated image download');check(createHash('sha256').update(await download.body()).digest('hex')===media.content_sha256,'browser download bytes match actual server digest');check(download.headers()['cache-control'].includes('no-store'),'private browser image response is not cacheable');
 check((await b.page.request.get('/api/account/media/'+media.id)).status()===404,'browser B cannot read A image');
 const exported=await a.page.request.post('/api/account/export',{headers:{Origin:cfg.appUrl},data:{format:'json'}});check(exported.status()===200,'browser authenticated export remains functional');check((await exported.json()).account.id===actors[0].id,'browser export belongs only to A');
 const cacheUrls=await a.page.evaluate(async()=>{if(!('caches'in window))return [];const urls=[];for(const name of await caches.keys())for(const req of await(await caches.open(name)).keys())urls.push(req.url);return urls;});check(cacheUrls.every(x=>!/^\/(api|auth|account|storage|supabase)(\/|$)/.test(new URL(x).pathname)),'browser PWA cache contains no private API/page/storage path');
 check(errors.length===0,'no unhandled browser console/page errors during current UI flows');
 await publicContext.close();await a.context.close();await b.context.close();
}catch(error){audit.fail(error,current);}finally{
 if(browser)await browser.close();await audit.finish(()=>cleanupFixtures(admin,actors,{stopServer:true}));
}
