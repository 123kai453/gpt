import "server-only";
import sharp from "sharp";
import { createHash } from "node:crypto";
import { RequestError } from "@/lib/security/request";

export const MAX_VERIFIED_BYTES = 5 * 1024 * 1024;
export const MAX_IMAGE_PIXELS = 16_000_000;
export function digestBytes(bytes: Uint8Array) {
  return createHash("sha256").update(bytes).digest("hex");
}
let imageJobs = 0;
/** No unbounded decode queue; reject excess work rather than buffering more pixels. */
export async function withImageBudget<T>(work: () => Promise<T>): Promise<T> {
  if (imageJobs >= 2) throw new RequestError(503, "IMAGE_PROCESSOR_BUSY", "图片服务繁忙，请稍后重试。");
  imageJobs++;
  try { return await work(); } finally { imageJobs--; }
}
export async function normalizeImage(input: Uint8Array, declaredMime: string) {
  return withImageBudget(() => decodeImage(input, declaredMime));
}
async function decodeImage(input: Uint8Array, declaredMime: string) {
  if (input.byteLength < 1 || input.byteLength > MAX_VERIFIED_BYTES) {
    throw new RequestError(413, "FILE_TOO_LARGE", "图片必须大于零且不超过 5 MiB。");
  }
  try {
    const options = { failOn: "warning" as const, limitInputPixels: MAX_IMAGE_PIXELS, animated: false };
    const metadata = await sharp(input, options).timeout({ seconds: 5 }).metadata();
    const allowed: Record<string, string> = { png: "image/png", jpeg: "image/jpeg", webp: "image/webp" };
    if (!metadata.format || allowed[metadata.format] !== declaredMime || !metadata.width || !metadata.height
      || metadata.width * metadata.height > MAX_IMAGE_PIXELS || (metadata.pages ?? 1) !== 1) {
      throw new Error("Unsupported image");
    }
    // Decode and re-encode all pixels; strip metadata and normalize to a single static PNG.
    const bytes = await sharp(input, options).rotate().png().timeout({ seconds: 5 }).toBuffer();
    if (bytes.byteLength > MAX_VERIFIED_BYTES) throw new RequestError(413, "FILE_TOO_LARGE", "规范化图片超过 5 MiB。");
    return { bytes, mime: "image/png" as const, extension: "png" as const, digest: digestBytes(bytes) };
  } catch (error) {
    if (error instanceof RequestError) throw error;
    if (error instanceof Error && /timeout|timed out/i.test(error.message)) throw new RequestError(503, "IMAGE_PROCESSING_TIMEOUT", "图片处理超时，请稍后重试。");
    throw new RequestError(415, "INVALID_IMAGE", "图片无法安全解码，或类型、大小、帧数不符合要求。");
  }
}
