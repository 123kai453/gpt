export type LocalAclTable =
  | 'profiles'
  | 'user_preferences'
  | 'user_consents'
  | 'sync_metadata'
  | 'user_data_exports'
  | 'user_media'
  | 'account_deletion_jobs'
  | 'account_mutation_receipts'
  | 'rate_limit_counters';

export function isLocalAclAuditMode(): boolean;
export function assertLocalAclAuditTarget(): Promise<void>;
export function observeUserRows(table: LocalAclTable, userId: string): Promise<Record<string, unknown>[]>;
