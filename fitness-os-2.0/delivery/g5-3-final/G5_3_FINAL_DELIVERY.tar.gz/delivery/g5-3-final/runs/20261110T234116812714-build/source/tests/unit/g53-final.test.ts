import { afterEach, describe, expect, it, vi } from "vitest";
import { boundedAdminFetch } from "../../src/lib/account/storage-fetch";
import { withImageBudget, normalizeImage } from "../../src/lib/account/verified-image";
import { strictDenied, registerSecret, redact, errorRecord, runChild } from "../helpers/g53-evidence.mjs";
import sharp from "sharp";
afterEach(()=>vi.unstubAllGlobals());
describe("G5.3 final offline infrastructure and resource checks, NOT Supabase integration",()=>{
 it("accepts only the explicit authenticated permission HTTP/SQLSTATE pair",()=>{
  expect(()=>strictDenied({status:403,error:{code:'42501'}},'real expected denial')).not.toThrow();
  for(const result of [{status:500,error:{code:'XX000'}},{status:404,error:{code:'PGRST202'}},{status:400,error:{code:'22023'}},{status:401,error:{code:'42501'}},{status:0,error:{code:'NETWORK'}},{status:200,error:null}])expect(()=>strictDenied(result,'must not pass')).toThrow();
 });
 it("records error name/message/stack/phase and removes registered tokens",()=>{
  const secret='test-only-maintenance-sensitive-value';registerSecret(secret);const e=errorRecord(new Error('failure '+secret),'cleanup');
  expect(e.name).toBe('Error');expect(e.phase).toBe('cleanup');expect(e.stack).toContain('[REDACTED]');expect(JSON.stringify(e)).not.toContain(secret);
  expect(redact('postgres://user:password@localhost/db')).toContain('[REDACTED_CONNECTION]');
 });
 it("captures child spawn failure instead of hanging",async()=>{
  await expect(runChild('fitness-definitely-missing-executable',[],{timeout:200})).rejects.toThrow('failed to start');
 });
 it("keeps operational JSON intact while persisting only redacted child output",async()=>{
  const nonce='test-only-internal-nonce';registerSecret(nonce);
  const result=await runChild('node',['-e','console.log(JSON.stringify({lease_token:"'+nonce+'"}))']);
  expect(JSON.parse(result.stdout).lease_token).toBe(nonce);
 });
 it("times out and waits for a real local child process",async()=>{
  await expect(runChild('node',['-e','setInterval(()=>{},1000)'],{timeout:100})).rejects.toThrow('timed out');
 });
 it("bounds stored object by declared length before reading a full body",async()=>{
  vi.stubGlobal('fetch',vi.fn(async()=>new Response(new Uint8Array([1]),{headers:{'Content-Length':String(5242881)}})));
  expect((await boundedAdminFetch('http://127.0.0.1/storage/v1/object/a')).status).toBe(413);
 });
 it("bounds chunked response bytes even when Content-Length is absent",async()=>{
  vi.stubGlobal('fetch',vi.fn(async()=>new Response(new ReadableStream({start(c){c.enqueue(new Uint8Array(5242880));c.enqueue(new Uint8Array([1]));c.close();}}))));
  expect((await boundedAdminFetch('http://127.0.0.1/storage/v1/object/a')).status).toBe(413);
 });
 it("preserves exact in-limit real response bytes and MIME",async()=>{
  vi.stubGlobal('fetch',vi.fn(async()=>new Response(new Uint8Array([1,2,3]),{headers:{'Content-Type':'image/png'}})));
  const r=await boundedAdminFetch('http://127.0.0.1/storage/v1/object/a');expect([...new Uint8Array(await r.arrayBuffer())]).toEqual([1,2,3]);expect(r.headers.get('Content-Type')).toBe('image/png');
 });
 it("does not turn an internal server failure into a missing-object answer",async()=>{
  vi.stubGlobal('fetch',vi.fn(async()=>new Response('unavailable',{status:500})));
  expect((await boundedAdminFetch('http://127.0.0.1/storage/v1/object/a')).status).toBe(500);
 });
 it("limits simultaneous decode work and releases slots after rejection",async()=>{
  let release!:()=>void;const held=new Promise<void>(r=>release=r);const a=withImageBudget(()=>held),b=withImageBudget(()=>held);
  await expect(withImageBudget(async()=>0)).rejects.toMatchObject({status:503,code:'IMAGE_PROCESSOR_BUSY'});release();await Promise.all([a,b]);
  await expect(withImageBudget(async()=>{throw new Error('synthetic decode failure');})).rejects.toThrow('synthetic decode failure');
  const bytes=await sharp({create:{width:2,height:2,channels:3,background:'red'}}).png().toBuffer();expect((await normalizeImage(bytes,'image/png')).digest).toMatch(/^[0-9a-f]{64}$/);
 });
});
