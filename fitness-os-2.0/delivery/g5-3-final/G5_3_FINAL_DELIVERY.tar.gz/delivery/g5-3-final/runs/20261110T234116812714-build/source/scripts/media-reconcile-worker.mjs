/** Trusted maintenance process; sweep positions are persisted by the server in SQL. */
const raw = process.env.MEDIA_WORKER_APP_ORIGIN;
const token = process.env.FITNESS_MEDIA_WORKER_TOKEN;
if (!raw || !token || token.length < 32) throw new Error('Secure worker origin/token configuration required.');
const origin = new URL(raw);
if ((origin.protocol !== 'https:' && !(origin.protocol === 'http:' && ['127.0.0.1','localhost','[::1]'].includes(origin.hostname)))
 || origin.username || origin.password || origin.search || origin.hash || !['/',''].includes(origin.pathname)) throw new Error('Invalid worker origin.');
let failures = 0, stopping = false, wake;
const controller = new AbortController();
for (const signal of ['SIGTERM','SIGINT']) process.once(signal, () => { stopping = true; controller.abort(); wake?.(); });
do {
  const started = new Date().toISOString();
  try {
    const r = await fetch(origin.origin + '/api/internal/media/reconcile', { method:'POST', redirect:'error',
      headers:{ Authorization:'Bearer '+token, 'Content-Type':'application/json' },body:'{}',signal:AbortSignal.any([controller.signal,AbortSignal.timeout(60000)]) });
    if (!r.ok) throw new Error('Worker request failed');
    const data = await r.json(); failures=0;
    console.log(JSON.stringify({status:'PASS',scope:'ONE_BOUNDED_BATCH',cursorAuthority:data.cursorAuthority,started,ended:new Date().toISOString(),
      completed:data.completed,verified:data.verified,invalidated:data.invalidated,orphansCleaned:data.orphansCleaned,accountsCleaned:data.accountsCleaned,deferred:data.deferred}));
  } catch {
    if (!stopping) { failures++;if(process.argv.includes('--once'))process.exitCode=1;console.error(JSON.stringify({status:'DEFERRED',code:'WORKER_UNAVAILABLE',started,ended:new Date().toISOString()})); }
  }
  if (process.argv.includes('--once') || stopping) break;
  await new Promise((r)=>{ const timer=setTimeout(()=>{wake=undefined;r();},Math.min(300000,30000*2**Math.min(failures,4)));wake=()=>{clearTimeout(timer);r();}; });
} while (!stopping);
