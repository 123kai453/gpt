import { accountError, dbError, enforceRateLimit, requireAccount, listWindow } from "@/lib/account/server";
import { MAX_IMAGE_BYTES } from "@/lib/account/files";
import { submitUpload } from "@/lib/account/media-reliability";
import { trustedClient } from "@/lib/account/trusted-state";
import { privateJson, RequestError, requireTrustedOrigin } from "@/lib/security/request";
export const dynamic = "force-dynamic";
export const runtime = "nodejs";

async function boundedForm(request: Request): Promise<FormData> {
  const max = MAX_IMAGE_BYTES + 32_768;
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("multipart/form-data;")) throw new RequestError(415, "MULTIPART_REQUIRED", "请以表单形式上传图片。");
  if (Number(request.headers.get("content-length")) > max) throw new RequestError(413, "FILE_TOO_LARGE", "图片大小不能超过 5 MB。");
  const reader = request.body?.getReader();
  if (!reader) throw new RequestError(400, "FILE_REQUIRED", "请选择图片。");
  const chunks: Uint8Array[] = []; let size = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read(); if (done) break;
      size += value.byteLength;
      if (size > max) { await reader.cancel(); throw new RequestError(413, "FILE_TOO_LARGE", "图片大小不能超过 5 MB。"); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(size); let offset=0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  try {
    return await new Response(bytes, { headers: { "Content-Type": request.headers.get("content-type")! } }).formData();
  } catch { throw new RequestError(400, "INVALID_FORM", "上传表单无效。"); }
}
export async function GET(request: Request) {
  try {
    const { client, user } = await requireAccount();
    const { offset, limit } = listWindow(request);
    const { data, error } = await client.from("user_media").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).order("id").range(offset, offset + limit);
    if (error) throw dbError(error);
    return privateJson({ media: data?.slice(0, limit) ?? [], nextOffset: data && data.length > limit ? offset + limit : null });
  } catch (error) { return accountError(error); }
}
export async function POST(request: Request) {
  try {
    requireTrustedOrigin(request);
    const { client, user } = await requireAccount();
    await enforceRateLimit(client, "media");
    const form = await boundedForm(request);
    const entries = [...form.entries()];
    if (entries.length !== 1 || entries[0][0] !== "file" || !(entries[0][1] instanceof File)) throw new RequestError(400, "FILE_REQUIRED", "每次请选择一张图片。");
    const file = entries[0][1];
    if (file.size <= 0 || file.size > MAX_IMAGE_BYTES) throw new RequestError(413, "FILE_TOO_LARGE", "图片必须大于 0 字节且不超过 5 MB。");
    const bytes = new Uint8Array(await file.arrayBuffer());
    const result = await submitUpload(trustedClient(), user.id, request.headers.get("Idempotency-Key") ?? "", bytes, file.type);
    return privateJson({ media: result.media, pending: !result.completed }, result.completed ? result.reused ? 200 : 201 : 202);
  } catch (error) { return accountError(error); }
}
