import "server-only";

const MAX_OBJECT_BYTES = 5 * 1024 * 1024;
/** Bound bytes while streaming, before the SDK can buffer a complete malicious object. */
export async function boundedAdminFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const signal = init?.signal ? AbortSignal.any([init.signal, AbortSignal.timeout(12000)]) : AbortSignal.timeout(12000);
  const response = await fetch(input, { ...init, signal });
  const url = new URL(input instanceof Request ? input.url : String(input));
  const method = init?.method ?? (input instanceof Request ? input.method : "GET");
  if (method !== "GET" || !url.pathname.startsWith("/storage/v1/object/") || !response.ok || !response.body) return response;
  const tooLarge = () => Response.json({ statusCode: "413", error: "PayloadTooLarge", message: "Stored object exceeds verification limit" }, { status: 413 });
  if (Number(response.headers.get("content-length")) > MAX_OBJECT_BYTES) { await response.body.cancel(); return tooLarge(); }
  const reader = response.body.getReader(); const chunks: Uint8Array[] = []; let size = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read(); if (done) break;
      size += value.byteLength;
      if (size > MAX_OBJECT_BYTES) { await reader.cancel(); return tooLarge(); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(size); let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  return new Response(bytes, { status: response.status, headers: response.headers });
}
