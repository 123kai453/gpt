export function strictDenied(result: unknown,label: string,options?: {kind?: string;codes?: string[];messages?: string[];httpStatus?: number}): void;
export function registerSecret(secret: string): void;
export function redact(value: unknown): string;
export function errorRecord(error: unknown,phase: string): {phase:string;name:string;message:string;code:string;stack:string;observed_at:string};
export function runChild(command:string,args:string[],options?:Record<string,unknown>): Promise<{code:number|null;signal:string|null;timedOut:boolean;stdout:string;stderr:string}>;
