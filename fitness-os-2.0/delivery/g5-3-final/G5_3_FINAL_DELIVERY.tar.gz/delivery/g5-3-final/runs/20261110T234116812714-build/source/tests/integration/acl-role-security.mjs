/**
 * Fresh local-stack candidate ACL audit. Never a hosted migration/test runner.
 * Requires the root-created FITNESS_ACL_AUDIT_CONFIG marker and local SDK keys.
 * Only user-a@example.invalid and user-b@example.invalid are fixture identities.
 * No token, password, signed URL, SQL row or config is logged or written to results.
 */
import { createHash, randomUUID } from 'node:crypto';
import { execFile } from 'node:child_process';
import { readFileSync, realpathSync, writeFileSync, renameSync } from 'node:fs';
import { isAbsolute, join, relative, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createClient } from '@supabase/supabase-js';
import { assertLocalAclAuditTarget, observeUserRows } from '../helpers/local-acl-observer.mjs';

const ENVIRONMENT = 'isolated-local-supabase-acl-audit';
const CANDIDATE_SHA256 = 'eb76a2d07f7780c8850431bd207865af33a31a1e6c9dda388b1cd12ff173968b';
const DOCKER_HOST = 'unix:///var/run/docker.sock';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const TABLES = ['profiles', 'user_preferences', 'user_consents', 'sync_metadata', 'user_media', 'user_data_exports', 'account_deletion_jobs'];
const PUBLIC_FUNCTIONS = ['has_current_auth_session', 'is_current_account_active', 'consume_account_rate_limit', 'apply_account_mutation', 'request_account_deletion'];
const PRIVATE_FUNCTIONS = ['guard_owned_resource', 'clear_removed_avatar', 'create_account_defaults'];
const BUCKET = 'private-media';
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/l9sAAAAASUVORK5CYII=', 'base64');
const pngHash = createHash('sha256').update(PNG).digest('hex');
const checks = [];
const observations = [];
const accounts = [];
const storagePaths = new Set();
const startedAt = new Date().toISOString();
let config;
let admin;
let anonymous;
let apiOrigin;
let resultDirectory;
let currentLabel = 'Validate the root-created isolated target marker';

class AuditFailure extends Error {
  constructor(label) { super(label); this.label = label; }
}
function check(condition, label) {
  if (!condition) { checks.push({ label, status: 'FAIL' }); throw new AuditFailure(label); }
  checks.push({ label, status: 'PASS' });
}
function data(response, label) {
  currentLabel = label;
  check(!response.error, label);
  return response.data;
}
function aclDenied(response, label) {
  currentLabel = label;
  const error = response.error;
  const http = Number(response.status ?? error?.status ?? error?.statusCode);
  const hidden = ['PGRST202', 'PGRST205', 'PGRST106'].includes(String(error?.code));
  check(Boolean(error) && http < 500 && (error.code === '42501' || [401, 403].includes(http) || (http === 404 && hidden) || (error.code === 'PGRST106' && http === 406)), label);
}
function inputRejected(response, label, allowedCodes = ['22023', '23514', 'PGRST202']) {
  currentLabel = label;
  check(Boolean(response.error) && allowedCodes.includes(String(response.error.code)) && Number(response.status) < 500, label);
}
function noRows(response, label) {
  const rows = data(response, `${label}: query succeeds`);
  check(Array.isArray(rows) && rows.length === 0, label);
}
function storageDenied(response, label, extraStatuses = []) {
  currentLabel = label;
  const status = Number(response.error?.statusCode ?? response.error?.status ?? response.status);
  check(Boolean(response.error) && [400, 401, 403, 404, ...extraStatuses].includes(status), label);
}
function trackedPath(actor, suffix = `${randomUUID()}.png`) {
  if (!UUID.test(actor.id)) throw new AuditFailure('Fixture UUID is invalid');
  const value = `${actor.id}/${suffix}`;
  storagePaths.add(value);
  return value;
}
function safeDockerEnv() {
  const env = { ...process.env, DOCKER_HOST };
  for (const name of ['DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH', 'SUPABASE_SECRET_KEY', 'SUPABASE_SERVICE_ROLE_KEY', 'SUPABASE_ACCESS_TOKEN', 'PGPASSWORD', 'PGPASSFILE']) delete env[name];
  return env;
}

// This is a fixed catalog-only SELECT: no actor/user input is interpolated.
const CATALOG_SQL = `begin read only;
set local search_path = pg_catalog;
select jsonb_build_object(
 'functions', (select jsonb_agg(to_jsonb(f)) from (
  select n.nspname,p.proname,oidvectortypes(p.proargtypes) as argument_types,
   pg_get_userbyid(p.proowner) as owner,p.prosecdef,p.proconfig,
   exists(select 1 from aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a where a.grantee=0 and a.privilege_type='EXECUTE') as public_execute,
   has_function_privilege('anon',p.oid,'EXECUTE') as anon_execute,
   has_function_privilege('authenticated',p.oid,'EXECUTE') as authenticated_execute,
   has_function_privilege('service_role',p.oid,'EXECUTE') as service_execute
  from pg_proc p join pg_namespace n on n.oid=p.pronamespace
  where (n.nspname='public' and p.proname in ('has_current_auth_session','is_current_account_active','consume_account_rate_limit','apply_account_mutation','request_account_deletion'))
     or (n.nspname='app_private' and p.proname in ('guard_owned_resource','clear_removed_avatar','create_account_defaults'))
  order by n.nspname,p.proname
 ) f),
 'tables', (select jsonb_agg(to_jsonb(t)) from (
  select c.relname,n.nspname,pg_get_userbyid(c.relowner) as owner,c.relrowsecurity,
   has_table_privilege('service_role',c.oid,'SELECT,INSERT,UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER,MAINTAIN') as service_any_privilege
  from pg_class c join pg_namespace n on n.oid=c.relnamespace
  where c.relkind='r' and ((n.nspname='public' and c.relname in ('profiles','user_preferences','user_consents','sync_metadata','user_media','user_data_exports','account_deletion_jobs'))
    or (n.nspname='app_private' and c.relname in ('account_mutation_receipts','rate_limit_counters')))
  order by n.nspname,c.relname
 ) t),
 'private_schema', (select jsonb_build_object('anon',has_schema_privilege('anon',n.oid,'USAGE'),'authenticated',has_schema_privilege('authenticated',n.oid,'USAGE'),'service_role',has_schema_privilege('service_role',n.oid,'USAGE')) from pg_namespace n where n.nspname='app_private')
)::text;
commit;
`;

async function readCatalog() {
  await assertLocalAclAuditTarget();
  return await new Promise((resolve, reject) => {
    const child = execFile('docker', ['--host', DOCKER_HOST, 'exec', '-i', '--env', 'PGOPTIONS=-c default_transaction_read_only=on -c statement_timeout=10000 -c search_path=pg_catalog', config.containerId, 'psql', '-X', '-v', 'ON_ERROR_STOP=1', '-At', '-q', '-U', 'postgres', '-d', 'postgres'], {
      env: safeDockerEnv(), timeout: 20_000, maxBuffer: 2_097_152, encoding: 'utf8',
    }, (error, stdout) => {
      if (error) { reject(new AuditFailure('Pinned local read-only catalog query succeeds')); return; }
      try { resolve(JSON.parse(stdout.trim())); } catch { reject(new AuditFailure('Pinned local catalog returns valid metadata JSON')); }
    });
    child.stdin.on('error', () => reject(new AuditFailure('Read-only catalog input is accepted')));
    child.stdin.end(CATALOG_SQL);
  });
}

async function localFetch(input, init = {}) {
  const target = new URL(typeof input === 'string' || input instanceof URL ? input : input.url);
  if (target.origin !== apiOrigin || target.username || target.password) throw new AuditFailure('SDK traffic remains on the exact local API origin');
  return await fetch(input, { ...init, redirect: 'error', signal: init.signal ? AbortSignal.any([init.signal, AbortSignal.timeout(20_000)]) : AbortSignal.timeout(20_000) });
}
let anonKey;
function client(key = anonKey, accessToken) {
  return createClient(apiOrigin, key, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
    global: { fetch: localFetch, ...(accessToken ? { headers: { Authorization: `Bearer ${accessToken}` } } : {}) },
  });
}
async function makeAccount(label) {
  currentLabel = `Create only the approved isolated fixture ${label}`;
  const email = { A: 'user-a@example.invalid', B: 'user-b@example.invalid' }[label];
  if (!email) throw new AuditFailure('Fixture identities are limited to the approved local pair');
  const password = `AclOnly!${randomUUID()}aA9`;
  const created = data(await admin.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { display_name: `ACL ${label}`, role: 'service_role' } }), `Auth Admin creates local fixture ${label} without email`);
  check(UUID.test(created.user?.id ?? ''), `Fixture ${label} has a valid Auth UUID`);
  const actor = { label, id: created.user.id, password, email, deviceId: randomUUID(), client: client() };
  accounts.push(actor);
  actor.session = data(await actor.client.auth.signInWithPassword({ email, password }), `Fixture ${label} obtains a real GoTrue password session`).session;
  const claims = JSON.parse(Buffer.from(actor.session.access_token.split('.')[1], 'base64url').toString());
  check(claims.sub === actor.id && claims.role === 'authenticated' && UUID.test(claims.session_id ?? ''), `Fixture ${label} JWT identity is authenticated with its own live session`);
  return actor;
}
function mutation(actor, entity, version, patch, mutationId = randomUUID()) {
  return actor.client.rpc('apply_account_mutation', { p_mutation_id: mutationId, p_device_id: actor.deviceId, p_entity: entity, p_base_version: version, p_patch: patch });
}
async function samePng(response, label) {
  const blob = data(response, `${label}: request succeeds`);
  const bytes = Buffer.from(await blob.arrayBuffer());
  check(createHash('sha256').update(bytes).digest('hex') === pngHash, label);
}
function signedTarget(raw) {
  if (typeof raw !== 'string') throw new AuditFailure('Storage returns a usable signed URL');
  const target = new URL(raw);
  if (target.origin !== apiOrigin || !target.pathname.startsWith('/storage/v1/object/sign/private-media/')) throw new AuditFailure('Signed URL remains on the isolated Storage origin');
  return target;
}
async function fetchSigned(target) {
  return await localFetch(target, { headers: { 'Cache-Control': 'no-cache' }, cache: 'no-store' });
}
async function checkRawPng(response, label) {
  check(response.status === 200, `${label}: HTTP 200`);
  check(createHash('sha256').update(Buffer.from(await response.arrayBuffer())).digest('hex') === pngHash, label);
}

async function run() {
  // Mandatory target/labels/permissions gate precedes every fixture creation.
  await assertLocalAclAuditTarget();
  config = JSON.parse(readFileSync(process.env.FITNESS_ACL_AUDIT_CONFIG, 'utf8'));
  const projectRoot = fileURLToPath(new URL('../../', import.meta.url));
  const allowedRunRoot = realpathSync(join(projectRoot, '.private-test-artifacts', 'acl-local'));
  resultDirectory = realpathSync(config.runDirectory);
  const relativeRun = relative(allowedRunRoot, resultDirectory);
  check(isAbsolute(resultDirectory) && relativeRun && !relativeRun.startsWith(`..${sep}`) && relativeRun !== '..' && !isAbsolute(relativeRun), 'Result destination is inside the guarded local audit directory');
  check(config.environment === ENVIRONMENT && config.dockerHost === DOCKER_HOST, 'Configuration selects only the fresh local audit environment');
  apiOrigin = new URL(process.env.NEXT_PUBLIC_SUPABASE_URL).origin;
  anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  check(Boolean(anonKey && serviceKey), 'Local SDK keys are injected without reading or logging secret files');
  check(createHash('sha256').update(readFileSync(join(projectRoot, 'supabase/reviews/20261103000100_account_foundation.acl_proposed.sql'))).digest('hex') === CANDIDATE_SHA256, 'Candidate file hash matches this audit');
  admin = client(serviceKey);
  anonymous = client();

  currentLabel = 'Read candidate function and table ACLs through the pinned local catalog';
  const catalog = await readCatalog();
  check(Array.isArray(catalog.functions) && catalog.functions.length === 8, 'Exactly eight candidate functions are present');
  const expectedArgs = { has_current_auth_session: '', is_current_account_active: '', consume_account_rate_limit: 'text', apply_account_mutation: 'uuid, uuid, text, bigint, jsonb', request_account_deletion: '', guard_owned_resource: '', clear_removed_avatar: '', create_account_defaults: '' };
  for (const row of catalog.functions) {
    const label = Object.hasOwn(expectedArgs, row.proname) ? row.proname : 'unexpected function';
    check(Object.hasOwn(expectedArgs, row.proname) && row.argument_types === expectedArgs[row.proname], `Catalog ${label}: exact signature`);
    check(row.owner === 'postgres', `Catalog ${label}: owner is postgres`);
    check(row.prosecdef === true, `Catalog ${label}: SECURITY DEFINER is enabled`);
    check(Array.isArray(row.proconfig) && row.proconfig.some((x) => /^search_path=(?:""|)$/.test(x)), `Catalog ${label}: search_path is fixed empty`);
    check(row.public_execute === false, `Catalog ${label}: PUBLIC EXECUTE is absent`);
    check(row.anon_execute === false, `Catalog ${label}: anon effective EXECUTE is absent`);
    check(row.service_execute === false, `Catalog ${label}: service_role effective EXECUTE is absent`);
    const publicFunction = PUBLIC_FUNCTIONS.includes(row.proname);
    check(row.nspname === (publicFunction ? 'public' : 'app_private') && row.authenticated_execute === publicFunction, `Catalog ${label}: authenticated EXECUTE matches the intended boundary`);
  }
  check(Array.isArray(catalog.tables) && catalog.tables.length === 9, 'Exactly nine candidate application tables are present');
  for (const row of catalog.tables) {
    check(row.owner === 'postgres' && row.relrowsecurity === true, `Catalog ${row.relname}: owner and RLS match`);
    check(row.service_any_privilege === false, `Catalog ${row.relname}: service_role has no effective direct application privilege`);
  }
  check(catalog.private_schema?.anon === false && catalog.private_schema?.authenticated === false && catalog.private_schema?.service_role === false, 'Private schema USAGE is absent for all three API roles');

  const a = await makeAccount('A');
  const b = await makeAccount('B');
  check(a.id !== b.id && a.session.access_token !== b.session.access_token, 'A and B are distinct real Auth identities');
  for (const actor of [a, b]) {
    const profile = data(await actor.client.from('profiles').select('*').single(), `${actor.label} reads its own profile`);
    const preferences = data(await actor.client.from('user_preferences').select('*').single(), `${actor.label} reads its own preferences`);
    check(profile.id === actor.id && preferences.user_id === actor.id, `${actor.label} owns the defaults created by the Auth trigger`);
    check(data(await actor.client.rpc('has_current_auth_session'), `${actor.label} calls the session helper`) === true, `${actor.label} has a live backing session`);
    check(data(await actor.client.rpc('is_current_account_active'), `${actor.label} calls the account helper`) === true, `${actor.label} account is active`);
  }
  const changed = data(await mutation(a, 'profile', 1, { display_name: 'ACL A changed' }), 'A saves its own profile through the RPC');
  check(changed.status === 'applied' && changed.record.id === a.id && changed.version === 2, 'A profile CAS applies only to A');
  const prefs = data(await mutation(b, 'preferences', 1, { theme: 'light' }), 'B saves its own preferences through the RPC');
  check(prefs.status === 'applied' && prefs.record.user_id === b.id && prefs.version === 2, 'B preference CAS applies only to B');
  noRows(await b.client.from('profiles').select('*').eq('id', a.id), 'B cannot read A profile');
  noRows(await b.client.from('user_preferences').select('*').eq('user_id', a.id), 'B cannot read A preferences');
  inputRejected(await mutation(a, 'profile', 2, { user_id: b.id }), 'RPC rejects an ownership field');
  inputRejected(await mutation(b, 'profile', 1, { avatar_path: `${a.id}/foreign.png` }), 'RPC rejects another user avatar path');
  inputRejected(await a.client.rpc('apply_account_mutation', { p_mutation_id: randomUUID(), p_device_id: a.deviceId, p_entity: 'profile', p_base_version: 2, p_patch: { display_name: 'wrong owner parameter' }, p_user_id: b.id }), 'RPC signature rejects an external owner parameter');
  const bCounters = JSON.stringify((await observeUserRows('rate_limit_counters', b.id)).sort((x, y) => String(x.action).localeCompare(String(y.action))));
  check(data(await a.client.rpc('consume_account_rate_limit', { p_action: 'consent' }), 'A invokes its own rate counter').allowed === true, 'Rate-limit RPC permits a valid user action');
  check(JSON.stringify((await observeUserRows('rate_limit_counters', b.id)).sort((x, y) => String(x.action).localeCompare(String(y.action)))) === bCounters, 'A rate-limit RPC does not modify B counters');
  inputRejected(await a.client.rpc('consume_account_rate_limit', { p_action: 'arbitrary_unlimited' }), 'Rate-limit RPC rejects an arbitrary action');

  const commonName = `${randomUUID()}.png`;
  const aPath = trackedPath(a, commonName);
  const bPath = trackedPath(b, commonName);
  const mediaA = data(await a.client.from('user_media').insert({ object_path: aPath, mime_type: 'image/png', size_bytes: PNG.byteLength }).select().single(), 'A creates owned media metadata');
  data(await a.client.storage.from(BUCKET).upload(aPath, PNG, { contentType: 'image/png', cacheControl: '0' }), 'A uploads its own real private PNG');
  data(await a.client.from('user_media').update({ status: 'ready' }).eq('id', mediaA.id).select().single(), 'A marks its own media ready');
  data(await b.client.storage.from(BUCKET).upload(bPath, PNG, { contentType: 'image/png', cacheControl: '0' }), 'B uploads its own real private PNG');
  await samePng(await a.client.storage.from(BUCKET).download(aPath), 'A downloads its own original PNG bytes');
  await samePng(await b.client.storage.from(BUCKET).download(bPath), 'B downloads its own original PNG bytes');
  const consent = data(await a.client.from('user_consents').insert({ scope: 'privacy_policy', granted: true, policy_version: 'isolated-acl-audit' }).select().single(), 'A appends its own consent');
  const exp = data(await a.client.from('user_data_exports').insert({ format: 'json' }).select().single(), 'A creates an owned export record');
  data(await a.client.from('user_data_exports').update({ status: 'processing' }).eq('id', exp.id).select().single(), 'A updates its own export state');

  const payloads = {
    profiles: [{ id: a.id }, { display_name: 'must not apply' }, 'id', a.id],
    user_preferences: [{ user_id: a.id }, { theme: 'dark' }, 'user_id', a.id],
    user_consents: [{ user_id: a.id, scope: 'privacy_policy', granted: true, policy_version: 'isolated-acl-audit' }, { granted: false }, 'id', consent.id],
    sync_metadata: [{ user_id: a.id, device_id: randomUUID() }, { last_seen_at: new Date().toISOString() }, 'user_id', a.id],
    user_media: [{ user_id: a.id, object_path: trackedPath(a), mime_type: 'image/png', size_bytes: PNG.byteLength }, { status: 'failed' }, 'id', mediaA.id],
    user_data_exports: [{ user_id: a.id, format: 'json' }, { status: 'failed' }, 'id', exp.id],
    account_deletion_jobs: [{ user_id: a.id }, { status: 'failed' }, 'user_id', a.id],
  };
  for (const [label, actor] of [['anon', anonymous], ['service_role', admin]]) {
    for (const table of TABLES) {
      const [insert, patch, key, id] = payloads[table];
      aclDenied(await actor.from(table).select('*'), `${label} cannot SELECT ${table}`);
      aclDenied(await actor.from(table).insert(insert), `${label} cannot INSERT ${table}`);
      aclDenied(await actor.from(table).update(patch).eq(key, id), `${label} cannot UPDATE ${table}`);
      aclDenied(await actor.from(table).delete().eq(key, id), `${label} cannot DELETE ${table}`);
    }
    const rpcArgs = {
      has_current_auth_session: undefined, is_current_account_active: undefined,
      consume_account_rate_limit: { p_action: 'consent' },
      apply_account_mutation: { p_mutation_id: randomUUID(), p_device_id: randomUUID(), p_entity: 'profile', p_base_version: 2, p_patch: { display_name: 'must not apply' } },
      request_account_deletion: undefined,
    };
    for (const fn of PUBLIC_FUNCTIONS) aclDenied(await actor.rpc(fn, rpcArgs[fn]), `${label} cannot EXECUTE ${fn}`);
  }
  for (const actor of [anonymous, a.client, b.client, admin]) {
    const label = actor === anonymous ? 'anon' : actor === admin ? 'service_role' : actor === a.client ? 'A' : 'B';
    aclDenied(await actor.schema('app_private').from('account_mutation_receipts').select('*'), `${label} cannot access the private receipt schema through the API`);
    for (const fn of PRIVATE_FUNCTIONS) aclDenied(await actor.schema('app_private').rpc(fn), `${label} cannot expose private trigger function ${fn} as an RPC`);
  }
  for (const table of ['profiles', 'user_preferences']) {
    const key = table === 'profiles' ? 'id' : 'user_id';
    aclDenied(await a.client.from(table).update(table === 'profiles' ? { display_name: 'bypass' } : { theme: 'light' }).eq(key, a.id), `A cannot bypass the ${table} mutation RPC with a direct UPDATE`);
  }
  for (const table of ['user_consents', 'sync_metadata', 'user_media', 'user_data_exports']) {
    noRows(await b.client.from(table).select('*').eq('user_id', a.id), `B cannot SELECT A ${table}`);
  }
  noRows(await b.client.from('user_media').update({ status: 'failed' }).eq('id', mediaA.id).select(), 'B cannot UPDATE A media metadata');
  noRows(await b.client.from('user_media').delete().eq('id', mediaA.id).select(), 'B cannot DELETE A media metadata');
  noRows(await b.client.from('user_data_exports').update({ status: 'failed' }).eq('id', exp.id).select(), 'B cannot UPDATE A export record');
  noRows(await b.client.from('user_data_exports').delete().eq('id', exp.id).select(), 'B cannot DELETE A export record');
  aclDenied(await b.client.from('user_media').insert({ user_id: a.id, object_path: trackedPath(a), mime_type: 'image/png', size_bytes: PNG.byteLength }), 'B cannot INSERT media owned by A');
  aclDenied(await b.client.from('user_consents').insert({ user_id: a.id, scope: 'privacy_policy', granted: true, policy_version: 'isolated-acl-audit' }), 'B cannot INSERT consent owned by A');
  aclDenied(await a.client.from('user_consents').update({ granted: false }).eq('id', consent.id), 'Consent history is append-only even for A');
  inputRejected(await a.client.from('user_media').update({ object_path: trackedPath(a) }).eq('id', mediaA.id), 'Media trigger rejects an owner path rewrite');

  storageDenied(await anonymous.storage.from(BUCKET).download(aPath), 'Anonymous cannot download the private object without a signed capability');
  storageDenied(await b.client.storage.from(BUCKET).download(aPath), 'B cannot download A object with B credentials');
  storageDenied(await b.client.storage.from(BUCKET).createSignedUrl(aPath, 10), 'B cannot sign A object URL');
  storageDenied(await b.client.storage.from(BUCKET).upload(trackedPath(a), PNG, { contentType: 'image/png' }), 'B cannot upload into A directory');
  storageDenied(await b.client.storage.from(BUCKET).update(aPath, PNG, { contentType: 'image/png' }), 'B cannot update A object');
  await b.client.storage.from(BUCKET).remove([aPath]);
  await samePng(await a.client.storage.from(BUCKET).download(aPath), 'B remove attempt leaves A actual binary intact');
  await anonymous.storage.from(BUCKET).remove([aPath]);
  await samePng(await a.client.storage.from(BUCKET).download(aPath), 'Anonymous remove attempt leaves A actual binary intact');
  storageDenied(await a.client.storage.from(BUCKET).upload(trackedPath(a), Buffer.alloc(5_242_881), { contentType: 'image/png' }), 'Storage rejects one byte above 5 MiB', [413, 415]);
  storageDenied(await a.client.storage.from(BUCKET).upload(trackedPath(a, `${randomUUID()}.svg`), Buffer.from('<svg/>'), { contentType: 'image/svg+xml' }), 'Storage rejects unsupported SVG MIME', [413, 415]);

  const shortSigned = signedTarget(data(await a.client.storage.from(BUCKET).createSignedUrl(aPath, 8), 'A creates a short-lived URL for its own object').signedUrl);
  const shortUrlFingerprint = createHash('sha256').update(shortSigned.href).digest('hex');
  await checkRawPng(await fetchSigned(shortSigned), 'Signed URL permits its anonymous bearer before expiry');
  const claims = JSON.parse(Buffer.from(shortSigned.searchParams.get('token').split('.')[1], 'base64url').toString());
  check(Number.isFinite(claims.exp) && claims.exp * 1000 > Date.now(), 'Signed URL has a concrete future expiry');
  if (typeof claims.iat === 'number') check(claims.exp - claims.iat === 8, 'Signed URL claim TTL matches the requested eight seconds');
  observations.push({ label: 'Declared signed URL TTL seconds', status: 'OBSERVED_8_SECONDS' });
  if (typeof claims.iat === 'number') observations.push({ label: 'Signed URL non-sensitive iat time', status: new Date(claims.iat * 1000).toISOString() });
  observations.push({ label: 'Signed URL non-sensitive exp time', status: new Date(claims.exp * 1000).toISOString() });
  const tampered = new URL(shortSigned);
  tampered.pathname = tampered.pathname.replace(`/${a.id}/`, `/${b.id}/`);
  check(tampered.pathname !== shortSigned.pathname, 'Tampered-path fixture selects the existing B object');
  const tamperedResult = await fetchSigned(tampered);
  check([400, 401, 403, 404].includes(tamperedResult.status), 'A signed token cannot fetch the existing B object by changing its URL path');
  const waitMs = Math.max(0, claims.exp * 1000 - Date.now() + 1_500);
  check(waitMs <= 12_000, 'Signed URL expiry wait is short and bounded');
  await new Promise((resolve) => setTimeout(resolve, waitMs));
  let expiredResult = await fetchSigned(shortSigned);
  let expiryBytes = Buffer.from(await expiredResult.arrayBuffer());
  const maximumObservationTime = claims.exp * 1000 + 90_000;
  // A still-readable URL is observed, never silently treated as an expiry PASS.
  // Poll only this unchanged capability; every wait is at most two seconds.
  while (expiredResult.status === 200 && Date.now() < maximumObservationTime) {
    observations.push({ label: 'Short signed URL beyond exp remains readable', status: `OBSERVED_HTTP_200_AT_${Math.max(0, Date.now() - claims.exp * 1000)}_MS_AFTER_EXP` });
    await new Promise((resolve) => setTimeout(resolve, Math.min(2_000, Math.max(1, maximumObservationTime - Date.now()))));
    expiredResult = await fetchSigned(shortSigned);
    expiryBytes = Buffer.from(await expiredResult.arrayBuffer());
  }
  const expiryMessage = expiryBytes.toString('utf8');
  // Storage can intentionally return a generic InvalidJWT rather than expose
  // whether expiry/signature failed. The URL is unchanged, previously valid,
  // and a newly signed URL to the same existing object is tested below.
  const signatureError = /jwt|jws|token|signature|expir/i.test(expiryMessage);
  const expiryRejected = [400, 401, 403].includes(expiredResult.status) && signatureError;
  const storageDate = Date.parse(expiredResult.headers.get('date') ?? '');
  observations.push({ label: 'Short signed URL final expiry observation', status: `OBSERVED_HTTP_${expiredResult.status}_AT_${Math.max(0, Date.now() - claims.exp * 1000)}_MS_AFTER_EXP` });
  observations.push({ label: 'Signed URL rejection category', status: signatureError ? 'OBSERVED_SIGNATURE_OR_TOKEN_REJECTION' : 'NO_RECOGNIZED_TOKEN_REJECTION' });
  observations.push({ label: 'Storage response clock relative to signed claim expiry', status: Number.isFinite(storageDate) ? storageDate >= claims.exp * 1000 ? 'OBSERVED_SERVER_CLOCK_PAST_EXPIRY' : 'OBSERVED_SERVER_CLOCK_BEFORE_EXPIRY' : 'NO_RESPONSE_DATE' });
  if (expiredResult.status === 200) observations.push({ label: 'Short signed URL bytes after claim expiry', status: createHash('sha256').update(expiryBytes).digest('hex') === pngHash ? 'OBSERVED_ORIGINAL_PNG_STILL_ACCESSIBLE' : 'OBSERVED_UNEXPECTED_200_BODY' });
  check(createHash('sha256').update(shortSigned.href).digest('hex') === shortUrlFingerprint, 'Expiry observation uses the unchanged originally working signed URL');
  const freshAfterExpiry = signedTarget(data(await a.client.storage.from(BUCKET).createSignedUrl(aPath, 30), 'A signs the same existing object after the old capability expires').signedUrl);
  await checkRawPng(await fetchSigned(freshAfterExpiry), 'A fresh signature still reads the same original object after old URL rejection');
  // Preserve a failed TTL assertion while continuing unrelated logout/ACL cases;
  // a platform clock tolerance/cache behavior must never be reported as PASS.
  checks.push({ label: 'Expired signed URL is explicitly rejected by Storage', status: expiryRejected ? 'PASS' : 'FAIL' });
  await samePng(await a.client.storage.from(BUCKET).download(aPath), 'Signed URL expiry did not delete or corrupt the underlying object');

  const logoutSigned = signedTarget(data(await a.client.storage.from(BUCKET).createSignedUrl(aPath, 60), 'A creates a separate URL to observe logout semantics').signedUrl);
  const staleToken = a.session.access_token;
  data(await a.client.auth.signOut({ scope: 'global' }), 'A performs a real global Auth logout');
  const afterLogoutSigned = await fetchSigned(logoutSigned);
  if (afterLogoutSigned.status === 200) {
    await checkRawPng(afterLogoutSigned, 'Logout does not change the bytes of an otherwise valid signed capability');
    observations.push({ label: 'Signed URL logout semantics', status: 'OBSERVED_BEARER_ACCESS_REMAINS_AFTER_LOGOUT' });
  } else {
    check([400, 401, 403, 404].includes(afterLogoutSigned.status), 'Post-logout signed URL has a concrete Storage rejection rather than a network/server error');
    observations.push({ label: 'Signed URL logout semantics', status: 'OBSERVED_STORAGE_DENIAL_AFTER_LOGOUT' });
  }
  const revoked = client(anonKey, staleToken);
  noRows(await revoked.from('profiles').select('*'), 'A former JWT cannot read its profile after logout');
  check(data(await revoked.rpc('has_current_auth_session'), 'Former JWT can evaluate the restricted helper') === false, 'Former JWT has no live Auth session');
  aclDenied(await revoked.rpc('consume_account_rate_limit', { p_action: 'consent' }), 'A former JWT cannot invoke a live-session write RPC');
  storageDenied(await revoked.storage.from(BUCKET).download(aPath), 'A former JWT cannot download the private object after logout');
  await samePng(await b.client.storage.from(BUCKET).download(bPath), 'A logout does not revoke B or damage B binary');

  a.client = client();
  a.session = data(await a.client.auth.signInWithPassword({ email: a.email, password: a.password }), 'A signs in with a new real session after logout').session;
  const deletion = data(await a.client.rpc('request_account_deletion'), 'A requests its own deletion through the authenticated RPC');
  const repeated = data(await a.client.rpc('request_account_deletion'), 'A retries the existing deletion request');
  check(deletion.user_id === a.id && repeated.id === deletion.id, 'Deletion RPC only marks A and returns the same resumable job');
  check(data(await a.client.rpc('is_current_account_active'), 'A evaluates account state after deletion request') === false, 'Deletion request makes only A inactive');
  noRows(await b.client.from('account_deletion_jobs').select('*').eq('user_id', a.id), 'B cannot read A deletion job');
  noRows(await b.client.from('account_deletion_jobs').update({ status: 'failed' }).eq('id', deletion.id).select(), 'B cannot modify A deletion job');
  check(data(await b.client.rpc('is_current_account_active'), 'B checks its independent account state') === true, 'A deletion request does not deactivate B');
  await samePng(await a.client.storage.from(BUCKET).download(aPath), 'A can read its own Storage object during deletion cleanup');
  data(await a.client.storage.from(BUCKET).remove([aPath]), 'A can remove its own real Storage object during deletion cleanup');
  storageDenied(await admin.storage.from(BUCKET).download(aPath), 'Privileged Storage observer confirms A binary no longer exists');
  await samePng(await b.client.storage.from(BUCKET).download(bPath), 'A cleanup leaves B actual binary intact');
  data(await admin.auth.admin.deleteUser(a.id, false), 'Auth Admin deletion still works without application table grants');
  for (const table of [...TABLES, 'account_mutation_receipts', 'rate_limit_counters']) check((await observeUserRows(table, a.id)).length === 0, `Read-only inspector confirms A cascade cleanup in ${table}`);
  check(data(await admin.auth.admin.getUserById(b.id), 'Auth Admin observes the surviving B fixture').user.id === b.id, 'Deleting A does not delete B Auth user');
  await samePng(await b.client.storage.from(BUCKET).download(bPath), 'Deleting A does not delete B Storage object');
}

let status = 'failed';
try {
  await run();
  status = checks.some((item) => item.status === 'FAIL') ? 'failed' : 'passed';
  if (status === 'failed') process.exitCode = 1;
} catch (error) {
  const label = error instanceof AuditFailure ? error.label : currentLabel;
  if (!checks.some((x) => x.status === 'FAIL' && x.label === label)) checks.push({ label, status: 'FAIL' });
  process.exitCode = 1;
} finally {
  if (config && admin && accounts.length) {
    try {
      await assertLocalAclAuditTarget();
      if (storagePaths.size) {
        const removed = await admin.storage.from(BUCKET).remove([...storagePaths]);
        if (removed.error) throw new AuditFailure('Cleanup removes only this run tracked local Storage paths');
      }
      for (const actor of accounts) {
        const removed = await admin.auth.admin.deleteUser(actor.id, false);
        const code = removed.error?.code;
        if (removed.error && !['user_not_found', 'not_found'].includes(code) && Number(removed.error.status) !== 404) throw new AuditFailure('Cleanup deletes only this run tracked local Auth fixtures');
      }
      checks.push({ label: 'Tracked local fixture cleanup completed', status: 'PASS' });
    } catch {
      checks.push({ label: 'Tracked local fixture cleanup completed', status: 'FAIL' });
      status = 'failed'; process.exitCode = 1;
    }
  }
  const result = { environment: ENVIRONMENT, candidateSha256: CANDIDATE_SHA256, startedAt, finishedAt: new Date().toISOString(), status, checks, observations };
  if (resultDirectory) {
    try {
      const destination = join(resultDirectory, 'role-security-results.json');
      const temporary = `${destination}.tmp`;
      writeFileSync(temporary, `${JSON.stringify(result, null, 2)}\n`, { mode: 0o600 });
      renameSync(temporary, destination);
    } catch { status = 'failed'; process.exitCode = 1; }
  }
  console.log(JSON.stringify({ status, environment: ENVIRONMENT, assertions: checks.filter((x) => x.status === 'PASS').length, failedChecks: checks.filter((x) => x.status === 'FAIL').map(({ label }) => ({ label, status: 'FAIL' })), observations }, null, 2));
}
