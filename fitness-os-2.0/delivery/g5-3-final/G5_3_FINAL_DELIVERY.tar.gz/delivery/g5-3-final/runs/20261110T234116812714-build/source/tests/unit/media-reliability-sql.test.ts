import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
const sql = readFileSync(new URL("../../supabase/reviews/20261110000200_account_upload_reliability.final_proposed.sql", import.meta.url), "utf8");
const source = (path: string) => readFileSync(new URL("../../" + path, import.meta.url), "utf8");
describe("G5.3 static security contracts (not database integration)", () => {
  it("contains durable per-user idempotency fingerprints", () => {
    expect(sql).toContain("unique(user_id,request_id)");
    expect(sql).toContain("request_sha256"); expect(sql).toContain("expected_sha256");
    expect(sql).toContain("idempotency_conflict"); expect(sql).toContain("idempotency_deleted");
  });
  it("uses token leases, bounded retries and a fresh post-lock clock", () => {
    expect(sql).toContain("lease_token is distinct from p_lease");
    expect(sql).toContain("attempts>=3"); expect(sql).toContain("next_attempt_at");
    expect(sql).toContain("Refresh AFTER waiting for the owner lock");
  });
  it("grants only the bounded new maintenance function to service_role", () => {
    const grant = sql.match(/^grant.*server_media_reliability.*$/gm);
    expect(grant).toHaveLength(1); expect(grant?.[0]).toContain("to service_role;");
    expect(sql).not.toMatch(/grant all.*to service_role/i);
    expect(sql).toContain("revoke all on all sequences in schema app_private");
  });
  it("has managed-version precondition and content-change/cancellation fences", () => {
    expect(sql).toContain("Storage object version column is required");
    expect(sql).toContain("tg_op in ('UPDATE','DELETE')");
    expect(sql).toContain("immutable_media_storage_key");
    expect(sql).toContain("v_media.status<>'processing'");
  });
  it("retains one atomic initial and seven original functions and transient avatar references", () => {
    expect(sql.match(/^begin;$/gm)).toHaveLength(1); expect(sql.match(/^commit;$/gm)).toHaveLength(1);
    const old = source("supabase/reviews/20261103000100_account_foundation.acl_proposed.sql");
    const fns = old.match(/^create function[\s\S]*?\$\$;/gm) ?? [];
    expect(fns).toHaveLength(8); for (const fn of fns.filter((f) => !f.includes("create function app_private.clear_removed_avatar"))) expect(sql).toContain(fn);
    expect(sql).toContain("if new.status not in ('ready','unavailable') then");
  });
  it("maintenance has a separate private credential and no cookie-based privilege fallback", () => {
    const route = source("src/app/api/internal/media/reconcile/route.ts");
    expect(route).toContain("timingSafeEqual"); expect(route).toContain("FITNESS_MEDIA_WORKER_TOKEN");
    expect(route).not.toContain("auth.uid"); expect(route).not.toContain("requireAccount");
  });
  it("reads actual bytes rather than trusting ETag or client SHA", () => {
    const code = source("src/lib/account/media-reliability.ts");
    expect(code).toContain("digestBytes(bytes) !== digest"); expect(code).toContain("digestBytes(raw)");
    expect(code).toContain(".raw().timeout"); expect(code).not.toContain("ETag");
    expect(source("src/app/api/account/media/[id]/route.ts")).toContain("new Uint8Array(verified.bytes)");
  });
  it("client retains only the logical request identity in memory, not a private file cache", () => {
    const ui = source("src/features/sync/account-privacy.tsx");
    expect(ui).toContain('"Idempotency-Key": uploadRequest.current.id');
    expect(ui).toContain("uploadRequest.current.owner !== user.id");
    expect(ui).not.toContain("caches.put");
  });
});
