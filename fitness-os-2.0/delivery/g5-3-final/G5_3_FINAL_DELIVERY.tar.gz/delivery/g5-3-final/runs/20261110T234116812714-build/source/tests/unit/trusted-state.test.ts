import { describe, expect, it, vi } from "vitest";
import sharp from "sharp";
import type { SupabaseClient } from "@supabase/supabase-js";
import { normalizeImage, MAX_VERIFIED_BYTES } from "../../src/lib/account/verified-image";
import { assertOwnedKey, uploadVerifiedMedia, prepareAccountDeletion, FINAL_BUCKET, STAGING_BUCKET } from "../../src/lib/account/trusted-state";

vi.mock("@/lib/supabase/admin", () => ({ createAdminSupabaseClient: () => { throw new Error("No credentials in offline tests"); } }));
vi.mock("@/lib/account/server", () => ({ dbError: () => new Error("RPC rejected") }));
const A = "aaaaaaaa-1111-4111-8111-111111111111";
const B = "bbbbbbbb-2222-4222-8222-222222222222";
async function image() { return sharp({ create: { width: 2, height: 2, channels: 3, background: "red" } }).png().toBuffer(); }

// This transport fake exercises real orchestration and decoding, NOT database ACL/RLS.
function transport(options: { missingFinal?: boolean; corruptStage?: boolean; lostReadyAck?: boolean; uncertainUpload?: boolean } = {}) {
  const objects = new Map<string, Uint8Array>();
  const calls: { name: string; action: string; owner: string }[] = [];
  let row: Record<string, unknown> = {};
  let removeFailures = 0;
  let lostAck = options.lostReadyAck;
  const client = {
    rpc: async (name: string, args: Record<string, unknown>) => {
      const action = String(args.p_action); const owner = String(args.p_owner);
      calls.push({ name, action, owner });
      if (name === "server_media_write") {
        if (action === "begin") row = { id: args.p_id, user_id: owner, object_path: `${owner}/${args.p_id}.png`, status: "pending" };
        if (action === "ready") {
          row = { ...row, status: "ready", content_sha256: args.p_digest };
          if (lostAck) { lostAck = false; return { data: null, error: { code: "NETWORK" } }; }
        }
        if (action === "failed") row.status = "failed";
        return { data: { ...row }, error: null };
      }
      return { data: { status: action }, error: null };
    },
    storage: { from: (bucket: string) => ({
      upload: async (key: string, bytes: Uint8Array) => {
        if (!(bucket === FINAL_BUCKET && options.missingFinal)) objects.set(`${bucket}:${key}`, new Uint8Array(bytes));
        return { error: options.uncertainUpload ? { status: 503 } : null };
      },
      download: async (key: string) => {
        const bytes = objects.get(`${bucket}:${key}`);
        if (!bytes) return { data: null, error: { status: 404 } };
        return { data: new Blob([new Uint8Array(bucket === STAGING_BUCKET && options.corruptStage ? [1, 2] : bytes)]), error: null };
      },
      remove: async (keys: string[]) => {
        if (removeFailures-- > 0) return { error: { status: 503 } };
        keys.forEach((key) => objects.delete(`${bucket}:${key}`)); return { error: null };
      },
      list: async (prefix: string) => {
        const found = new Map<string, { name: string; id: string | null }>();
        for (const key of objects.keys()) {
          const start = `${bucket}:${prefix}/`; if (!key.startsWith(start)) continue;
          const rest = key.slice(start.length); const name = rest.split("/")[0];
          found.set(name, { name, id: rest.includes("/") ? null : name });
        }
        return { data: [...found.values()], error: null };
      },
    }) },
  } as unknown as SupabaseClient;
  return { client, objects, calls, failNextRemove: () => { removeFailures = 1; } };
}

describe("trusted image decoding (offline, actual sharp)", () => {
  it("fully decodes and normalizes a valid image", async () => {
    const result = await normalizeImage(await image(), "image/png");
    expect((await sharp(result.bytes).metadata()).format).toBe("png");
    expect(result.digest).toMatch(/^[a-f0-9]{64}$/);
  });
  it("rejects a JPEG-shaped marker sequence without a decodable image", async () => {
    await expect(normalizeImage(new Uint8Array([255,216,255,217]), "image/jpeg")).rejects.toMatchObject({ status: 415 });
  });
  it("rejects forged MIME", async () => { await expect(normalizeImage(await image(), "image/jpeg")).rejects.toMatchObject({ status: 415 }); });
  it("rejects empty and oversized inputs before decode", async () => {
    for (const input of [new Uint8Array(), new Uint8Array(MAX_VERIFIED_BYTES + 1)]) {
      await expect(normalizeImage(input, "image/png")).rejects.toMatchObject({ status: 413 });
    }
  });
});
describe("trusted upload orchestration (mock transport; no Supabase)", () => {
  it("only finalizes after stage/final readback and deletes staging", async () => {
    const t = transport(); const row = await uploadVerifiedMedia(t.client, A, await image(), "image/png");
    expect(row.status).toBe("ready"); expect(t.calls.map((c) => c.action)).toEqual(["begin", "ready"]);
    expect([...t.objects.keys()]).toHaveLength(1); expect([...t.objects.keys()][0]).toContain(`${FINAL_BUCKET}:${A}/`);
  });
  it("missing final object never gets a ready call", async () => {
    const t = transport({ missingFinal: true });
    await expect(uploadVerifiedMedia(t.client, A, await image(), "image/png")).rejects.toMatchObject({ code: "OBJECT_VERIFY_FAILED" });
    expect(t.calls.some((c) => c.action === "ready")).toBe(false); expect(t.objects.size).toBe(0);
  });
  it("corrupt stored bytes never get a ready call", async () => {
    const t = transport({ corruptStage: true });
    await expect(uploadVerifiedMedia(t.client, A, await image(), "image/png")).rejects.toMatchObject({ code: "OBJECT_VERIFY_FAILED" });
    expect(t.calls.some((c) => c.action === "ready")).toBe(false);
  });
  it("uncertain upload outcome retains pending fence even after apparent cleanup", async () => {
    const t = transport({ uncertainUpload: true });
    await expect(uploadVerifiedMedia(t.client, A, await image(), "image/png")).rejects.toMatchObject({ code: "UPLOAD_FAILED" });
    expect(t.calls.map((c) => c.action)).toEqual(["begin"]);
    expect(t.objects.size).toBe(0); // Empty now is not proof of no delayed writer.
  });
  it("lost finalization acknowledgement inspects committed state without deleting ready binary", async () => {
    const t = transport({ lostReadyAck: true });
    expect((await uploadVerifiedMedia(t.client, A, await image(), "image/png")).status).toBe("ready");
    expect(t.calls.map((c) => c.action)).toEqual(["begin", "ready", "inspect"]); expect(t.objects.size).toBe(1);
  });
});
describe("owner-scoped deletion and retry (mock transport)", () => {
  it("rejects cross-owner, encoded and dot-segment keys", () => {
    for (const key of [`${B}/a.png`, `${A}/../b.png`, `${A}/a//b`, `${A}/%2e/a`, `${A}/a/./b`]) expect(() => assertOwnedKey(A, key)).toThrow();
  });
  it("failure marks retryable stage; retry clears only A including nested orphan and preserves B", async () => {
    const t = transport();
    t.objects.set(`${FINAL_BUCKET}:${A}/a.png`, new Uint8Array([1]));
    t.objects.set(`${STAGING_BUCKET}:${A}/orphan/${B}/c.png`, new Uint8Array([2]));
    t.objects.set(`${FINAL_BUCKET}:${B}/b.png`, new Uint8Array([3]));
    t.failNextRemove(); await expect(prepareAccountDeletion(t.client, A)).rejects.toMatchObject({ code: "STORAGE_DELETE_FAILED" });
    expect(t.calls.map((c) => c.action)).toEqual(["start", "cancel_account", "fail"]);
    await prepareAccountDeletion(t.client, A);
    expect(t.calls.map((c) => c.action)).toEqual(["start", "cancel_account", "fail", "start", "cancel_account", "verify_auth"]);
    expect([...t.objects.keys()]).toEqual([`${FINAL_BUCKET}:${B}/b.png`]);
    expect(t.calls.every((c) => c.owner === A)).toBe(true);
  });
});
