import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";
import { randomUUID } from "node:crypto";
import { createAdminSupabaseClient } from "@/lib/supabase/admin";
import { dbError } from "@/lib/account/server";
import { RequestError } from "@/lib/security/request";
import { digestBytes, MAX_VERIFIED_BYTES, normalizeImage } from "./verified-image";

export const STAGING_BUCKET = "private-media-staging";
export const FINAL_BUCKET = "private-media";
const UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
export function assertOwner(owner: string) {
  if (!UUID.test(owner)) throw new RequestError(400, "INVALID_OWNER", "账号标识无效。");
}
export function assertOwnedKey(owner: string, key: string) {
  assertOwner(owner);
  if (!key.startsWith(`${owner}/`) || key.split("/").some((s) => !s || s === "." || s.includes("..") || !/^[A-Za-z0-9_.-]+$/.test(s))) {
    throw new RequestError(409, "UNSAFE_STORAGE_KEY", "文件键需人工审查，未继续清理。");
  }
}
export function trustedClient() {
  const client = createAdminSupabaseClient();
  if (!client) throw new RequestError(503, "ADMIN_NOT_CONFIGURED", "可信服务端尚未配置，操作未执行。");
  return client;
}
async function rpc(client: SupabaseClient, name: string, args: Record<string, unknown>) {
  const { data, error } = await client.rpc(name, args);
  if (error) throw dbError(error);
  return data;
}
export async function mediaWrite(client: SupabaseClient, owner: string, id: string, action: string, extra: Record<string, unknown> = {}) {
  assertOwner(owner);
  if (!UUID.test(id)) throw new RequestError(400, "INVALID_MEDIA", "媒体标识无效。");
  return rpc(client, "server_media_write", { ...extra, p_owner: owner, p_id: id, p_action: action });
}
export async function exportWrite(client: SupabaseClient, owner: string, id: string, action: string, format?: "json" | "csv") {
  assertOwner(owner);
  return rpc(client, "server_export_write", { p_owner: owner, p_id: id, p_action: action, p_format: format ?? null });
}
export async function deletionWrite(client: SupabaseClient, owner: string, action: string) {
  assertOwner(owner);
  return rpc(client, "server_deletion_progress", { p_owner: owner, p_action: action });
}
async function remove(client: SupabaseClient, bucket: string, owner: string, key: string) {
  assertOwnedKey(owner, key);
  const { error } = await client.storage.from(bucket).remove([key]);
  if (error) throw new RequestError(503, "STORAGE_DELETE_FAILED", "私人文件清理未完成，请重试。");
}
async function verifyObject(client: SupabaseClient, bucket: string, key: string, expected: Uint8Array) {
  const { data, error } = await client.storage.from(bucket).download(key);
  if (error || !data || data.size > MAX_VERIFIED_BYTES || data.size !== expected.byteLength) {
    throw new RequestError(503, "OBJECT_VERIFY_FAILED", "存储对象不存在或长度不一致。");
  }
  const actual = new Uint8Array(await data.arrayBuffer());
  if (digestBytes(actual) !== digestBytes(expected)) throw new RequestError(503, "OBJECT_VERIFY_FAILED", "存储对象内容不一致。");
}
export async function uploadVerifiedMedia(client: SupabaseClient, owner: string, input: Uint8Array, mime: string) {
  assertOwner(owner);
  const verified = await normalizeImage(input, mime);
  const id = randomUUID();
  const key = `${owner}/${id}.png`;
  const row = await mediaWrite(client, owner, id, "begin", { p_mime: verified.mime, p_size: verified.bytes.byteLength });
  if (row?.object_path !== key) throw new RequestError(503, "MEDIA_KEY_MISMATCH", "媒体键核验失败。");
  let finalizationAttempted = false;
  let uploadOutcomeUncertain = false;
  try {
    for (const bucket of [STAGING_BUCKET, FINAL_BUCKET]) {
      uploadOutcomeUncertain = true;
      const { error } = await client.storage.from(bucket).upload(key, verified.bytes, { contentType: verified.mime, upsert: false, cacheControl: "0" });
      if (error) throw new RequestError(503, "UPLOAD_FAILED", "可信上传未完成。");
      uploadOutcomeUncertain = false;
      await verifyObject(client, bucket, key, verified.bytes);
    }
    await remove(client, STAGING_BUCKET, owner, key);
    finalizationAttempted = true;
    return await mediaWrite(client, owner, id, "ready", { p_mime: verified.mime, p_size: verified.bytes.byteLength, p_digest: verified.digest });
  } catch (error) {
    if (finalizationAttempted) {
      // A lost response may follow a committed ready transition. Never delete that object blindly.
      let observed;
      try { observed = await mediaWrite(client, owner, id, "inspect"); } catch { throw error; }
      if (observed?.status === "ready") {
        if (observed.content_sha256 !== verified.digest) throw error;
        await verifyObject(client, FINAL_BUCKET, key, verified.bytes);
        return observed;
      }
      if (observed?.status !== "pending") throw error;
    }
    // Release the pending fence only after both object removals succeeded.
    // Uncertain cleanup stays pending, blocking Auth deletion; never pretend it is complete.
    const cleanups = await Promise.allSettled([remove(client, STAGING_BUCKET, owner, key), remove(client, FINAL_BUCKET, owner, key)]);
    // A failed upload response can leave a delayed remote write. Empty metadata
    // and successful removal cannot prove that writer is quiescent. Keep its fence.
    if (!uploadOutcomeUncertain && cleanups.every((result) => result.status === "fulfilled")) {
      try { await mediaWrite(client, owner, id, "failed"); } catch { /* Trusted reconciliation required. */ }
    }
    throw error;
  }
}
export async function deleteOwnedMedia(client: SupabaseClient, owner: string, row: { id: string; object_path: string }) {
  assertOwnedKey(owner, row.object_path);
  const cancel = await client.rpc("server_media_reliability", { p_action: "cancel_media", p_owner: owner, p_media: row.id });
  if (cancel.error) throw dbError(cancel.error);
  if (cancel.data?.active) throw new RequestError(409, "MEDIA_DELETE_RETRY", "上传操作正在结束，请稍后重试删除。");
  await mediaWrite(client, owner, row.id, "deleting");
  await remove(client, FINAL_BUCKET, owner, row.object_path);
  await remove(client, STAGING_BUCKET, owner, row.object_path);
  await mediaWrite(client, owner, row.id, "remove");
}
export async function clearAccountStorage(client: SupabaseClient, owner: string) {
  assertOwner(owner);
  const budget = { remaining: 200 };
  async function walk(bucket: string, prefix: string): Promise<void> {
    if (prefix !== owner) assertOwnedKey(owner, prefix);
    for (;;) {
      if (--budget.remaining < 0) throw new RequestError(409, "DELETE_RETRY_REQUIRED", "本批清理达到上限，请重试。");
      const { data, error } = await client.storage.from(bucket).list(prefix, { limit: 100, offset: 0, sortBy: { column: "name", order: "asc" } });
      if (error || !data) throw new RequestError(503, "STORAGE_DELETE_FAILED", "私人文件清理失败，请重试。");
      if (!data.length) return;
      for (const item of data) {
        const key = `${prefix}/${item.name}`;
        assertOwnedKey(owner, key);
        if (item.id) await remove(client, bucket, owner, key);
        else await walk(bucket, key);
      }
    }
  }
  for (const bucket of [FINAL_BUCKET, STAGING_BUCKET]) await walk(bucket, owner);
}
export async function prepareAccountDeletion(client: SupabaseClient, owner: string) {
  await deletionWrite(client, owner, "start");
  try {
    const cancel = await client.rpc("server_media_reliability", { p_action: "cancel_account", p_owner: owner });
    if (cancel.error) throw dbError(cancel.error);
    if (cancel.data?.active) throw new RequestError(503, "UPLOAD_DRAIN_REQUIRED", "仍有上传操作正在结束，请稍后重试删除。");
    await clearAccountStorage(client, owner);
    // DB independently checks object metadata and unfinished upload fences.
    return await deletionWrite(client, owner, "verify_auth");
  } catch (error) {
    try { await deletionWrite(client, owner, "fail"); } catch { /* Keep the original error. */ }
    throw error;
  }
}

/** Only called after real password reauthentication in the account API. */
export async function authorizeAccountCleanup(client: SupabaseClient, owner: string, jobId: string) {
  await rpc(client, "server_media_reliability", { p_action: "account_cleanup_authorize", p_owner: owner, p_request: jobId });
  const claim = await rpc(client, "server_media_reliability", { p_action: "account_cleanup_claim", p_owner: owner });
  if (!claim.claimed) throw new RequestError(409, "DELETE_ALREADY_PROCESSING", "删除正在处理或等待重试，请稍后重试。");
  return claim.lease_token as string;
}
export async function deferAccountCleanup(client: SupabaseClient, owner: string, lease: string) {
  await rpc(client, "server_media_reliability", { p_action: "account_cleanup_retry", p_owner: owner, p_lease: lease });
}
export async function verifyAuthRemoved(client: SupabaseClient, owner: string) {
  const result = await client.auth.admin.getUserById(owner);
  if (result.error?.status === 404 && result.error.code === "user_not_found") return;
  throw new RequestError(503, "AUTH_DELETE_UNCONFIRMED", "账号删除尚未核实，请稍后重试或联系支持。");
}
/** Resumes only a narrowly authorized receipt; a user RPC request is insufficient. */
export async function resumeAccountCleanup(client: SupabaseClient, owner: string) {
  const claim = await rpc(client, "server_media_reliability", { p_action: "account_cleanup_claim", p_owner: owner });
  if (!claim.claimed) return false;
  try {
    await prepareAccountDeletion(client, owner);
    const result = await client.auth.admin.deleteUser(owner, false);
    if (result.error) { await verifyAuthRemoved(client, owner); return true; }
    await verifyAuthRemoved(client, owner);
    return true;
  } catch (error) {
    await Promise.allSettled([deferAccountCleanup(client, owner, claim.lease_token), deletionWrite(client, owner, "fail")]);
    throw error;
  }
}
