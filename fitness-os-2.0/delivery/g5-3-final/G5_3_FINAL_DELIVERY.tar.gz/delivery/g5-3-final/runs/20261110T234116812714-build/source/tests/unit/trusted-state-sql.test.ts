import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
const sql = readFileSync(new URL("../../supabase/reviews/20261103000100_account_foundation.trusted_state_proposed.sql", import.meta.url), "utf8");
const old = readFileSync(new URL("../../supabase/reviews/20261103000100_account_foundation.acl_proposed.sql", import.meta.url), "utf8");
const grants = sql.match(/^grant\s[\s\S]*?;/gim) ?? [];
const policies = sql.match(/^create policy\s[\s\S]*?;/gim) ?? [];

describe("trusted candidate static boundary (not database execution)", () => {
  it("authenticated has no broad writes; consent INSERT remains column-limited", () => {
    for (const grant of grants.filter((s) => /to authenticated;/i.test(s))) {
      expect(grant).toMatch(/^grant (select|execute|insert \(user_id, scope, granted, policy_version\) on public.user_consents)/i);
    }
    expect(sql).toContain("grant insert (user_id, scope, granted, policy_version) on public.user_consents to authenticated;");
  });
  it("trusted finalizers are granted only to service_role with fixed search_path and role guard", () => {
    for (const name of ["server_media_write", "server_export_write", "server_deletion_progress"]) {
      const fn = sql.match(new RegExp(`create function public\\.${name}\\([\\s\\S]*?\\$\\$;`))?.[0];
      expect(fn).toContain("security definer set search_path = ''");
      expect(fn).toContain("trusted_service_required");
      expect(grants.filter((s) => s.includes(`public.${name}(`))).toHaveLength(1);
      expect(grants.find((s) => s.includes(`public.${name}(`))).toMatch(/to service_role;/);
    }
    expect(grants.filter((s) => /to service_role;/.test(s))).toHaveLength(3);
  });
  it("Storage gives clients only own ready-object SELECT, never staging writes", () => {
    const storage = policies.filter((s) => s.includes("on storage.objects"));
    expect(storage).toHaveLength(1); expect(storage[0]).toContain("for select to authenticated");
    expect(storage[0]).toContain("m.status = 'ready'");
    expect(storage[0]).toContain("bucket_id = 'private-media'");
    expect(sql).toContain("'private-media-staging','private-media-staging',false");
  });
  it("missing objects and pending uploads are explicit server-side fences", () => {
    expect(sql).toContain("message='verified_object_missing'");
    expect(sql).toContain("message='upload_still_pending'");
    expect(sql).toContain("where user_id=p_owner and status='pending'");
    expect(sql).toContain("bucket_id in ('private-media','private-media-staging')");
  });
  it("export paths are NULL and media keys bind owner/id/type", () => {
    expect(sql).toContain("constraint user_data_exports_object_owner check (object_path is null)");
    expect(sql).toContain("object_path = user_id::text || '/' || id::text || case mime_type");
    expect(sql).toContain("constraint verified_ready check");
  });
  it("preserves all eight old RPC/trigger implementations and consent append rules", () => {
    const functions = old.match(/^create function[\s\S]*?\$\$;/gm) ?? [];
    expect(functions).toHaveLength(8); functions.forEach((fn) => expect(sql).toContain(fn));
    expect(policies.filter((s) => s.includes("on public.user_consents"))).toHaveLength(2);
    expect(policies.filter((s) => s.includes("on public.user_consents")).every((s) => /for (select|insert)/.test(s))).toBe(true);
  });
  it("owns one explicit transaction and does not introduce dynamic SQL", () => {
    expect(sql.match(/^begin;$/gm)).toHaveLength(1);
    expect(sql.match(/^commit;$/gm)).toHaveLength(1);
    expect(sql.trim().endsWith("commit;")).toBe(true);
    expect(sql).not.toMatch(/^[ \t]*execute[ \t]+/gmi);
  });
  it("sync clocks are written by bounded mutation RPC, not client payload", () => {
    expect(sql).toContain("values (v_user, p_device_id, pg_catalog.clock_timestamp()");
    expect(sql).toContain("last_synced_at = case when v_version = p_base_version");
    expect(grants.filter((g) => /sync_metadata/.test(g)).every((g) => /^grant select/.test(g))).toBe(true);
  });
  it("retains password reauthentication before cleanup and final Auth Admin delete", () => {
    const route = readFileSync(new URL("../../src/app/api/account/delete/route.ts", import.meta.url), "utf8");
    const auth = route.indexOf("client.auth.signInWithPassword");
    const cleanup = route.indexOf("await prepareAccountDeletion(admin, user.id)");
    const removeAuth = route.indexOf("admin.auth.admin.deleteUser(user.id, false)");
    expect(auth).toBeGreaterThan(0); expect(cleanup).toBeGreaterThan(auth); expect(removeAuth).toBeGreaterThan(cleanup);
  });
});
