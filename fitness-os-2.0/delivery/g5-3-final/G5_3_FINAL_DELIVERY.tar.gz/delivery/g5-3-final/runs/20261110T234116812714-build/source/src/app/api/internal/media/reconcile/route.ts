import { timingSafeEqual } from "node:crypto";
import { z } from "zod";
import { trustedClient } from "@/lib/account/trusted-state";
import { reconcileMedia } from "@/lib/account/media-reliability";
import { accountError } from "@/lib/account/server";
import { privateJson, readJson, RequestError } from "@/lib/security/request";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function POST(request: Request) {
  try {
    const expected = process.env.FITNESS_MEDIA_WORKER_TOKEN;
    if (!expected || expected.length < 32) throw new RequestError(503, "WORKER_NOT_CONFIGURED", "媒体维护服务尚未配置。");
    const supplied = request.headers.get("authorization")?.replace(/^Bearer /, "") ?? "";
    if (Buffer.byteLength(supplied) !== Buffer.byteLength(expected) || !timingSafeEqual(Buffer.from(supplied), Buffer.from(expected))) throw new RequestError(401, "WORKER_AUTH_REQUIRED", "需要可信维护身份。");
    const body = z.object({ after: z.uuid().nullable().optional() }).strict().safeParse(await readJson(request));
    if (!body.success) throw new RequestError(400, "INVALID_WORKER_REQUEST", "维护请求格式无效。");
    return privateJson(await reconcileMedia(trustedClient(), body.data.after ?? null));
  } catch (error) { return accountError(error); }
}
