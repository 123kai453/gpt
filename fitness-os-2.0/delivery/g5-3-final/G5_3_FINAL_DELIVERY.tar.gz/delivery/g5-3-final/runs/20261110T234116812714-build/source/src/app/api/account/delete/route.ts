import { prepareAccountDeletion, deletionWrite, authorizeAccountCleanup, deferAccountCleanup, verifyAuthRemoved } from "@/lib/account/trusted-state";
import { z } from "zod";
import { cookies } from "next/headers";
import { getSupabasePublicConfig } from "@/lib/supabase/config";
import { accountError, dbError, requireAccount } from "@/lib/account/server";
import { createAdminSupabaseClient } from "@/lib/supabase/admin";
import { privateJson, readJson, RequestError, requireTrustedOrigin } from "@/lib/security/request";
export const dynamic = "force-dynamic";
export const runtime = "nodejs";
const deletionSchema = z.object({ confirmation: z.literal("DELETE"), password: z.string().min(1).max(128) }).strict();

export async function POST(request: Request) {
  let context: Awaited<ReturnType<typeof requireAccount>> | undefined;
  let jobId: string | undefined;
  let cleanupLease: string | undefined;
  let server: ReturnType<typeof createAdminSupabaseClient> = null;
  try {
    requireTrustedOrigin(request);
    const parsed = deletionSchema.safeParse(await readJson(request));
    if (!parsed.success) throw new RequestError(400, "DELETE_CONFIRMATION_REQUIRED", "请输入 DELETE 并提供当前密码以确认删除。");
    const admin = createAdminSupabaseClient();
    server = admin;
    if (!admin) throw new RequestError(503, "ADMIN_NOT_CONFIGURED", "服务端尚未配置账号删除凭据，账号和数据尚未删除。");
    context = await requireAccount(true);
    const { client, user } = context;
    if (!user.email) throw new RequestError(409, "EMAIL_ACCOUNT_REQUIRED", "当前账号缺少可验证的邮箱，无法完成删除确认。");
    // Reauthentication occurs before marking or removing any data. Password never enters our database.
    const { data: reauthenticated, error: authError } = await client.auth.signInWithPassword({ email: user.email, password: parsed.data.password });
    if (authError || reauthenticated.user?.id !== user.id) throw new RequestError(401, "REAUTHENTICATION_FAILED", "密码验证失败，未执行删除。");
    const { data: job, error: requestError } = await client.rpc("request_account_deletion");
    if (requestError) throw dbError(requestError);
    if (!job?.id) throw new RequestError(503, "DELETE_NOT_STARTED", "未能建立删除任务，请重试。");
    jobId = job.id;
    cleanupLease = await authorizeAccountCleanup(admin, user.id, job.id);
    await prepareAccountDeletion(admin, user.id);
    // Only after password reauthentication, both-bucket cleanup and DB pending fences.
    const { error: deleteError } = await admin.auth.admin.deleteUser(user.id, false);
    if (deleteError) { await verifyAuthRemoved(admin, user.id); }
    await verifyAuthRemoved(admin, user.id);
    // Auth row deletion cascades all user-owned SQL records, receipts and deletion job.
    // Account removal has already revoked all sessions. Logout HTTP can return
    // 403 for the deleted user, and a transient failure must not turn a completed
    // deletion into a misleading error or leave its browser cookies behind.
    try { await client.auth.signOut({ scope: "local" }); } catch { /* Explicit cookie cleanup below is authoritative. */ }
    const publicConfig = getSupabasePublicConfig();
    if (publicConfig) {
      const base = `sb-${new URL(publicConfig.url).hostname.split(".")[0]}-auth-token`;
      const cookieStore = await cookies();
      for (const cookie of cookieStore.getAll()) {
        if (cookie.name === base || cookie.name.startsWith(base + ".") || cookie.name.startsWith(base + "-")) {
          cookieStore.set(cookie.name, "", { path: "/", maxAge: 0, sameSite: "lax" });
        }
      }
    }
    return privateJson({ deleted: true, message: "账号、数据库记录及私人文件已删除。" });
  } catch (error) {
    if (jobId && context) {
      if (server && cleanupLease) { try { await deferAccountCleanup(server, context.user.id, cleanupLease); } catch { /* Durable lease remains for recovery if the database is unavailable. */ } }
      if (server) { try { await deletionWrite(server, context.user.id, "fail"); } catch { /* Auth may already be gone. */ } }
    }
    return accountError(error);
  }
}
