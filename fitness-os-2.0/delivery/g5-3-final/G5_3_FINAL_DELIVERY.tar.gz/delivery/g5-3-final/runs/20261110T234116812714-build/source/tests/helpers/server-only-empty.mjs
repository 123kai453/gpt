// Unit test alias only; production retains Next server-only enforcement.
export {};
