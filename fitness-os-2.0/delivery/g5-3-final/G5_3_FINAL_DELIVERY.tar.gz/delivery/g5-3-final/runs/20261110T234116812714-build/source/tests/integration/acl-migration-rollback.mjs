/**
 * Disposable PostgreSQL 17 migration/rollback fixture tests, not an Auth/Storage integration.
 * Usage: node tests/integration/acl-migration-rollback.mjs --config <private local config>
 *
 * Requires a pre-created, explicitly marked fresh Docker container. This script never starts
 * containers, invokes the Supabase CLI, uses an API URL, or changes the main database/roles.
 * Only acl_audit_* databases created by this invocation can be changed or removed.
 * Auth/Storage schemas below are minimal DDL compatibility fixtures; their UUID rows are not
 * GoTrue users and their Storage rows are not file binaries. The real service tests are separate.
 */
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createHash, randomBytes } from 'node:crypto';
import { mkdir, readFile, realpath, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../../', import.meta.url));
const originalPath = path.join(root, 'supabase/migrations/20261103000100_account_foundation.sql');
const candidatePath = path.join(root, 'supabase/reviews/20261103000100_account_foundation.acl_proposed.sql');
const originalHash = 'e3ee70b56d33b0ab3d4e73e95525a5d1c16fa94624901006a92387c9f405f436';
const candidateHash = 'eb76a2d07f7780c8850431bd207865af33a31a1e6c9dda388b1cd12ff173968b';
const migrationVersion = '20261103000100';
const appTables = [
  'public.profiles', 'public.user_preferences', 'public.user_consents',
  'public.sync_metadata', 'public.user_data_exports', 'public.user_media',
  'public.account_deletion_jobs', 'app_private.account_mutation_receipts',
  'app_private.rate_limit_counters',
];
const digest = (value) => createHash('sha256').update(value).digest('hex');
const literal = (value) => `'${String(value).replaceAll("'", "''")}'`;
const identifier = (value) => `"${String(value).replaceAll('"', '""')}"`;
const results = [];
const createdDatabases = new Map();
let config;
let reportFile;
let verifiedContainer = false;
let localPassword;

function requireCondition(condition, message) {
  if (!condition) throw new Error(message);
}

function safeFailure(error) {
  const message = error instanceof Error ? error.message : 'Unknown local fixture failure';
  return (localPassword ? message.replaceAll(localPassword, '<redacted>') : message).slice(0, 700);
}

function command(args, input = '', timeout = 90_000) {
  requireCondition(verifiedContainer || args[2] === 'inspect', 'Container identity has not been verified');
  const env = { ...process.env };
  const dockerSelectors = new Set(['DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH']);
  for (const name of Object.keys(env)) {
    if (/^(SUPABASE_|NEXT_PUBLIC_|PG)/.test(name) || name === 'DATABASE_URL' || dockerSelectors.has(name)) delete env[name];
  }
  if (localPassword) env.PGPASSWORD = localPassword;
  return new Promise((resolve, reject) => {
    const child = spawn('docker', args, { env, stdio: ['pipe', 'pipe', 'pipe'], shell: false });
    let stdout = '';
    let stderr = '';
    let finished = false;
    const timer = setTimeout(() => {
      child.kill('SIGTERM');
      if (!finished) { finished = true; reject(new Error('Local Docker command timed out')); }
    }, timeout);
    const collect = (stream, append) => stream.on('data', (chunk) => {
      append(chunk.toString());
      if (stdout.length + stderr.length > 8 * 1024 * 1024) child.kill('SIGTERM');
    });
    collect(child.stdout, (text) => { stdout += text; });
    collect(child.stderr, (text) => { stderr += text; });
    child.on('error', () => {
      clearTimeout(timer);
      if (!finished) { finished = true; reject(new Error('Unable to run local Docker client')); }
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (!finished) { finished = true; resolve({ code, stdout, stderr }); }
    });
    child.stdin.on('error', () => {});
    child.stdin.end(input);
  });
}

async function verifyContainer() {
  const format = '{"id":{{json .Id}},"name":{{json .Name}},"running":{{json .State.Running}},"labels":{{json .Config.Labels}}}';
  const response = await command(['--host', config.dockerHost, 'inspect', '--format', format, config.containerId]);
  requireCondition(response.code === 0, 'The explicitly selected fresh container is unavailable');
  const actual = JSON.parse(response.stdout.trim());
  requireCondition(actual.id === config.containerId, 'Fresh container ID mismatch');
  requireCondition(actual.name === `/${config.containerName}`, 'Fresh container name mismatch');
  requireCondition(actual.running === true, 'Fresh container is not running');
  for (const [name, value] of Object.entries(config.requiredContainerLabels)) {
    requireCondition(actual.labels?.[name] === value, 'Fresh container audit label mismatch');
  }
  verifiedContainer = true;
}

function sqlState(response) {
  return /(?:ERROR|FATAL):\s+([0-9A-Z]{5}):/.exec(response.stderr)?.[1] ?? null;
}

async function sql(database, statement, { transaction = false, maintenance = false } = {}) {
  requireCondition(database === 'postgres' || createdDatabases.has(database), 'Unapproved database target');
  const user = maintenance ? config.maintenanceUser : config.postgresUser;
  const args = ['--host', config.dockerHost, 'exec', '-i', '--user', 'postgres'];
  if (localPassword) args.push('--env', 'PGPASSWORD');
  args.push(config.containerId, 'env');
  // Empty PGSERVICE is still a selected libpq service. Unset selectors instead of
  // assigning empty strings, and never read a container user's credential files.
  for (const variable of ['PGHOSTADDR', 'PGSERVICE', 'PGSERVICEFILE', 'PGOPTIONS', 'PGHOST', 'PGPORT', 'PGUSER', 'PGDATABASE']) {
    args.push('-u', variable);
  }
  if (!localPassword) args.push('-u', 'PGPASSWORD');
  args.push('PGPASSFILE=/dev/null', 'psql', '-X', '-w', '--quiet', '--tuples-only', '--no-align',
    '--pset=pager=off', '--set=ON_ERROR_STOP=1', '--set=VERBOSITY=verbose', '--set=SHOW_CONTEXT=never',
    `--host=${config.postgresSocket}`, `--port=${config.postgresPort}`, `--username=${user}`, `--dbname=${database}`);
  if (transaction) args.push('--single-transaction');
  args.push('--file=-');
  return command(args, `set statement_timeout='45s';\nset lock_timeout='5s';\n${statement}\n`);
}

async function successfulSql(database, statement, options) {
  const response = await sql(database, statement, options);
  requireCondition(response.code === 0, `Local fixture SQL failed (SQLSTATE ${sqlState(response) ?? 'unavailable'})`);
  return response.stdout.trim();
}

async function queryJson(database, statement, options) {
  return JSON.parse(await successfulSql(database, statement, options));
}

function expectedFailure(response, state, message) {
  requireCondition(response.code !== 0, 'Expected local fixture failure was not raised');
  requireCondition(sqlState(response) === state, `Unexpected failure SQLSTATE: ${sqlState(response) ?? 'unavailable'}`);
  requireCondition(response.stderr.includes(message), 'Failure happened outside the intended injection point');
  return { sqlstate: state, intendedFailurePointMatched: true };
}

const fixtureSql = `
create schema auth;
create table auth.users (id uuid primary key, raw_user_meta_data jsonb);
create table auth.sessions (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  not_after timestamptz
);
create function auth.uid() returns uuid language sql stable as $$
  select (nullif(pg_catalog.current_setting('request.jwt.claims',true),'')::jsonb ->> 'sub')::uuid;
$$;
create function auth.jwt() returns jsonb language sql stable as $$
  select coalesce(nullif(pg_catalog.current_setting('request.jwt.claims',true),'')::jsonb,'{}'::jsonb);
$$;
create schema storage;
create table storage.buckets (
  id text primary key, name text not null, public boolean not null default false,
  file_size_limit bigint, allowed_mime_types text[]
);
create table storage.objects (
  id uuid primary key default pg_catalog.gen_random_uuid(),
  bucket_id text references storage.buckets(id), name text not null
);
create function storage.foldername(text) returns text[] language sql immutable as $$
  select (pg_catalog.string_to_array($1,'/'))[1:pg_catalog.array_length(pg_catalog.string_to_array($1,'/'),1)-1];
$$;
alter table storage.buckets enable row level security;
alter table storage.objects enable row level security;
grant usage on schema public,auth,storage to anon,authenticated,service_role;
grant usage on language plpgsql to authenticated;
alter default privileges for role postgres in schema public
  grant all on tables to anon,authenticated,service_role;
alter default privileges for role postgres in schema public
  grant all on functions to anon,authenticated,service_role;
insert into auth.users(id,raw_user_meta_data) values
 ('11111111-1111-4111-8111-111111111111','{"display_name":"Local SQL Fixture A"}'),
 ('22222222-2222-4222-8222-222222222222','{"display_name":"Local SQL Fixture B"}');
`;

const metadataSql = `
select pg_catalog.jsonb_build_object(
 'schemas',(select coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) from (
   select n.nspname,pg_catalog.pg_get_userbyid(n.nspowner) as owner,n.nspacl::text as acl
   from pg_catalog.pg_namespace n where n.nspname in ('public','app_private','supabase_migrations','auth','storage') order by n.nspname
 )t),
 'relations',(select coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) from (
   select n.nspname,c.relname,c.relkind,pg_catalog.pg_get_userbyid(c.relowner) as owner,
     c.relrowsecurity,c.relforcerowsecurity,c.relacl::text as acl
   from pg_catalog.pg_class c join pg_catalog.pg_namespace n on n.oid=c.relnamespace
   where n.nspname in ('public','app_private','supabase_migrations','auth','storage') order by n.nspname,c.relname
 )t),
 'constraints',(select coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) from (
   select n.nspname,c.relname,k.conname,k.contype,pg_catalog.pg_get_constraintdef(k.oid) as definition
   from pg_catalog.pg_constraint k join pg_catalog.pg_class c on c.oid=k.conrelid
   join pg_catalog.pg_namespace n on n.oid=c.relnamespace
   where n.nspname in ('public','app_private','supabase_migrations','auth','storage') order by n.nspname,c.relname,k.conname
 )t),
 'indexes',(select coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) from (
   select schemaname,tablename,indexname,indexdef from pg_catalog.pg_indexes
   where schemaname in ('public','app_private','supabase_migrations','auth','storage') order by schemaname,tablename,indexname
 )t),
 'functions',(select coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) from (
   select n.nspname,p.proname,pg_catalog.pg_get_function_identity_arguments(p.oid) as arguments,
     pg_catalog.pg_get_userbyid(p.proowner) as owner,p.prosecdef,p.proconfig,p.proacl::text as acl,
     pg_catalog.md5(pg_catalog.pg_get_functiondef(p.oid)) as definition_digest,
     exists(select 1 from pg_catalog.aclexplode(coalesce(p.proacl,pg_catalog.acldefault('f',p.proowner))) a
       where a.grantee=0 and a.privilege_type='EXECUTE') as public_execute,
     pg_catalog.has_function_privilege('anon',p.oid,'EXECUTE') as anon_execute,
     pg_catalog.has_function_privilege('authenticated',p.oid,'EXECUTE') as authenticated_execute,
     pg_catalog.has_function_privilege('service_role',p.oid,'EXECUTE') as service_role_execute
   from pg_catalog.pg_proc p join pg_catalog.pg_namespace n on n.oid=p.pronamespace
   where n.nspname in ('public','app_private','auth','storage') and p.prokind in ('f','p') order by n.nspname,p.proname,p.oid
 )t),
 'policies',(select coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) from (
   select schemaname,tablename,policyname,permissive,roles,cmd,qual,with_check from pg_catalog.pg_policies
   where schemaname in ('public','app_private','storage') order by schemaname,tablename,policyname
 )t),
 'triggers',(select coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) from (
   select n.nspname,c.relname,t.tgname,t.tgenabled,pg_catalog.pg_get_triggerdef(t.oid) as definition
   from pg_catalog.pg_trigger t join pg_catalog.pg_class c on c.oid=t.tgrelid
   join pg_catalog.pg_namespace n on n.oid=c.relnamespace
   where not t.tgisinternal and (n.nspname in ('public','app_private') or (n.nspname='auth' and c.relname='users'))
   order by n.nspname,c.relname,t.tgname
 )t),
 'default_acl',(select coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) from (
   select pg_catalog.pg_get_userbyid(d.defaclrole) as owner,n.nspname,d.defaclobjtype,d.defaclacl::text as acl
   from pg_catalog.pg_default_acl d left join pg_catalog.pg_namespace n on n.oid=d.defaclnamespace
   order by owner,n.nspname,d.defaclobjtype
 )t),
 'auth_user_count',(select count(*) from auth.users),
 'auth_users_digest',(select md5(coalesce(jsonb_agg(to_jsonb(u) order by u.id)::text,'[]')) from auth.users u),
 'auth_session_count',(select count(*) from auth.sessions),
 'storage_buckets',(select coalesce(jsonb_agg(to_jsonb(b) order by b.id),'[]'::jsonb) from storage.buckets b),
 'storage_object_count',(select count(*) from storage.objects),
 'history_exists',pg_catalog.to_regclass('supabase_migrations.schema_migrations') is not null
);`;

async function snapshot(database) {
  const metadata = await queryJson(database, metadataSql);
  const existing = appTables.filter((table) => metadata.relations.some((r) => `${r.nspname}.${r.relname}` === table && ['r', 'p'].includes(r.relkind)));
  const rows = {};
  if (existing.length) {
    const expressions = existing.map((table) => `${literal(table)},(select jsonb_build_object('count',count(*),'digest',md5(coalesce(jsonb_agg(to_jsonb(t) order by to_jsonb(t)::text)::text,'[]'))) from ${table} t)`);
    Object.assign(rows, await queryJson(database, `select jsonb_build_object(${expressions.join(',')});`));
  }
  const history = metadata.history_exists
    ? await queryJson(database, "select coalesce(jsonb_agg(to_jsonb(h) order by h.version),'[]'::jsonb) from supabase_migrations.schema_migrations h;")
    : [];
  return { metadata, rows, history };
}

function summarize(value) {
  const { metadata: m } = value;
  const isApp = (name) => ['public', 'app_private'].includes(name);
  return {
    fingerprint_sha256: digest(JSON.stringify(value)),
    appTables: m.relations.filter((r) => isApp(r.nspname) && ['r', 'p'].includes(r.relkind)).length,
    appFunctions: m.functions.filter((f) => isApp(f.nspname)).length,
    appIndexes: m.indexes.filter((i) => isApp(i.schemaname)).length,
    appConstraints: m.constraints.filter((c) => isApp(c.nspname)).length,
    customTriggers: m.triggers.length, policies: m.policies.length,
    appPrivateExists: m.schemas.some((s) => s.nspname === 'app_private'),
    authUserFixtureRows: m.auth_user_count, storageObjects: m.storage_object_count,
    bucketCount: m.storage_buckets.length, historyExists: m.history_exists,
    historyVersions: value.history.map((h) => h.version),
  };
}

async function createDatabase(suffix) {
  await verifyContainer();
  const name = `acl_audit_${config.runId.replaceAll(/[^a-z0-9]/gi, '').slice(0, 12).toLowerCase()}_${config.nonce}_${suffix}`;
  requireCondition(/^acl_audit_[a-z0-9_]+$/.test(name) && name.length <= 63, 'Invalid auxiliary database name');
  const exists = await queryJson('postgres', `select to_jsonb(exists(select 1 from pg_catalog.pg_database where datname=${literal(name)}));`, { maintenance: true });
  requireCondition(!exists, 'Refusing to reuse an existing auxiliary database');
  await successfulSql('postgres', `create database ${identifier(name)} with owner postgres template template0;`, { maintenance: true });
  const marker = `fitness-os-acl-fixture:${config.runId}:${config.nonce}:${suffix}`;
  createdDatabases.set(name, marker);
  await successfulSql('postgres', `comment on database ${identifier(name)} is ${literal(marker)};`, { maintenance: true });
  await successfulSql(name, fixtureSql, { transaction: true });
  return name;
}

async function createHistory(database, rejectVersion = false) {
  await successfulSql(database, `create schema supabase_migrations;
    create table supabase_migrations.schema_migrations (
      version text primary key, statements text[], name text
      ${rejectVersion ? `,constraint acl_audit_history_reject_version check (version <> '${migrationVersion}')` : ''}
    );`, { transaction: true });
}

const historyInsert = `insert into supabase_migrations.schema_migrations(version,name,statements)
  values ('${migrationVersion}','account_foundation',array['isolated migration fixture; not a CLI execution']);`;

async function runCase(id, label, action) {
  const started = Date.now();
  try {
    const evidence = await action();
    results.push({ id, label, status: 'PASS', durationMs: Date.now() - started, ...evidence });
  } catch (error) {
    results.push({ id, label, status: 'FAIL', durationMs: Date.now() - started, failure: safeFailure(error) });
  }
}

async function cleanup() {
  const outcomes = [];
  if (config.keepDatabases === true) return [...createdDatabases.keys()].map((database) => ({ database, status: 'RETAINED_BY_EXPLICIT_CONFIG' }));
  for (const [database, marker] of createdDatabases) {
    try {
      await verifyContainer();
      const actual = await queryJson('postgres', `select jsonb_build_object('owner',pg_get_userbyid(datdba),'marker',shobj_description(oid,'pg_database')) from pg_database where datname=${literal(database)};`, { maintenance: true });
      requireCondition(actual?.marker === marker && actual.owner === 'postgres', 'Auxiliary database cleanup marker/owner mismatch');
      await successfulSql('postgres', `drop database ${identifier(database)} with (force);`, { maintenance: true });
      outcomes.push({ database, status: 'REMOVED_OWN_MARKED_AUXILIARY_DATABASE' });
    } catch (error) { outcomes.push({ database, status: 'CLEANUP_FAILED', failure: safeFailure(error) }); }
  }
  return outcomes;
}

async function main() {
  const args = process.argv.slice(2);
  if (args.length === 1 && args[0] === '--help') {
    console.log('Usage: node tests/integration/acl-migration-rollback.mjs --config <private isolated-local-supabase-acl-audit JSON>');
    return;
  }
  requireCondition(args.length === 2 && args[0] === '--config', 'Explicit --config for the marked fresh local container is required');
  config = JSON.parse(await readFile(path.resolve(args[1]), 'utf8'));
  requireCondition(config.environment === 'isolated-local-supabase-acl-audit', 'Wrong isolated execution environment marker');
  requireCondition(typeof config.runId === 'string' && /^[a-zA-Z0-9_-]{6,64}$/.test(config.runId), 'Missing unique audit run marker');
  requireCondition(typeof config.dockerHost === 'string' && /^unix:\/\/\//.test(config.dockerHost), 'Only an explicit local Unix Docker socket is allowed');
  requireCondition(typeof config.containerId === 'string' && /^[a-f0-9]{64}$/.test(config.containerId), 'An exact full fresh container ID is required');
  requireCondition(typeof config.containerName === 'string' && config.containerName.includes('acl-audit') && config.containerName.includes(config.runId), 'Fresh container name must contain the audit marker');
  requireCondition(!config.expectedContainerName || config.expectedContainerName === config.containerName, 'Expected container name mismatch');
  requireCondition(config.requiredContainerLabels && Object.entries(config.requiredContainerLabels).length > 0, 'Exact fresh container labels are required');
  requireCondition(Object.values(config.requiredContainerLabels).some((v) => typeof v === 'string' && (v === config.runId || v.endsWith(`-${config.runId}`))), 'Container labels must carry the unique audit marker');
  requireCondition(config.database === 'postgres' && config.postgresUser === 'postgres', 'Fixture role/database must be postgres');
  config.maintenanceUser ??= 'postgres';
  requireCondition(['postgres', 'supabase_admin'].includes(config.maintenanceUser), 'Unapproved local maintenance role');
  config.postgresSocket ??= '/var/run/postgresql';
  config.postgresPort ??= 5432;
  requireCondition(['/var/run/postgresql', '/tmp'].includes(config.postgresSocket) && config.postgresPort === 5432, 'Only the explicit in-container Unix PostgreSQL socket is allowed');
  if (config.passwordEnv) {
    requireCondition(/^ACL_AUDIT_[A-Z0-9_]+$/.test(config.passwordEnv), 'Only audit-scoped private credential variables are permitted');
    localPassword = process.env[config.passwordEnv];
    requireCondition(Boolean(localPassword), 'Requested local audit credential binding is absent');
  }
  config.nonce = randomBytes(3).toString('hex');
  const privateDirectory = await realpath(path.join(root, '.private-test-artifacts'));
  requireCondition(typeof config.reportPath === 'string', 'An explicit ignored report path is required');
  reportFile = path.resolve(root, config.reportPath);
  requireCondition(path.relative(privateDirectory, reportFile).length > 0 && !path.relative(privateDirectory, reportFile).startsWith('..') && path.relative(privateDirectory, reportFile) !== '.', 'Report must remain under .private-test-artifacts');
  await mkdir(path.dirname(reportFile), { recursive: true });
  const reportParent = await realpath(path.dirname(reportFile));
  requireCondition(reportParent === privateDirectory || reportParent.startsWith(privateDirectory + path.sep), 'Report parent resolves outside the ignored directory');
  const candidate = await readFile(candidatePath, 'utf8');
  requireCondition(digest(await readFile(originalPath)) === originalHash, 'Original migration hash mismatch');
  requireCondition(digest(candidate) === candidateHash, 'Candidate migration hash mismatch');
  requireCondition(!config.candidateSha256 || config.candidateSha256 === candidateHash, 'Configured candidate hash mismatch');
  if (config.candidateSql) requireCondition(await realpath(config.candidateSql) === await realpath(candidatePath), 'Unapproved candidate source path');
  await verifyContainer();
  const preflight = await queryJson('postgres', `select jsonb_build_object(
    'postgresql_major',current_setting('server_version_num')::int / 10000,
    'role',current_user,
    'required_roles_present',(select count(*)=3 from pg_roles where rolname in ('anon','authenticated','service_role')));`);
  requireCondition(preflight.postgresql_major === 17 && preflight.role === 'postgres', 'Requires the fresh PostgreSQL 17 postgres role');
  requireCondition(preflight.required_roles_present, 'Required local API roles must already exist; this script does not modify roles');

  let successDatabase;
  await runCase('M1', 'Full candidate and history record commit in one external transaction', async () => {
    const database = await createDatabase('success');
    await createHistory(database);
    const before = await snapshot(database);
    await successfulSql(database, `${candidate}\n${historyInsert}`, { transaction: true });
    const after = await snapshot(database);
    const summary = summarize(after);
    assert.equal(summary.appTables, 9);
    assert.equal(summary.appFunctions, 8);
    assert.equal(summary.appIndexes, 15);
    assert.equal(summary.appConstraints, 44);
    assert.equal(summary.customTriggers, 5);
    assert.equal(summary.policies, 22);
    assert.equal(summary.bucketCount, 1);
    assert.deepEqual(summary.historyVersions, [migrationVersion]);
    assert.equal(after.rows['public.profiles'].count, 2);
    assert.equal(after.rows['public.user_preferences'].count, 2);
    for (const fn of after.metadata.functions.filter((f) => ['public', 'app_private'].includes(f.nspname))) {
      assert.equal(fn.owner, 'postgres');
      assert.equal(fn.prosecdef, true);
      assert.ok(fn.proconfig.includes('search_path=""'));
      assert.equal(fn.public_execute, false);
      assert.equal(fn.anon_execute, false);
      assert.equal(fn.service_role_execute, false);
      assert.equal(fn.authenticated_execute, fn.nspname === 'public');
    }
    successDatabase = database;
    return {
      database, before: summarize(before), after: summary,
      historyBootstrapOutsideBusinessTransaction: true,
      functionAclAssertions: 'all 8 checked with real PostgreSQL effective privileges',
      observedFunctionAclMatrix: after.metadata.functions
        .filter((f) => ['public', 'app_private'].includes(f.nspname))
        .map((f) => ({
          schema: f.nspname, name: f.proname, arguments: f.arguments,
          owner: f.owner, securityDefiner: f.prosecdef, configuration: f.proconfig,
          PUBLIC_EXECUTE: f.public_execute, anon_EXECUTE: f.anon_execute,
          authenticated_EXECUTE: f.authenticated_execute, service_role_EXECUTE: f.service_role_execute,
        })),
    };
  });

  await runCase('M2', 'Tail failure rolls back every candidate object and fixture data change', async () => {
    const database = await createDatabase('tail'); const before = await snapshot(database);
    const failure = expectedFailure(await sql(database, `${candidate}\nselect 1/0;`, { transaction: true }), '22012', 'division by zero');
    const after = await snapshot(database); assert.deepEqual(after, before);
    return { database, ...failure, before: summarize(before), after: summarize(after), logicalSnapshotRestored: true };
  });

  await runCase('M3', 'Late pre-existing Storage policy conflict rolls back earlier application DDL', async () => {
    const database = await createDatabase('storage');
    await successfulSql(database, 'create policy acl_audit_existing_policy on storage.objects for select to authenticated using (false);', { transaction: true });
    const before = await snapshot(database);
    const failure = expectedFailure(await sql(database, candidate, { transaction: true }), 'P0001', 'Storage objects already have policies');
    const after = await snapshot(database); assert.deepEqual(after, before);
    return { database, ...failure, before: summarize(before), after: summarize(after), logicalSnapshotRestored: true };
  });

  await runCase('M4', 'Non-postgres creator is rejected by the candidate guard', async () => {
    const database = await createDatabase('creator'); const before = await snapshot(database);
    const failure = expectedFailure(await sql(database, `set local role authenticated;\n${candidate}`, { transaction: true }), '42501', 'migration_creator_must_be_postgres');
    const after = await snapshot(database); assert.deepEqual(after, before);
    return { database, ...failure, before: summarize(before), after: summarize(after), logicalSnapshotRestored: true };
  });

  await runCase('M5', 'History-record failure rolls back business objects but preserves earlier ledger bootstrap', async () => {
    const database = await createDatabase('history'); await createHistory(database, true);
    const before = await snapshot(database);
    const failure = expectedFailure(await sql(database, `${candidate}\n${historyInsert}`, { transaction: true }), '23514', 'acl_audit_history_reject_version');
    const after = await snapshot(database); assert.deepEqual(after, before);
    assert.equal(after.metadata.history_exists, true); assert.equal(after.history.length, 0);
    return { database, ...failure, before: summarize(before), after: summarize(after), logicalSnapshotRestored: true, earlierHistoryStructureRetained: true, historyFailureIsSyntheticCheckConstraint: true };
  });

  await runCase('M6', 'Raw replay fails without altering committed structure, data or version', async () => {
    requireCondition(Boolean(successDatabase), 'The successful migration fixture is unavailable');
    const before = await snapshot(successDatabase);
    const failure = expectedFailure(await sql(successDatabase, `${candidate}\n${historyInsert}`, { transaction: true }), 'P0001', 'PHASE 2 migration conflict: public.profiles already exists');
    const after = await snapshot(successDatabase); assert.deepEqual(after, before);
    return { database: successDatabase, ...failure, before: summarize(before), after: summarize(after), committedStatePreserved: true };
  });

  const cleanupResults = await cleanup();
  const status = results.length === 6 && results.every((r) => r.status === 'PASS') && cleanupResults.every((r) => r.status !== 'CLEANUP_FAILED') ? 'PASS' : 'FAIL';
  const report = {
    status, suite: 'isolated-postgresql-migration-fixture', checkedAt: new Date().toISOString(),
    runId: config.runId, containerName: config.containerName, containerId: config.containerId,
    originalSha256: originalHash, candidateSha256: candidateHash,
    productionDatabaseAccessed: false, productionMigrationExecuted: false,
    supabaseCliExecuted: false, mainDatabaseBusinessTablesChanged: false, databaseRolesChanged: false,
    fixtureLimitations: ['Minimal SQL Auth/Storage compatibility schemas; not real GoTrue/Storage API', 'Two UUID fixture rows are not real Auth users', 'No Storage file binaries', 'External psql single-transaction wrapper; not an end-to-end Supabase CLI runner test', 'Logical snapshot equality is not a whole-database physical backup'],
    tests: results, cleanup: cleanupResults,
  };
  const tempReport = `${reportFile}.tmp-${process.pid}`;
  await writeFile(tempReport, JSON.stringify(report, null, 2) + '\n', { mode: 0o600 });
  await rename(tempReport, reportFile);
  console.log(JSON.stringify({ status, suite: report.suite, passedCases: results.filter((r) => r.status === 'PASS').length, totalCases: results.length, reportPath: reportFile, productionDatabaseAccessed: false }));
  if (status !== 'PASS') process.exitCode = 1;
}

try {
  await main();
} catch (error) {
  let cleanupResults = [];
  if (verifiedContainer && config) cleanupResults = await cleanup();
  const failure = { status: 'BLOCKED_OR_FAILED', suite: 'isolated-postgresql-migration-fixture', failure: safeFailure(error), productionDatabaseAccessed: false, completedTests: results, cleanup: cleanupResults };
  if (reportFile) await writeFile(reportFile, JSON.stringify(failure, null, 2) + '\n', { mode: 0o600 });
  console.error(JSON.stringify({ status: failure.status, failure: failure.failure, reportPath: reportFile ?? null, productionDatabaseAccessed: false }));
  process.exitCode = 1;
}
