import { defineConfig } from "vitest/config";
import { fileURLToPath } from "node:url";
export default defineConfig({
  resolve: { alias: {
    "@": fileURLToPath(new URL("./src", import.meta.url)),
    "server-only": fileURLToPath(new URL("./tests/helpers/server-only-empty.mjs", import.meta.url)),
  } },
  test: { include: ["tests/unit/**/*.test.ts"], environment: "node" },
});
