import { verifiedDownload } from "@/lib/account/media-reliability";
import { trustedClient, deleteOwnedMedia } from "@/lib/account/trusted-state";
import { z } from "zod";
import { accountError, dbError, enforceRateLimit, PRIVATE_HEADERS, requireAccount } from "@/lib/account/server";
import { privateJson, RequestError, requireTrustedOrigin } from "@/lib/security/request";
export const dynamic = "force-dynamic";
type Context = { params: Promise<{ id: string }> };
async function ownMedia(client: Awaited<ReturnType<typeof requireAccount>>["client"], userId: string, id: string) {
  if (!z.uuid().safeParse(id).success) throw new RequestError(404, "MEDIA_NOT_FOUND", "找不到该图片。");
  const { data, error } = await client.from("user_media").select("*").eq("id", id).eq("user_id", userId).maybeSingle();
  if (error) throw dbError(error);
  if (!data) throw new RequestError(404, "MEDIA_NOT_FOUND", "找不到该图片。");
  return data;
}
export async function GET(_request: Request, context: Context) {
  try {
    const { client, user } = await requireAccount();
    const media = await ownMedia(client, user.id, (await context.params).id);
    if (!["ready", "unavailable"].includes(media.status)) throw new RequestError(409, "MEDIA_NOT_READY", "图片尚未完成上传或正在清理。");
    const verified = await verifiedDownload(trustedClient(), user.id, media.id);
    return new Response(new Uint8Array(verified.bytes), { headers: { ...PRIVATE_HEADERS, "Content-Type": media.mime_type, "Content-Disposition": `attachment; filename="${media.id}.${media.mime_type === "image/jpeg" ? "jpg" : media.mime_type.split("/")[1]}"`, "Content-Security-Policy": "default-src 'none'; sandbox" } });
  } catch (error) { return accountError(error); }
}
export async function DELETE(request: Request, context: Context) {
  try {
    requireTrustedOrigin(request);
    const { client, user } = await requireAccount();
    await enforceRateLimit(client, "media");
    const media = await ownMedia(client, user.id, (await context.params).id);
    await deleteOwnedMedia(trustedClient(), user.id, media);
    return privateJson({ deleted: true });
  } catch (error) { return accountError(error); }
}
