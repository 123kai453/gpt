/** FUTURE isolated-local SDK suite. Never applies SQL. NOT RUN in the design-only task. */
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash, randomUUID } from 'node:crypto';
import { createClient } from '@supabase/supabase-js';
import sharp from 'sharp';
import { assertLocalAclAuditTarget, observeUserRows } from '../helpers/local-acl-observer.mjs';

const profilePath = process.env.FITNESS_ACL_AUDIT_CONFIG;
if (!profilePath || Object.keys(process.env).some((key) => key.startsWith('SUPABASE_') || key.startsWith('PG') || key.startsWith('POSTGRES_') || ['DATABASE_URL', 'DIRECT_URL'].includes(key))) throw new Error('Fresh local profile and sanitized child environment required; no requests made.');
await assertLocalAclAuditTarget(); // Exact Docker ID/name/labels, loopback URL and mode-0600 config.
const cfg = JSON.parse(readFileSync(profilePath, 'utf8'));
const candidate = new URL('../../supabase/reviews/20261103000100_account_foundation.trusted_state_proposed.sql', import.meta.url);
assert.equal(cfg.candidateSha256, createHash('sha256').update(readFileSync(candidate)).digest('hex'));
assert.equal(cfg.productionCredentialsLoaded, false);
assert.equal(cfg.environment, 'isolated-local-supabase-acl-audit');
assert.ok(['localhost', '127.0.0.1', '[::1]'].includes(new URL(cfg.apiUrl).hostname));
const origin = new URL(cfg.apiUrl).origin;
const localFetch = (input, init) => {
  const url = new URL(typeof input === 'string' ? input : input.url ?? input.toString());
  assert.equal(url.origin, origin, 'no cross-origin SDK requests');
  return fetch(input, { ...init, redirect: 'error' });
};
const options = { auth: { persistSession: false, autoRefreshToken: false }, global: { fetch: localFetch } };
const admin = createClient(cfg.apiUrl, cfg.serviceRoleKey, options);
const anon = createClient(cfg.apiUrl, cfg.anonKey, options);
const users = [];
const paths = [];
const checks = [];
function ok(result, label) { assert.equal(result.error, null, label); checks.push(label); return result.data; }
function denied(result, label) {
  assert.ok(result.error, label);
  assert.ok([400, 401, 403, 404, 406].includes(Number(result.status ?? result.error.statusCode ?? result.error.status)), label);
  checks.push(label);
}
function rejected(result, label) { assert.ok(result.error && ['22023', '42501', 'P0001'].includes(result.error.code), label); checks.push(label); }
const mediaRpc = (u, id, action, extra = {}) => admin.rpc('server_media_write', { p_owner: u.id, p_id: id, p_action: action, ...extra });
try {
  const existing = ok(await admin.auth.admin.listUsers({ page: 1, perPage: 2 }), 'fresh local Auth accessible');
  assert.equal(existing.users.length, 0, 'never reuse a stack with existing users');
  for (const email of ['user-a@example.invalid', 'user-b@example.invalid']) {
    const password = `LocalOnly!${randomUUID()}aA9`;
    const created = ok(await admin.auth.admin.createUser({ email, password, email_confirm: true }), 'local fictional Auth user created without mail');
    const client = createClient(cfg.apiUrl, cfg.anonKey, options);
    users.push({ id: created.user.id, client });
    ok(await client.auth.signInWithPassword({ email, password }), 'real local user session');
  }
  const [a, b] = users;
  for (const table of ['profiles', 'user_preferences', 'user_consents', 'sync_metadata', 'user_data_exports', 'user_media', 'account_deletion_jobs']) {
    denied(await admin.from(table).select('*'), `service role has no direct ${table} read`);
    denied(await anon.from(table).select('*'), `anon has no direct ${table} read`);
  }
  denied(await anon.rpc('server_deletion_progress', { p_owner: a.id, p_action: 'start' }), 'anon cannot invoke trusted deletion RPC');
  const bytes = await sharp({ create: { width: 2, height: 2, channels: 3, background: 'blue' } }).png().toBuffer();
  const digest = createHash('sha256').update(bytes).digest('hex');
  const id = randomUUID(); const key = `${a.id}/${id}.png`;
  denied(await a.client.from('user_media').insert({ id, user_id: a.id, object_path: key, mime_type: 'image/png', size_bytes: bytes.length, status: 'ready' }), 'authenticated cannot insert forged ready');
  denied(await a.client.rpc('server_media_write', { p_owner: a.id, p_id: id, p_action: 'begin', p_mime: 'image/png', p_size: bytes.length }), 'authenticated cannot invoke trusted RPC');
  ok(await mediaRpc(a, id, 'begin', { p_mime: 'image/png', p_size: bytes.length }), 'trusted pending reservation');
  denied(await a.client.from('user_media').update({ status: 'ready', content_sha256: digest, verified_at: new Date().toISOString() }).eq('id', id), 'authenticated cannot promote pending to ready');
  rejected(await mediaRpc(a, id, 'ready', { p_mime: 'image/png', p_size: bytes.length, p_digest: digest }), 'nonexistent object cannot become ready');
  denied(await a.client.storage.from('private-media').upload(key, bytes, { contentType: 'image/png' }), 'direct final upload denied');
  denied(await a.client.storage.from('private-media-staging').upload(key, bytes, { contentType: 'image/png' }), 'direct staging upload denied');
  for (const bucket of ['private-media-staging', 'private-media']) {
    paths.push([bucket, key]);
    ok(await admin.storage.from(bucket).upload(key, bytes, { contentType: 'image/png', upsert: false }), 'trusted object upload');
  }
  denied(await a.client.storage.from('private-media-staging').download(key), 'even owner cannot read staging');
  ok(await admin.storage.from('private-media-staging').remove([key]), 'trusted staging cleanup');
  ok(await mediaRpc(a, id, 'ready', { p_mime: 'image/png', p_size: bytes.length, p_digest: digest }), 'trusted valid object finalization');
  ok(await a.client.storage.from('private-media').download(key), 'A reads own ready binary');
  denied(await b.client.storage.from('private-media').download(key), 'B cannot read A binary');
  denied(await anon.storage.from('private-media').download(key), 'anon cannot read A binary');
  const forbiddenDelete = await b.client.storage.from('private-media').remove([key]);
  // Storage may reject or legitimately report zero visible deletions under RLS.
  if (forbiddenDelete.error) denied(forbiddenDelete, 'B delete rejected');
  else { assert.deepEqual(forbiddenDelete.data, []); checks.push('B delete affects no rows'); }
  ok(await a.client.storage.from('private-media').download(key), 'A binary survives B delete attempt');
  const exportId = randomUUID();
  denied(await a.client.from('user_data_exports').insert({ user_id: a.id, format: 'json', status: 'completed' }), 'authenticated cannot insert completed export');
  ok(await admin.rpc('server_export_write', { p_owner: a.id, p_id: exportId, p_action: 'begin', p_format: 'json' }), 'trusted export begin');
  denied(await a.client.from('user_data_exports').update({ status: 'completed', object_path: `${a.id}/forged.json`, error_code: 'FORGED', completed_at: new Date().toISOString() }).eq('id', exportId), 'authenticated cannot complete export');
  ok(await admin.rpc('server_export_write', { p_owner: a.id, p_id: exportId, p_action: 'complete' }), 'trusted export serialization completion');
  ok(await a.client.from('user_consents').insert({ user_id: a.id, scope: 'analytics', granted: true, policy_version: 'local-test-v1' }), 'consent append allowed');
  denied(await a.client.from('user_consents').update({ granted: false }).eq('user_id', a.id), 'consent history update denied');
  denied(await a.client.from('user_consents').delete().eq('user_id', a.id), 'consent history delete denied');
  denied(await a.client.from('sync_metadata').insert({ user_id: a.id, device_id: randomUUID(), last_seen_at: '2099-01-01T00:00:00Z' }), 'client cannot forge server sync time');
  const bId = randomUUID(); const bKey = `${b.id}/${bId}.png`;
  ok(await mediaRpc(b, bId, 'begin', { p_mime: 'image/png', p_size: bytes.length }), 'B reservation');
  paths.push(['private-media', bKey]);
  ok(await admin.storage.from('private-media').upload(bKey, bytes, { contentType: 'image/png' }), 'B object');
  ok(await mediaRpc(b, bId, 'ready', { p_mime: 'image/png', p_size: bytes.length, p_digest: digest }), 'B ready');
  ok(await a.client.rpc('request_account_deletion'), 'user deletion request remains available');
  denied(await a.client.from('account_deletion_jobs').update({ status: 'completed', attempts: 0, last_error: 'FORGED', completed_at: new Date().toISOString() }).eq('user_id', a.id), 'authenticated cannot forge deletion stage');
  const start = ok(await admin.rpc('server_deletion_progress', { p_owner: a.id, p_action: 'start' }), 'trusted delete start');
  rejected(await admin.rpc('server_deletion_progress', { p_owner: a.id, p_action: 'verify_auth' }), 'uncleared objects block Auth stage');
  ok(await admin.rpc('server_deletion_progress', { p_owner: a.id, p_action: 'fail' }), 'trusted failure persisted');
  const retry = ok(await admin.rpc('server_deletion_progress', { p_owner: a.id, p_action: 'start' }), 'trusted retry');
  assert.equal(retry.attempts, start.attempts + 1);
  ok(await admin.storage.from('private-media').remove([key]), 'remove only A object');
  ok(await admin.rpc('server_deletion_progress', { p_owner: a.id, p_action: 'verify_auth' }), 'empty owner prefix allows Auth stage');
  ok(await admin.auth.admin.deleteUser(a.id), 'Auth admin delete with SQL cascade');
  for (const table of ['profiles', 'user_preferences', 'user_consents', 'sync_metadata', 'user_data_exports', 'user_media', 'account_deletion_jobs', 'account_mutation_receipts', 'rate_limit_counters']) {
    assert.deepEqual(await observeUserRows(table, a.id), []);
    checks.push(`A physical ${table} rows cascaded (read-only local observer)`);
  }
  ok(await b.client.storage.from('private-media').download(bKey), 'B survives A deletion');
  const session = ok(await b.client.auth.getSession(), 'B session for revocation test').session;
  assert.ok(session?.access_token);
  const revoked = createClient(cfg.apiUrl, cfg.anonKey, { ...options, global: { fetch: localFetch, headers: { Authorization: `Bearer ${session.access_token}` } } });
  ok(await b.client.auth.signOut(), 'B local logout');
  denied(await revoked.storage.from('private-media').download(bKey), 'revoked B JWT cannot download after logout');
  console.log(JSON.stringify({ status: 'PASS', environment: 'ISOLATED_LOCAL_ONLY', candidateSha256: cfg.candidateSha256, assertions: checks.length, checks }));
} catch {
  console.error(JSON.stringify({ status: 'FAIL', environment: 'ISOLATED_LOCAL_ONLY', completedAssertions: checks.length, error: 'Sanitized failure; no credentials/SQL rows logged.' }));
  process.exitCode = 1;
} finally {
  for (const [bucket, key] of paths) await admin.storage.from(bucket).remove([key]);
  for (const u of users) await admin.auth.admin.deleteUser(u.id);
}
