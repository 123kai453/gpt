import { test, expect, type Page } from '@playwright/test';
import { createClient } from '@supabase/supabase-js';
import { randomUUID } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { assertLocalAclAuditTarget, isLocalAclAuditMode, observeUserRows } from '../helpers/local-acl-observer.mjs';
import { countLocalStorageBinaryFiles, setLocalStorageDeleteFault } from '../helpers/local-acl-faults.mjs';

const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/l9sAAAAASUVORK5CYII=', 'base64');

test('isolated ACL: application logout, failed Storage cleanup, safe retry and physical binary deletion', async ({ browser }) => {
  test.skip(!isLocalAclAuditMode(), 'Requires a verified fresh local ACL stack; never runs against hosted projects.');
  test.setTimeout(150_000);
  await assertLocalAclAuditTarget();
  const config = JSON.parse(readFileSync(process.env.FITNESS_ACL_AUDIT_CONFIG!, 'utf8'));
  const origin = new URL(process.env.NEXT_PUBLIC_APP_URL!).origin;
  expect(['127.0.0.1', 'localhost']).toContain(new URL(origin).hostname);
  const admin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const password = `Acl-local!${randomUUID()}Aa9`;
  const actors: { id: string; email: string }[] = [];
  const paths: string[] = [];
  const checks: string[] = [];
  const physicalCounts: Record<string, number> = {};
  const contexts = [];
  let faultInstalled = false;
  let status = 'failed';
  async function login(page: Page, email: string) {
    await page.goto(`${origin}/auth/sign-in`);
    const form = page.locator('.auth-form:visible');
    await expect(form.getByRole('button', { name: '登录账户', exact: true })).toBeEnabled();
    await form.getByRole('textbox', { name: '邮箱地址', exact: true }).fill(email);
    await form.locator('input[name="password"]').fill(password);
    await form.getByRole('button', { name: '登录账户', exact: true }).click();
    await expect(page).toHaveURL(/\/account\/profile$/);
  }
  try {
    for (const email of ['user-a@example.invalid', 'user-b@example.invalid']) {
      const result = await admin.auth.admin.createUser({ email, password, email_confirm: true });
      expect(result.error).toBeNull(); expect(result.data.user).not.toBeNull();
      actors.push({ id: result.data.user!.id, email });
    }
    const [a, b] = actors;
    const ca = await browser.newContext({ baseURL: origin }); contexts.push(ca);
    const cb = await browser.newContext({ baseURL: origin }); contexts.push(cb);
    const pa = await ca.newPage(), pb = await cb.newPage();
    await login(pa, a.email); await login(pb, b.email);
    const upload = async (context: typeof ca) => {
      const response = await context.request.post(`${origin}/api/account/media`, {
        headers: { Origin: origin }, multipart: { file: { name: 'audit-pixel.png', mimeType: 'image/png', buffer: png } },
      });
      expect(response.status()).toBe(201);
      const { media } = await response.json(); paths.push(media.object_path); return media;
    };
    const ma = await upload(ca), mb = await upload(cb);
    const own = await ca.request.get(`${origin}/api/account/media/${ma.id}`);
    expect(own.status()).toBe(200); expect(Buffer.compare(await own.body(), png)).toBe(0);
    expect(own.headers()['cache-control']).toContain('no-store');
    const anonymous = await browser.newContext({ baseURL: origin }); contexts.push(anonymous);
    expect((await anonymous.request.get(`${origin}/api/account/media/${ma.id}`)).status()).toBe(401);
    expect((await cb.request.get(`${origin}/api/account/media/${ma.id}`)).status()).toBe(404);
    expect((await cb.request.delete(`${origin}/api/account/media/${ma.id}`, { headers: { Origin: origin } })).status()).toBe(404);
    checks.push('A-D: authenticated own download, anonymous denial and B read/delete denial through actual application');

    const staleCookies = await ca.cookies();
    expect(staleCookies.some((cookie) => cookie.name.startsWith('sb-'))).toBe(true);
    await pa.goto(`${origin}/account/security`);
    await pa.getByRole('button', { name: '退出登录', exact: true }).click();
    await expect(pa).toHaveURL(/\/auth\/sign-in$/);
    expect((await ca.request.get(`${origin}/api/account/media/${ma.id}`)).status()).toBe(401);
    const stale = await browser.newContext({ baseURL: origin, storageState: { cookies: staleCookies, origins: [] } }); contexts.push(stale);
    expect((await stale.request.get(`${origin}/api/account/media/${ma.id}`)).status()).toBe(401);
    expect((await cb.request.get(`${origin}/api/account/media/${mb.id}`)).status()).toBe(200);
    checks.push('E: logout and replayed old application cookies cannot download private files; B unaffected');
    await login(pa, a.email);

    // No user_media row: include a nested orphan and a B-looking subfolder under A.
    const orphanPath = `${a.id}/orphan/${b.id}/audit-orphan-${randomUUID()}.png`;
    const orphan = await admin.storage.from('private-media').upload(orphanPath, png, { contentType: 'image/png' });
    expect(orphan.error).toBeNull(); paths.push(orphanPath);
    expect((await observeUserRows('user_media', a.id)).some((row) => row.object_path === orphanPath)).toBe(false);

    const beforeA = await countLocalStorageBinaryFiles(a.id), beforeB = await countLocalStorageBinaryFiles(b.id);
    expect(beforeA).toBeGreaterThan(0); expect(beforeB).toBeGreaterThan(0);
    physicalCounts.beforeA = beforeA; physicalCounts.beforeB = beforeB;
    await setLocalStorageDeleteFault(a.id, true); faultInstalled = true;
    try {
      const failed = await ca.request.post(`${origin}/api/account/delete`, { headers: { Origin: origin }, data: { confirmation: 'DELETE', password } });
      expect(failed.status()).toBe(503);
      expect((await admin.auth.admin.getUserById(a.id)).data.user?.id).toBe(a.id);
      const jobs = await observeUserRows('account_deletion_jobs', a.id);
      expect(jobs).toHaveLength(1); expect(jobs[0].status).toBe('failed'); expect(Number(jobs[0].attempts)).toBeGreaterThanOrEqual(1);
      expect((await cb.request.get(`${origin}/api/account/media/${mb.id}`)).status()).toBe(200);
      expect(await countLocalStorageBinaryFiles(b.id)).toBe(beforeB);
      checks.push('G: server-side Storage failure leaves A Auth/job retryable and B binary intact');
    } finally {
      await setLocalStorageDeleteFault(a.id, false); faultInstalled = false;
    }
    const retry = await ca.request.post(`${origin}/api/account/delete`, { headers: { Origin: origin }, data: { confirmation: 'DELETE', password } });
    expect(retry.status()).toBe(200); expect((await retry.json()).deleted).toBe(true);
    expect((await admin.auth.admin.getUserById(a.id)).data.user).toBeNull();
    for (const table of ['profiles', 'user_preferences', 'user_consents', 'sync_metadata', 'user_data_exports', 'user_media', 'account_deletion_jobs', 'account_mutation_receipts', 'rate_limit_counters'] as const) {
      expect(await observeUserRows(table, a.id)).toHaveLength(0);
    }
    expect((await admin.storage.from('private-media').download(ma.object_path)).data).toBeNull();
    physicalCounts.afterA = await countLocalStorageBinaryFiles(a.id);
    physicalCounts.afterB = await countLocalStorageBinaryFiles(b.id);
    expect(physicalCounts.afterA).toBe(0);
    expect(physicalCounts.afterB).toBe(beforeB);
    const bFile = await cb.request.get(`${origin}/api/account/media/${mb.id}`);
    expect(bFile.status()).toBe(200); expect(Buffer.compare(await bFile.body(), png)).toBe(0);
    expect((await admin.auth.admin.getUserById(b.id)).data.user?.id).toBe(b.id);
    checks.push('F-G: retry deletes A Auth, nine SQL relations, nested orphan and physical binary files; B survives unchanged');
    status = 'passed';
  } finally {
    if (faultInstalled && actors[0]) await setLocalStorageDeleteFault(actors[0].id, false);
    for (const context of contexts) await context.close();
    if (paths.length) await admin.storage.from('private-media').remove(paths);
    for (const actor of actors) await admin.auth.admin.deleteUser(actor.id, false);
    writeFileSync(join(config.runDirectory, 'backend-lifecycle-results.json'), JSON.stringify({ status, environment: config.environment, candidateSha256: config.candidateSha256, checks, noEmailSent: true, physicalBinaryVerification: status === 'passed', physicalCounts }, null, 2) + '\n', { mode: 0o600 });
  }
});
