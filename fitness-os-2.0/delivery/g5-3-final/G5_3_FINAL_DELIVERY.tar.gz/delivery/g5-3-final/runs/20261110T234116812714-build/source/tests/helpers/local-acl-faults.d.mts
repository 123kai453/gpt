export function setLocalStorageDeleteFault(userId: string, enabled: boolean, bucket?: "private-media" | "private-media-staging"): Promise<void>;
export function countLocalStorageBinaryFiles(userId: string): Promise<number>;
