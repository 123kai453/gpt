-- G5.3 FINAL REMEDIATION INITIAL CANDIDATE. Local validation only; hosted execution NOT approved.
-- Fresh target only after a NEW hosted snapshot; do not run alongside either old initial.
-- Backend patch and explicit service-role RPC boundary are required as one release.
-- REVIEW PROPOSAL ONLY. Not an approved or applied migration.
-- Preserve the original migrations file until the user explicitly approves this diff.
-- PHASE 2 account foundation. Intentionally abort on pre-existing application
-- tables instead of silently adopting or overwriting an unknown hosted schema.
-- Standalone review candidate owns its transaction. Do not nest it inside CLI wrappers.
begin;

do $$
declare table_name text;
begin
  if current_user <> 'postgres' then
    raise exception using errcode = '42501', message = 'migration_creator_must_be_postgres';
  end if;
  foreach table_name in array array[
    'profiles', 'user_preferences', 'user_consents', 'sync_metadata',
    'user_data_exports', 'user_media', 'account_deletion_jobs'
  ] loop
    if pg_catalog.to_regclass('public.' || table_name) is not null then
      raise exception 'PHASE 2 migration conflict: public.% already exists; review and migrate explicitly', table_name;
    end if;
  end loop;
  if pg_catalog.to_regnamespace('app_private') is not null then
    raise exception 'PHASE 2 migration conflict: app_private already exists; review explicitly';
  end if;
end;
$$;

create schema app_private;
revoke all on schema app_private from public, anon, authenticated, service_role;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text,
  display_name text not null default '',
  avatar_path text,
  version bigint not null default 1 check (version > 0),
  created_at timestamptz not null default pg_catalog.now(),
  updated_at timestamptz not null default pg_catalog.now(),
  deletion_requested_at timestamptz,
  constraint profiles_username_format check (
    username is null or username ~ '^[a-zA-Z0-9_]{3,24}$'
  ),
  constraint profiles_display_name_length check (pg_catalog.char_length(display_name) <= 64),
  constraint profiles_avatar_path_length check (avatar_path is null or pg_catalog.char_length(avatar_path) <= 300)
);
create unique index profiles_username_case_insensitive on public.profiles (pg_catalog.lower(username)) where username is not null;

create table public.user_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  theme text not null default 'dark' check (theme in ('dark', 'light')),
  language text not null default 'zh-CN' check (language in ('zh-CN', 'en')),
  unit_system text not null default 'metric' check (unit_system in ('metric', 'imperial')),
  timezone text not null default 'UTC' check (pg_catalog.char_length(timezone) between 1 and 100),
  notification_preferences jsonb not null default '{"email":false,"push":false}'::jsonb,
  version bigint not null default 1 check (version > 0),
  created_at timestamptz not null default pg_catalog.now(),
  updated_at timestamptz not null default pg_catalog.now(),
  constraint user_preferences_notifications check (
    pg_catalog.jsonb_typeof(notification_preferences) = 'object'
    and notification_preferences ?& array['email', 'push']
    and (notification_preferences - array['email', 'push']) = '{}'::jsonb
    and pg_catalog.jsonb_typeof(notification_preferences -> 'email') = 'boolean'
    and pg_catalog.jsonb_typeof(notification_preferences -> 'push') = 'boolean'
  )
);

create table public.user_consents (
  id uuid primary key default pg_catalog.gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  scope text not null check (scope in ('privacy_policy', 'terms', 'health_data', 'analytics', 'notifications')),
  granted boolean not null,
  policy_version text not null check (pg_catalog.char_length(policy_version) between 1 and 64),
  created_at timestamptz not null default pg_catalog.now()
);
create index user_consents_user_scope_created on public.user_consents (user_id, scope, created_at desc);

create table public.sync_metadata (
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  device_id uuid not null,
  last_seen_at timestamptz not null default pg_catalog.now(),
  last_synced_at timestamptz,
  primary key (user_id, device_id)
);

create table public.user_data_exports (
  id uuid primary key default pg_catalog.gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  format text not null check (format in ('json', 'csv')),
  status text not null default 'pending' check (status in ('pending', 'processing', 'completed', 'failed')),
  object_path text,
  error_code text check (error_code is null or error_code ~ '^[A-Z0-9_]{1,80}$'),
  created_at timestamptz not null default pg_catalog.now(),
  updated_at timestamptz not null default pg_catalog.now(),
  completed_at timestamptz,
  constraint user_data_exports_object_owner check (object_path is null),
  constraint export_completion check ((status = 'completed') = (completed_at is not null))
);
create index user_data_exports_user_created on public.user_data_exports(user_id, created_at desc);

create table public.user_media (
  id uuid primary key default pg_catalog.gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  object_path text not null unique,
  mime_type text not null check (mime_type in ('image/png', 'image/jpeg', 'image/webp')),
  size_bytes bigint not null check (size_bytes between 1 and 5242880),
  status text not null default 'pending' check (status in ('pending', 'processing', 'ready', 'unavailable', 'deleting', 'failed')),
  storage_object_id uuid,
  storage_object_version text,
  content_sha256 text check (content_sha256 is null or content_sha256 ~ '^[a-f0-9]{64}$'),
  verified_at timestamptz,
  constraint verified_ready check (status not in ('ready','unavailable') or (content_sha256 is not null and verified_at is not null)),
  created_at timestamptz not null default pg_catalog.now(),
  updated_at timestamptz not null default pg_catalog.now(),
  constraint user_media_object_path check (
    object_path = user_id::text || '/' || id::text || case mime_type
      when 'image/png' then '.png' when 'image/jpeg' then '.jpg' when 'image/webp' then '.webp' end
  )
);
create index user_media_user_created on public.user_media(user_id, created_at desc);

create table public.account_deletion_jobs (
  id uuid primary key default pg_catalog.gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  status text not null default 'requested' check (status in ('requested', 'deleting_storage', 'deleting_auth', 'completed', 'failed')),
  attempts integer not null default 0 check (attempts between 0 and 100000),
  last_error text check (last_error is null or last_error ~ '^[A-Z0-9_]{1,80}$'),
  created_at timestamptz not null default pg_catalog.now(),
  updated_at timestamptz not null default pg_catalog.now(),
  completed_at timestamptz
);

create table app_private.account_mutation_receipts (
  user_id uuid not null references auth.users(id) on delete cascade,
  mutation_id uuid not null,
  request_payload jsonb not null,
  result jsonb,
  created_at timestamptz not null default pg_catalog.now(),
  primary key (user_id, mutation_id)
);
create table app_private.rate_limit_counters (
  user_id uuid not null references auth.users(id) on delete cascade,
  action text not null,
  window_start timestamptz not null,
  count integer not null check (count > 0),
  primary key (user_id, action, window_start)
);

-- Every application table is private by default. No grants inherited from the
-- public schema defaults are retained, including for the anonymous API role.
alter table public.profiles enable row level security;
alter table public.user_preferences enable row level security;
alter table public.user_consents enable row level security;
alter table public.sync_metadata enable row level security;
alter table public.user_data_exports enable row level security;
alter table public.user_media enable row level security;
alter table public.account_deletion_jobs enable row level security;
alter table app_private.account_mutation_receipts enable row level security;
alter table app_private.rate_limit_counters enable row level security;
revoke all on public.profiles, public.user_preferences, public.user_consents,
  public.sync_metadata, public.user_data_exports, public.user_media,
  public.account_deletion_jobs from public, anon, authenticated, service_role;
revoke all on all tables in schema app_private from public, anon, authenticated, service_role;

-- Auth logout revokes refresh tokens immediately, while an already issued JWT
-- can otherwise remain valid until exp. Enforce the backing Auth session too.
create function public.has_current_auth_session() returns boolean
language plpgsql stable security definer set search_path = '' as $$
declare
  v_user uuid := auth.uid();
  v_session text := auth.jwt() ->> 'session_id';
begin
  if v_user is null or v_session is null or v_session !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' then
    return false;
  end if;
  return exists (select 1 from auth.sessions s where s.id = v_session::uuid
    and s.user_id = v_user and (s.not_after is null or s.not_after > pg_catalog.now()));
end;
$$;
revoke all on function public.has_current_auth_session() from public, anon, authenticated, service_role;
grant execute on function public.has_current_auth_session() to authenticated;

create function public.is_current_account_active() returns boolean
language sql stable security definer set search_path = '' as $$
  select public.has_current_auth_session() and exists (
    select 1 from public.profiles p
    where p.id = (select auth.uid()) and p.deletion_requested_at is null
  );
$$;
revoke all on function public.is_current_account_active() from public, anon, authenticated, service_role;
grant execute on function public.is_current_account_active() to authenticated;

grant select on public.profiles, public.user_preferences to authenticated;
create policy profiles_select_own on public.profiles for select to authenticated using (id = (select auth.uid()) and (select public.has_current_auth_session()));
create policy preferences_select_own on public.user_preferences for select to authenticated using (user_id = (select auth.uid()) and (select public.has_current_auth_session()));

grant select on public.user_consents to authenticated;
grant insert (user_id, scope, granted, policy_version) on public.user_consents to authenticated;
create policy consents_select_own on public.user_consents for select to authenticated using (user_id = (select auth.uid()) and (select public.has_current_auth_session()));
create policy consents_insert_own on public.user_consents for insert to authenticated with check (user_id = (select auth.uid()) and public.is_current_account_active());

grant select on public.sync_metadata, public.user_media, public.user_data_exports to authenticated;
create policy sync_select_own on public.sync_metadata for select to authenticated using (user_id = (select auth.uid()) and (select public.has_current_auth_session()));
create policy media_select_own on public.user_media for select to authenticated using (user_id = (select auth.uid()) and (select public.has_current_auth_session()));
create policy exports_select_own on public.user_data_exports for select to authenticated using (user_id = (select auth.uid()) and (select public.has_current_auth_session()));
grant select on public.account_deletion_jobs to authenticated;
create policy deletion_jobs_select_own on public.account_deletion_jobs for select to authenticated using (user_id = (select auth.uid()) and (select public.has_current_auth_session()));

-- Server-maintained timestamps and immutable ownership on writable resources.
create function app_private.guard_owned_resource() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'UPDATE' then
    if new.user_id is distinct from old.user_id or new.id is distinct from old.id or new.created_at is distinct from old.created_at then
      raise exception using errcode = '22023', message = 'immutable_resource_identity';
    end if;
    if tg_table_name = 'user_media' then
      if new.object_path is distinct from old.object_path or new.mime_type is distinct from old.mime_type or new.size_bytes is distinct from old.size_bytes then
        raise exception using errcode = '22023', message = 'immutable_media_metadata';
      end if;
    end if;
    new.updated_at := pg_catalog.clock_timestamp();
  else
    new.created_at := pg_catalog.clock_timestamp();
    new.updated_at := new.created_at;
  end if;
  return new;
end;
$$;
revoke all on function app_private.guard_owned_resource() from public, anon, authenticated, service_role;
create trigger media_guard before insert or update on public.user_media for each row execute function app_private.guard_owned_resource();
create trigger exports_guard before insert or update on public.user_data_exports for each row execute function app_private.guard_owned_resource();
create trigger deletion_jobs_guard before insert or update on public.account_deletion_jobs for each row execute function app_private.guard_owned_resource();

-- Serialize avatar cleanup with CAS mutations through the profile row lock.
-- A concurrent device cannot leave a reference to media being removed.
create function app_private.clear_removed_avatar() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'DELETE' then
    update public.profiles set avatar_path = null, version = version + 1,
      updated_at = pg_catalog.clock_timestamp()
      where id = old.user_id and avatar_path = old.object_path;
    return old;
  end if;
  if new.status not in ('ready','unavailable') then
    update public.profiles set avatar_path = null, version = version + 1,
      updated_at = pg_catalog.clock_timestamp()
      where id = old.user_id and avatar_path = old.object_path;
  end if;
  return new;
end;
$$;
revoke all on function app_private.clear_removed_avatar() from public, anon, authenticated, service_role;
create trigger media_clear_avatar before update or delete on public.user_media for each row execute function app_private.clear_removed_avatar();

create function app_private.create_account_defaults() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, display_name) values (new.id, case
    when pg_catalog.jsonb_typeof(new.raw_user_meta_data -> 'display_name') = 'string'
      then pg_catalog.left(pg_catalog.btrim(new.raw_user_meta_data ->> 'display_name'), 64)
    else '' end);
  insert into public.user_preferences (user_id) values (new.id);
  return new;
end;
$$;
revoke all on function app_private.create_account_defaults() from public, anon, authenticated, service_role;
create trigger fitness_os_account_defaults after insert on auth.users for each row execute function app_private.create_account_defaults();
-- Existing hosted Auth users also receive defaults, without changing Auth data.
insert into public.profiles (id, display_name) select id, case
  when pg_catalog.jsonb_typeof(raw_user_meta_data -> 'display_name') = 'string'
    then pg_catalog.left(pg_catalog.btrim(raw_user_meta_data ->> 'display_name'), 64)
  else '' end from auth.users;
insert into public.user_preferences (user_id) select id from auth.users;

create function public.consume_account_rate_limit(p_action text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_user uuid := auth.uid();
  v_limit integer;
  v_seconds integer;
  v_start timestamptz;
  v_count integer;
  v_now timestamptz := pg_catalog.clock_timestamp();
begin
  if v_user is null then raise exception using errcode = '42501', message = 'authentication_required'; end if;
  if not public.has_current_auth_session() then raise exception using errcode = '42501', message = 'session_revoked_or_expired'; end if;
  case p_action
    when 'mutation' then v_limit := 120; v_seconds := 60;
    when 'media' then v_limit := 30; v_seconds := 60;
    when 'consent' then v_limit := 30; v_seconds := 60;
    when 'export' then v_limit := 3; v_seconds := 3600;
    when 'delete' then v_limit := 3; v_seconds := 3600;
    else raise exception using errcode = '22023', message = 'invalid_rate_limit_action';
  end case;
  if not exists (select 1 from public.profiles where id = v_user) then
    raise exception using errcode = '42501', message = 'account_not_found';
  end if;
  v_start := pg_catalog.to_timestamp(pg_catalog.floor(extract(epoch from v_now) / v_seconds) * v_seconds);
  insert into app_private.rate_limit_counters as counter (user_id, action, window_start, count)
    values (v_user, p_action, v_start, 1)
    on conflict (user_id, action, window_start) do update set count = counter.count + 1
      where counter.count < v_limit
    returning count into v_count;
  return pg_catalog.jsonb_build_object(
    'allowed', v_count is not null,
    'retry_after', case when v_count is null then greatest(1, pg_catalog.ceil(extract(epoch from (v_start + pg_catalog.make_interval(secs => v_seconds) - v_now)))::integer) else 0 end
  );
end;
$$;
revoke all on function public.consume_account_rate_limit(text) from public, anon, authenticated, service_role;
grant execute on function public.consume_account_rate_limit(text) to authenticated;

create function public.apply_account_mutation(
  p_mutation_id uuid, p_device_id uuid, p_entity text, p_base_version bigint, p_patch jsonb
) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_user uuid := auth.uid();
  v_payload jsonb;
  v_receipt app_private.account_mutation_receipts%rowtype;
  v_profile public.profiles%rowtype;
  v_preferences public.user_preferences%rowtype;
  v_record jsonb;
  v_version bigint;
  v_result jsonb;
  v_rate jsonb;
  v_key text;
begin
  if v_user is null then raise exception using errcode = '42501', message = 'authentication_required'; end if;
  if not public.has_current_auth_session() then raise exception using errcode = '42501', message = 'session_revoked_or_expired'; end if;
  if p_mutation_id is null or p_device_id is null or p_base_version is null or p_base_version < 1
    or p_entity is null or p_entity not in ('profile', 'preferences')
    or p_patch is null or pg_catalog.jsonb_typeof(p_patch) <> 'object' or p_patch = '{}'::jsonb
    or pg_catalog.octet_length(p_patch::text) > 8192 then
    raise exception using errcode = '22023', message = 'invalid_mutation';
  end if;
  v_payload := pg_catalog.jsonb_build_object('device_id',p_device_id,'entity',p_entity,'base_version',p_base_version,'patch',p_patch);
  insert into app_private.account_mutation_receipts (user_id, mutation_id, request_payload)
    values (v_user, p_mutation_id, v_payload) on conflict (user_id, mutation_id) do nothing;
  select * into strict v_receipt from app_private.account_mutation_receipts
    where user_id = v_user and mutation_id = p_mutation_id for update;
  if v_receipt.request_payload <> v_payload then
    raise exception using errcode = '22023', message = 'mutation_id_reused_with_different_payload';
  end if;
  if v_receipt.result is not null then return v_receipt.result; end if;
  -- Locking the profile also serializes deletion requests against preference writes.
  select * into v_profile from public.profiles where id = v_user for update;
  if not found then raise exception using errcode = '42501', message = 'account_not_found'; end if;
  if v_profile.deletion_requested_at is not null then
    raise exception using errcode = '42501', message = 'account_deletion_in_progress';
  end if;
  v_rate := public.consume_account_rate_limit('mutation');
  if not (v_rate ->> 'allowed')::boolean then
    raise exception using errcode = 'P0001', message = 'rate_limit_exceeded', detail = v_rate::text;
  end if;
  for v_key in select pg_catalog.jsonb_object_keys(p_patch) loop
    if (p_entity = 'profile' and v_key not in ('username', 'display_name', 'avatar_path'))
      or (p_entity = 'preferences' and v_key not in ('theme', 'language', 'unit_system', 'timezone', 'notification_preferences')) then
      raise exception using errcode = '22023', message = 'unknown_mutation_field';
    end if;
  end loop;
  if p_entity = 'profile' then
    v_version := v_profile.version;
    if p_patch ? 'username' and not (
      p_patch -> 'username' = 'null'::jsonb or
      (pg_catalog.jsonb_typeof(p_patch -> 'username') = 'string' and (p_patch ->> 'username') ~ '^[a-zA-Z0-9_]{3,24}$')
    ) then raise exception using errcode = '22023', message = 'invalid_username'; end if;
    if p_patch ? 'display_name' and (pg_catalog.jsonb_typeof(p_patch -> 'display_name') <> 'string' or pg_catalog.char_length(p_patch ->> 'display_name') > 64) then
      raise exception using errcode = '22023', message = 'invalid_display_name';
    end if;
    if p_patch ? 'avatar_path' and not (
      p_patch -> 'avatar_path' = 'null'::jsonb or
      (pg_catalog.jsonb_typeof(p_patch -> 'avatar_path') = 'string' and pg_catalog.char_length(p_patch ->> 'avatar_path') <= 300 and exists (
        select 1 from public.user_media m where m.user_id = v_user and m.object_path = p_patch ->> 'avatar_path' and m.status = 'ready'
      ))
    ) then raise exception using errcode = '22023', message = 'invalid_avatar_path'; end if;
    if v_version = p_base_version then
      update public.profiles set
        username = case when p_patch ? 'username' then p_patch ->> 'username' else username end,
        display_name = case when p_patch ? 'display_name' then p_patch ->> 'display_name' else display_name end,
        avatar_path = case when p_patch ? 'avatar_path' then p_patch ->> 'avatar_path' else avatar_path end,
        version = version + 1, updated_at = pg_catalog.clock_timestamp()
      where id = v_user returning * into v_profile;
    end if;
    v_record := pg_catalog.to_jsonb(v_profile);
  else
    select * into strict v_preferences from public.user_preferences where user_id = v_user for update;
    v_version := v_preferences.version;
    if p_patch ? 'theme' and (pg_catalog.jsonb_typeof(p_patch -> 'theme') <> 'string' or p_patch ->> 'theme' not in ('dark', 'light')) then
      raise exception using errcode = '22023', message = 'invalid_theme';
    end if;
    if p_patch ? 'language' and (pg_catalog.jsonb_typeof(p_patch -> 'language') <> 'string' or p_patch ->> 'language' not in ('zh-CN', 'en')) then
      raise exception using errcode = '22023', message = 'invalid_language';
    end if;
    if p_patch ? 'unit_system' and (pg_catalog.jsonb_typeof(p_patch -> 'unit_system') <> 'string' or p_patch ->> 'unit_system' not in ('metric', 'imperial')) then
      raise exception using errcode = '22023', message = 'invalid_unit_system';
    end if;
    if p_patch ? 'timezone' and (pg_catalog.jsonb_typeof(p_patch -> 'timezone') <> 'string' or not exists (
      select 1 from pg_catalog.pg_timezone_names where name = p_patch ->> 'timezone'
    )) then raise exception using errcode = '22023', message = 'invalid_timezone'; end if;
    if p_patch ? 'notification_preferences' and not (
      pg_catalog.jsonb_typeof(p_patch -> 'notification_preferences') = 'object'
      and (p_patch -> 'notification_preferences') ?& array['email', 'push']
      and ((p_patch -> 'notification_preferences') - array['email', 'push']) = '{}'::jsonb
      and pg_catalog.jsonb_typeof(p_patch #> '{notification_preferences,email}') = 'boolean'
      and pg_catalog.jsonb_typeof(p_patch #> '{notification_preferences,push}') = 'boolean'
    ) then raise exception using errcode = '22023', message = 'invalid_notification_preferences'; end if;
    if v_version = p_base_version then
      update public.user_preferences set
        theme = case when p_patch ? 'theme' then p_patch ->> 'theme' else theme end,
        language = case when p_patch ? 'language' then p_patch ->> 'language' else language end,
        unit_system = case when p_patch ? 'unit_system' then p_patch ->> 'unit_system' else unit_system end,
        timezone = case when p_patch ? 'timezone' then p_patch ->> 'timezone' else timezone end,
        notification_preferences = case when p_patch ? 'notification_preferences' then p_patch -> 'notification_preferences' else notification_preferences end,
        version = version + 1, updated_at = pg_catalog.clock_timestamp()
      where user_id = v_user returning * into v_preferences;
    end if;
    v_record := pg_catalog.to_jsonb(v_preferences);
  end if;
  v_result := pg_catalog.jsonb_build_object(
    'status', case when v_version = p_base_version then 'applied' else 'conflict' end,
    'entity', p_entity, 'record', v_record, 'version', (v_record ->> 'version')::bigint, 'mutation_id', p_mutation_id
  );
  update app_private.account_mutation_receipts set result = v_result where user_id = v_user and mutation_id = p_mutation_id;
  insert into public.sync_metadata (user_id, device_id, last_seen_at, last_synced_at)
    values (v_user, p_device_id, pg_catalog.clock_timestamp(), case when v_version = p_base_version then pg_catalog.clock_timestamp() else null end)
    on conflict (user_id, device_id) do update set last_seen_at = excluded.last_seen_at,
      last_synced_at = case when v_version = p_base_version then excluded.last_synced_at else public.sync_metadata.last_synced_at end;
  return v_result;
end;
$$;
revoke all on function public.apply_account_mutation(uuid, uuid, text, bigint, jsonb) from public, anon, authenticated, service_role;
grant execute on function public.apply_account_mutation(uuid, uuid, text, bigint, jsonb) to authenticated;

create function public.request_account_deletion() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_user uuid := auth.uid();
  v_profile public.profiles%rowtype;
  v_job public.account_deletion_jobs%rowtype;
  v_rate jsonb;
begin
  if v_user is null then raise exception using errcode = '42501', message = 'authentication_required'; end if;
  if not public.has_current_auth_session() then raise exception using errcode = '42501', message = 'session_revoked_or_expired'; end if;
  select * into v_profile from public.profiles where id = v_user for update;
  if not found then raise exception using errcode = '42501', message = 'account_not_found'; end if;
  select * into v_job from public.account_deletion_jobs where user_id = v_user for update;
  if found then return pg_catalog.to_jsonb(v_job); end if;
  v_rate := public.consume_account_rate_limit('delete');
  if not (v_rate ->> 'allowed')::boolean then
    raise exception using errcode = 'P0001', message = 'rate_limit_exceeded', detail = v_rate::text;
  end if;
  update public.profiles set deletion_requested_at = pg_catalog.clock_timestamp(),
    updated_at = pg_catalog.clock_timestamp(), version = version + 1 where id = v_user;
  insert into public.account_deletion_jobs (user_id) values (v_user) returning * into v_job;
  return pg_catalog.to_jsonb(v_job);
end;
$$;
revoke all on function public.request_account_deletion() from public, anon, authenticated, service_role;
grant execute on function public.request_account_deletion() to authenticated;

-- Buckets are configuration, never public. Existing differently configured
-- buckets require human review, rather than an UPDATE that changes old data.
do $$
begin
  if not exists (select 1 from pg_catalog.pg_class where oid = 'storage.objects'::regclass and relrowsecurity)
    or not exists (select 1 from pg_catalog.pg_class where oid = 'storage.buckets'::regclass and relrowsecurity) then
    raise exception 'Storage RLS must already be enabled; candidate will not modify managed table settings';
  end if;
  if exists (select 1 from pg_catalog.pg_policy where polrelid = 'storage.objects'::regclass) then
    raise exception 'Storage objects already have policies; review existing policy OR-composition before applying PHASE 2';
  end if;
  if exists (select 1 from storage.buckets where id = 'private-media' and
    (public is distinct from false or file_size_limit is distinct from 5242880::bigint or allowed_mime_types is distinct from array['image/png','image/jpeg','image/webp']::text[])) then
    raise exception 'Storage bucket private-media exists with incompatible settings; review explicitly';
  end if;
  if exists (select 1 from storage.buckets where id = 'private-media-staging' and
    (public is distinct from false or file_size_limit is distinct from 5242880::bigint or allowed_mime_types is distinct from array['image/png','image/jpeg','image/webp']::text[])) then
    raise exception 'Staging bucket settings conflict';
  end if;
end;
$$;
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  values ('private-media', 'private-media', false, 5242880, array['image/png','image/jpeg','image/webp']) on conflict (id) do nothing;
create policy fitness_media_select_own on storage.objects for select to authenticated using (
  bucket_id = 'private-media' and (storage.foldername(name))[1] = (select auth.uid())::text
  and (select public.has_current_auth_session())
  and exists (select 1 from public.user_media m where m.user_id = (select auth.uid())
    and m.object_path = storage.objects.name and m.status = 'ready' and m.content_sha256 is not null)
);

-- Direct application-table rights remain revoked for service_role. The bounded
-- server functions below add only their own EXECUTE grants; Storage/Auth Admin
-- still require the existing privileged credential, strictly on the server.

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
 values ('private-media-staging','private-media-staging',false,5242880,array['image/png','image/jpeg','image/webp']) on conflict (id) do nothing;

-- These are the compatibility media/export/deletion operations.
-- G5.3 additionally grants ONLY the bounded reliability dispatcher below, never table DML.
-- No authenticated finalizer; auth.uid() is deliberately not the trust discriminator.
create function public.server_media_write(
 p_owner uuid, p_id uuid, p_action text, p_mime text default null,
 p_size bigint default null, p_digest text default null
) returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_profile public.profiles%rowtype; v_media public.user_media%rowtype; v_path text;
begin
 if (auth.jwt()->>'role') is distinct from 'service_role' then
  raise exception using errcode='42501',message='trusted_service_required'; end if;
 if p_owner is null or p_id is null or p_action is null or p_action not in ('begin','ready','failed','deleting','remove','inspect') then
  raise exception using errcode='22023',message='invalid_server_media_action'; end if;
 select * into v_profile from public.profiles where id=p_owner for update;
 if not found then raise exception using errcode='42501',message='account_not_found'; end if;
 if p_action in ('begin','ready') and v_profile.deletion_requested_at is not null then
  raise exception using errcode='42501',message='account_deletion_in_progress'; end if;
 if p_action='begin' then
  if p_mime is null or p_mime not in ('image/png','image/jpeg','image/webp') or p_size is null or p_size not between 1 and 5242880 then
   raise exception using errcode='22023',message='invalid_verified_media'; end if;
  v_path:=p_owner::text||'/'||p_id::text||case p_mime when 'image/png' then '.png' when 'image/jpeg' then '.jpg' else '.webp' end;
  if exists(select 1 from app_private.media_upload_jobs where media_id=p_id) or exists(select 1 from app_private.media_orphan_claims where object_path=v_path) then raise exception using errcode='22023',message='reserved_media_identity'; end if;
  insert into public.user_media(id,user_id,object_path,mime_type,size_bytes,status)
   values(p_id,p_owner,v_path,p_mime,p_size,'pending') returning * into v_media;
  return pg_catalog.to_jsonb(v_media);
 end if;
 select * into v_media from public.user_media where id=p_id and user_id=p_owner for update;
 if not found then
  if p_action='remove' then return '{"deleted":true}'::jsonb; end if;
  raise exception using errcode='42501',message='media_not_found';
 end if;
 if p_action='inspect' then return pg_catalog.to_jsonb(v_media); end if;
 if p_action='ready' then
  if v_media.status<>'pending' or p_digest is null or p_digest !~ '^[a-f0-9]{64}$' or p_size is distinct from v_media.size_bytes or p_mime is distinct from v_media.mime_type then
   raise exception using errcode='22023',message='invalid_media_finalization'; end if;
  if not exists(select 1 from storage.objects where bucket_id='private-media' and name=v_media.object_path) then
   raise exception using errcode='P0001',message='verified_object_missing'; end if;
  update public.user_media set status='ready',content_sha256=p_digest,verified_at=pg_catalog.clock_timestamp()
   where id=p_id and user_id=p_owner returning * into v_media;
 elsif p_action='failed' then
  if v_media.status<>'pending' then raise exception using errcode='22023',message='invalid_media_transition'; end if;
  if exists(select 1 from storage.objects where bucket_id in ('private-media','private-media-staging') and name=v_media.object_path) then
   raise exception using errcode='P0001',message='media_cleanup_required'; end if;
  update public.user_media set status='failed' where id=p_id and user_id=p_owner returning * into v_media;
 elsif p_action='deleting' then
  if v_media.status='pending' then raise exception using errcode='P0001',message='upload_still_pending'; end if;
  update public.user_media set status='deleting' where id=p_id and user_id=p_owner returning * into v_media;
 elsif p_action='remove' then
  if v_media.status='pending' then raise exception using errcode='P0001',message='upload_still_pending'; end if;
  if exists(select 1 from storage.objects where bucket_id in ('private-media','private-media-staging') and name=v_media.object_path) then
   raise exception using errcode='P0001',message='media_cleanup_required'; end if;
  delete from public.user_media where id=p_id and user_id=p_owner;
  return '{"deleted":true}'::jsonb;
 end if;
 return pg_catalog.to_jsonb(v_media);
end;
$$;
revoke all on function public.server_media_write(uuid,uuid,text,text,bigint,text) from public,anon,authenticated,service_role;
grant execute on function public.server_media_write(uuid,uuid,text,text,bigint,text) to service_role;

create function public.server_export_write(p_owner uuid,p_id uuid,p_action text,p_format text default null)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_profile public.profiles%rowtype; v_job public.user_data_exports%rowtype;
begin
 if (auth.jwt()->>'role') is distinct from 'service_role' then raise exception using errcode='42501',message='trusted_service_required'; end if;
 if p_owner is null or p_id is null or p_action is null or p_action not in ('begin','complete','fail') then
  raise exception using errcode='22023',message='invalid_server_export_action'; end if;
 select * into v_profile from public.profiles where id=p_owner for update;
 if not found then raise exception using errcode='42501',message='account_not_found'; end if;
 if p_action in ('begin','complete') and v_profile.deletion_requested_at is not null then
  raise exception using errcode='42501',message='account_deletion_in_progress'; end if;
 if p_action='begin' then
  if p_format is null or p_format not in ('json','csv') then raise exception using errcode='22023',message='invalid_export_format'; end if;
  insert into public.user_data_exports(id,user_id,format,status) values(p_id,p_owner,p_format,'processing') returning * into v_job;
 else
  select * into v_job from public.user_data_exports where id=p_id and user_id=p_owner for update;
  if not found or v_job.status<>'processing' then raise exception using errcode='22023',message='invalid_export_transition'; end if;
  update public.user_data_exports set status=case when p_action='complete' then 'completed' else 'failed' end,
   completed_at=case when p_action='complete' then pg_catalog.clock_timestamp() else null end,
   error_code=case when p_action='fail' then 'EXPORT_FAILED' else null end
   where id=p_id and user_id=p_owner returning * into v_job;
 end if;
 return pg_catalog.to_jsonb(v_job);
end;
$$;
revoke all on function public.server_export_write(uuid,uuid,text,text) from public,anon,authenticated,service_role;
grant execute on function public.server_export_write(uuid,uuid,text,text) to service_role;

create function public.server_deletion_progress(p_owner uuid,p_action text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_profile public.profiles%rowtype; v_job public.account_deletion_jobs%rowtype;
begin
 if (auth.jwt()->>'role') is distinct from 'service_role' then raise exception using errcode='42501',message='trusted_service_required'; end if;
 if p_owner is null or p_action is null or p_action not in ('start','verify_auth','fail') then
  raise exception using errcode='22023',message='invalid_deletion_action'; end if;
 select * into v_profile from public.profiles where id=p_owner for update;
 if not found or v_profile.deletion_requested_at is null then raise exception using errcode='42501',message='deletion_not_requested'; end if;
 select * into v_job from public.account_deletion_jobs where user_id=p_owner for update;
 if not found then raise exception using errcode='42501',message='deletion_job_missing'; end if;
 if p_action='start' then
  if v_job.attempts>=100000 then raise exception using errcode='P0001',message='deletion_retry_limit'; end if;
  update public.account_deletion_jobs set status='deleting_storage',attempts=attempts+1,last_error=null where user_id=p_owner returning * into v_job;
 elsif p_action='verify_auth' then
  if v_job.status<>'deleting_storage' then raise exception using errcode='22023',message='invalid_deletion_transition'; end if;
  if exists(select 1 from public.user_media where user_id=p_owner and status in ('pending','processing')) then
   raise exception using errcode='P0001',message='upload_still_pending'; end if;
  if exists(select 1 from storage.objects where bucket_id in ('private-media','private-media-staging') and pg_catalog.split_part(name,'/',1)=p_owner::text) then
   raise exception using errcode='P0001',message='storage_cleanup_required'; end if;
  update public.account_deletion_jobs set status='deleting_auth' where user_id=p_owner returning * into v_job;
 else
  update public.account_deletion_jobs set status='failed',last_error='DELETE_RETRY_REQUIRED' where user_id=p_owner returning * into v_job;
 end if;
 return pg_catalog.to_jsonb(v_job);
end;
$$;
revoke all on function public.server_deletion_progress(uuid,text) from public,anon,authenticated,service_role;
grant execute on function public.server_deletion_progress(uuid,text) to service_role;

-- Review fragment, NOT a standalone migration. Included in the unique G5.3 initial.
do $$ begin
 if not exists(select 1 from pg_catalog.pg_attribute where attrelid='storage.objects'::regclass and attname='version' and not attisdropped) then
  raise exception 'Storage object version column is required; review platform compatibility';
 end if;
end; $$;
create table app_private.media_upload_jobs (
 media_id uuid primary key, -- Durable request tombstone survives explicit media deletion.
 user_id uuid not null references auth.users(id) on delete cascade,
 request_id uuid not null,
 request_sha256 text not null check(request_sha256 ~ '^[a-f0-9]{64}$'),
 expected_sha256 text not null check(expected_sha256 ~ '^[a-f0-9]{64}$'),
 status text not null default 'pending' check(status in ('pending','processing','ready','failed')),
 attempts integer not null default 0 check(attempts between 0 and 3),
 lease_token uuid, lease_until timestamptz, next_attempt_at timestamptz not null default pg_catalog.clock_timestamp(),
 phase text not null default 'reserved' check(phase in ('reserved','writing','verifying','ready','failed')),
 last_error text check(last_error is null or last_error ~ '^[A-Z0-9_]{1,64}$'),
 created_at timestamptz not null default pg_catalog.clock_timestamp(),
 updated_at timestamptz not null default pg_catalog.clock_timestamp(),
 unique(user_id,request_id)
);
create index media_upload_jobs_due on app_private.media_upload_jobs(status,next_attempt_at,lease_until);
create table app_private.media_job_events (
 id bigint generated always as identity primary key,
 media_id uuid not null, -- Audit survives media deletion, but cascades with Auth user.
 user_id uuid not null references auth.users(id) on delete cascade,
 event text not null check(event in ('reserved','claimed','ready','retry','failed','invalidated','cancelled')),
 code text check(code is null or code ~ '^[A-Z0-9_]{1,64}$'),
 observed_at timestamptz not null default pg_catalog.clock_timestamp()
);
create table app_private.media_orphan_claims (
 bucket_id text not null check(bucket_id in ('private-media','private-media-staging')),
 object_path text not null, object_id uuid not null, object_version text,
 lease_token uuid not null, lease_until timestamptz not null,
 attempts integer not null default 0 check(attempts>=0),
 next_attempt_at timestamptz not null default pg_catalog.clock_timestamp(),
 last_error text check(last_error is null or last_error='STORAGE_DELETE_FAILED'),
 updated_at timestamptz not null default pg_catalog.clock_timestamp(),
 primary key(bucket_id,object_path)
);
alter table app_private.media_upload_jobs enable row level security;
alter table app_private.media_job_events enable row level security;
alter table app_private.media_orphan_claims enable row level security;
revoke all on all tables in schema app_private from public,anon,authenticated,service_role;
revoke all on all sequences in schema app_private from public,anon,authenticated,service_role;

-- Durable bounded sweep progress is global operational state, not a client cursor.
create table app_private.media_maintenance_state (
 name text primary key check(name in ('due','ready','orphan','account_cleanup','media_delete')),
 cursor_id uuid, revision bigint not null default 0 check(revision>=0),
 updated_at timestamptz not null default pg_catalog.clock_timestamp()
);
insert into app_private.media_maintenance_state(name) values('due'),('ready'),('orphan'),('account_cleanup'),('media_delete');
-- Only the trusted API, AFTER password reauthentication, may authorize automatic deletion.
-- A user's request_account_deletion() alone never grants this authorization.
create table app_private.account_cleanup_authorizations (
 user_id uuid primary key references auth.users(id) on delete cascade,
 job_id uuid not null references public.account_deletion_jobs(id) on delete cascade,
 authorized_at timestamptz not null default pg_catalog.clock_timestamp(),
 expires_at timestamptz not null,
 attempts integer not null default 0 check(attempts between 0 and 3),
 lease_token uuid, lease_until timestamptz,
 next_attempt_at timestamptz not null default pg_catalog.clock_timestamp(),
 last_error text check(last_error is null or last_error='DELETE_RETRY_REQUIRED'),
 updated_at timestamptz not null default pg_catalog.clock_timestamp()
);
alter table app_private.media_maintenance_state enable row level security;
alter table app_private.account_cleanup_authorizations enable row level security;
revoke all on app_private.media_maintenance_state,app_private.account_cleanup_authorizations from public,anon,authenticated,service_role;

create function app_private.media_event(p_media uuid,p_owner uuid,p_event text,p_code text default null)
returns void language sql security definer set search_path='' as $$
 insert into app_private.media_job_events(media_id,user_id,event,code) values(p_media,p_owner,p_event,p_code);
$$;
revoke all on function app_private.media_event(uuid,uuid,text,text) from public,anon,authenticated,service_role;

create function public.server_media_reliability(
 p_action text,p_owner uuid default null,p_media uuid default null,p_request uuid default null,
 p_lease uuid default null,p_data jsonb default '{}'::jsonb
) returns jsonb language plpgsql security definer set search_path='' as $$
declare
 v_profile public.profiles%rowtype; v_media public.user_media%rowtype;
 v_job app_private.media_upload_jobs%rowtype; v_obj storage.objects%rowtype;
 v_claim app_private.media_orphan_claims%rowtype; v_bucket text; v_key text;
 v_active boolean:=false; v_id uuid; v_now timestamptz:=pg_catalog.clock_timestamp(); v_code text;
 v_auth app_private.account_cleanup_authorizations%rowtype; v_name text;
begin
 if (auth.jwt()->>'role') is distinct from 'service_role' then raise exception using errcode='42501',message='trusted_service_required'; end if;
 if p_action is null or p_data is null or pg_catalog.jsonb_typeof(p_data)<>'object' or pg_catalog.octet_length(p_data::text)>4096 then
  raise exception using errcode='22023',message='invalid_reliability_request'; end if;
 if p_action='scan_state' then
  return (select pg_catalog.jsonb_object_agg(name,pg_catalog.jsonb_build_object('cursor',cursor_id,'revision',revision)) from app_private.media_maintenance_state);
 elsif p_action='scan_advance' then
  v_name:=p_data->>'kind';
  if v_name is null or v_name not in ('due','ready','orphan','account_cleanup','media_delete') or p_data->>'revision' is null then raise exception using errcode='22023',message='invalid_sweep_cursor'; end if;
  update app_private.media_maintenance_state set cursor_id=(p_data->>'after')::uuid,revision=revision+1,updated_at=v_now
   where name=v_name and revision=(p_data->>'revision')::bigint;
  return pg_catalog.jsonb_build_object('advanced',found);
 elsif p_action='account_cleanup_due' then
  return coalesce((select pg_catalog.jsonb_agg(pg_catalog.to_jsonb(q)) from (
   select a.user_id from app_private.account_cleanup_authorizations a
   where a.expires_at>v_now and a.attempts<3 and a.next_attempt_at<=v_now and (a.lease_until is null or a.lease_until<=v_now)
    and (p_data->>'after' is null or a.user_id>(p_data->>'after')::uuid) order by a.user_id limit 11) q),'[]'::jsonb);
 elsif p_action='deleting_list' then
  return coalesce((select pg_catalog.jsonb_agg(pg_catalog.to_jsonb(q)) from (
   select id,user_id,object_path from public.user_media where status='deleting'
    and (p_data->>'after' is null or id>(p_data->>'after')::uuid) order by id limit 11) q),'[]'::jsonb);
 elsif p_action='due' then
  return coalesce((select pg_catalog.jsonb_agg(pg_catalog.to_jsonb(q)) from (
   select media_id,user_id from app_private.media_upload_jobs
   where (p_owner is null or user_id=p_owner) and (p_data->>'after' is null or media_id>(p_data->>'after')::uuid) and
    ((status='pending' and next_attempt_at<=v_now and (attempts>0 or created_at<=v_now-interval '10 seconds')) or (status='processing' and lease_until<=v_now))
   order by media_id limit 11) q),'[]'::jsonb);
 elsif p_action='ready_list' then
  return coalesce((select pg_catalog.jsonb_agg(pg_catalog.to_jsonb(q)) from (
   select * from public.user_media where status in ('ready','unavailable') and (p_owner is null or user_id=p_owner)
    and (p_data->>'after' is null or id>(p_data->>'after')::uuid) order by id limit 11) q),'[]'::jsonb);
 elsif p_action='orphan_list' then
  return coalesce((select pg_catalog.jsonb_agg(pg_catalog.to_jsonb(q)) from (
   select o.bucket_id,o.name,o.id,to_jsonb(o)->>'version' as version from storage.objects o
   where o.bucket_id in ('private-media','private-media-staging')
    and o.name ~ '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\.(png|jpg|webp)$'
    and (p_owner is null or pg_catalog.split_part(o.name,'/',1)=p_owner::text)
    and (p_data->>'after' is null or o.id>(p_data->>'after')::uuid)
    and not exists(select 1 from public.user_media m where m.object_path=o.name)
    and not exists(select 1 from app_private.media_upload_jobs j where j.media_id=pg_catalog.split_part(pg_catalog.split_part(o.name,'/',2),'.',1)::uuid and j.status in ('pending','processing'))
   union all
   select c.bucket_id,c.object_path,c.object_id,c.object_version from app_private.media_orphan_claims c
   where not exists(select 1 from storage.objects o where o.bucket_id=c.bucket_id and o.name=c.object_path)
    and not exists(select 1 from public.user_media m where m.object_path=c.object_path)
    and (p_owner is null or pg_catalog.split_part(c.object_path,'/',1)=p_owner::text)
    and (p_data->>'after' is null or c.object_id>(p_data->>'after')::uuid)
   order by id limit 11) q),'[]'::jsonb);
 elsif p_action in ('orphan_claim','orphan_done','orphan_retry') then
  v_bucket:=p_data->>'bucket';v_key:=p_data->>'key';
  if v_bucket not in ('private-media','private-media-staging') or v_key is null
   or v_key !~ '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\.(png|jpg|webp)$' then
   raise exception using errcode='22023',message='unsafe_orphan_key'; end if;
  perform 1 from public.profiles where id=pg_catalog.split_part(v_key,'/',1)::uuid for update;
  if exists(select 1 from public.user_media where object_path=v_key) or exists(select 1 from app_private.media_upload_jobs where media_id=pg_catalog.split_part(pg_catalog.split_part(v_key,'/',2),'.',1)::uuid and status in ('pending','processing')) then return '{"claimed":false}'::jsonb; end if;
  select * into v_claim from app_private.media_orphan_claims where bucket_id=v_bucket and object_path=v_key for update;
  v_now:=pg_catalog.clock_timestamp();
  if p_action='orphan_retry' then
   if v_claim.lease_token is not distinct from p_lease then update app_private.media_orphan_claims set lease_until=v_now,last_error='STORAGE_DELETE_FAILED',next_attempt_at=v_now+pg_catalog.make_interval(secs=>least(300,pg_catalog.power(2,least(8,attempts)))::integer),updated_at=v_now where bucket_id=v_bucket and object_path=v_key; end if;
   return '{"deferred":true}'::jsonb;
  end if;
  if p_action='orphan_done' then
   if v_claim.lease_token is distinct from p_lease then return '{"done":false}'::jsonb; end if;
   if exists(select 1 from storage.objects where bucket_id=v_bucket and name=v_key) then return '{"done":false}'::jsonb; end if;
   delete from app_private.media_orphan_claims where bucket_id=v_bucket and object_path=v_key;
   return '{"done":true}'::jsonb;
  end if;
  if found and (v_claim.lease_until>v_now or v_claim.next_attempt_at>v_now) then return '{"claimed":false}'::jsonb; end if;
  select * into v_obj from storage.objects where bucket_id=v_bucket and name=v_key;
  if not found then
   if v_claim.object_id::text is distinct from p_data->>'id' or v_claim.object_version is distinct from p_data->>'version' then return '{"claimed":false}'::jsonb; end if;
   update app_private.media_orphan_claims set lease_token=pg_catalog.gen_random_uuid(),lease_until=v_now+interval '30 seconds',attempts=attempts+1,updated_at=v_now where bucket_id=v_bucket and object_path=v_key returning * into v_claim;
   return pg_catalog.to_jsonb(v_claim)||'{"claimed":true}'::jsonb;
  end if;
  if v_obj.id::text is distinct from p_data->>'id' or (to_jsonb(v_obj)->>'version') is distinct from p_data->>'version' then return '{"claimed":false}'::jsonb; end if;
  insert into app_private.media_orphan_claims(bucket_id,object_path,object_id,object_version,lease_token,lease_until,attempts)
   values(v_bucket,v_key,v_obj.id,to_jsonb(v_obj)->>'version',pg_catalog.gen_random_uuid(),v_now+interval '30 seconds',1)
   on conflict(bucket_id,object_path) do update set object_id=excluded.object_id,object_version=excluded.object_version,lease_token=excluded.lease_token,lease_until=excluded.lease_until,attempts=app_private.media_orphan_claims.attempts+1,updated_at=v_now returning * into v_claim;
  return pg_catalog.to_jsonb(v_claim)||'{"claimed":true}'::jsonb;
 end if;
 if p_owner is null then raise exception using errcode='22023',message='owner_required'; end if;
 select * into v_profile from public.profiles where id=p_owner for update;
 if not found then raise exception using errcode='42501',message='account_not_found'; end if;
 v_now:=pg_catalog.clock_timestamp(); -- Refresh AFTER waiting for the owner lock.
 if p_action='account_cleanup_authorize' then
  if v_profile.deletion_requested_at is null or not exists(select 1 from public.account_deletion_jobs where id=p_request and user_id=p_owner) then
   raise exception using errcode='42501',message='deletion_not_requested'; end if;
  insert into app_private.account_cleanup_authorizations(user_id,job_id,expires_at)
   values(p_owner,p_request,v_now+interval '1 hour')
   on conflict(user_id) do update set authorized_at=v_now,expires_at=v_now+interval '1 hour',attempts=0,next_attempt_at=v_now,last_error=null,updated_at=v_now
   where app_private.account_cleanup_authorizations.lease_until is null or app_private.account_cleanup_authorizations.lease_until<=v_now;
  return '{"authorized":true}'::jsonb;
 elsif p_action in ('account_cleanup_claim','account_cleanup_retry') then
  select * into v_auth from app_private.account_cleanup_authorizations where user_id=p_owner for update;
  v_now:=pg_catalog.clock_timestamp();
  if not found or v_auth.expires_at<=v_now then return '{"claimed":false}'::jsonb; end if;
  if p_action='account_cleanup_retry' then
   if v_auth.lease_token is distinct from p_lease then raise exception using errcode='42501',message='stale_cleanup_lease'; end if;
   update app_private.account_cleanup_authorizations set lease_token=null,lease_until=null,last_error='DELETE_RETRY_REQUIRED',
    next_attempt_at=v_now+pg_catalog.make_interval(secs=>pg_catalog.power(2,attempts)::integer),updated_at=v_now where user_id=p_owner;
   return '{"deferred":true}'::jsonb;
  end if;
  if v_auth.attempts>=3 or v_auth.next_attempt_at>v_now or v_auth.lease_until>v_now then return '{"claimed":false}'::jsonb; end if;
  update app_private.account_cleanup_authorizations set attempts=attempts+1,lease_token=pg_catalog.gen_random_uuid(),lease_until=v_now+interval '60 seconds',updated_at=v_now
   where user_id=p_owner returning * into v_auth;
  return pg_catalog.jsonb_build_object('claimed',true,'lease_token',v_auth.lease_token);
 end if;
 if p_action='cancel_account' then
  if v_profile.deletion_requested_at is null then raise exception using errcode='42501',message='deletion_not_requested'; end if;
  for v_job in select * from app_private.media_upload_jobs where user_id=p_owner and status in ('pending','processing') order by media_id for update loop
   if v_job.status='processing' and v_job.lease_until>v_now then v_active:=true; continue; end if;
   update app_private.media_upload_jobs set status='failed',lease_token=null,lease_until=null,last_error='ACCOUNT_DELETING',updated_at=v_now where media_id=v_job.media_id;
   update public.user_media set status='failed' where id=v_job.media_id;
   perform app_private.media_event(v_job.media_id,p_owner,'cancelled','ACCOUNT_DELETING');
  end loop;
  return pg_catalog.jsonb_build_object('cancelled',not v_active,'active',v_active);
 end if;
 if p_action='reserve' then
  if v_profile.deletion_requested_at is not null then raise exception using errcode='42501',message='account_deletion_in_progress'; end if;
  if p_request is null or coalesce(p_data->>'request_sha','') !~ '^[a-f0-9]{64}$' or coalesce(p_data->>'expected_sha','') !~ '^[a-f0-9]{64}$'
   or coalesce(p_data->>'mime','')<>'image/png' or coalesce((p_data->>'size')::bigint,0) not between 1 and 5242880 then
   raise exception using errcode='22023',message='invalid_upload_intent'; end if;
  select * into v_job from app_private.media_upload_jobs where user_id=p_owner and request_id=p_request for update;
  if found then
   if v_job.request_sha256<>p_data->>'request_sha' or v_job.expected_sha256<>p_data->>'expected_sha' then
    raise exception using errcode='22023',message='idempotency_conflict'; end if;
  else
   v_id:=pg_catalog.gen_random_uuid();
   insert into public.user_media(id,user_id,object_path,mime_type,size_bytes,status)
    values(v_id,p_owner,p_owner::text||'/'||v_id::text||'.png','image/png',(p_data->>'size')::bigint,'pending');
   insert into app_private.media_upload_jobs(media_id,user_id,request_id,request_sha256,expected_sha256)
    values(v_id,p_owner,p_request,p_data->>'request_sha',p_data->>'expected_sha') returning * into v_job;
   perform app_private.media_event(v_id,p_owner,'reserved');
  end if;
  p_media:=v_job.media_id;
 end if;
 select * into v_media from public.user_media where id=p_media and user_id=p_owner for update;
 if not found then raise exception using errcode='22023',message='idempotency_deleted'; end if;
 select * into v_job from app_private.media_upload_jobs where media_id=p_media and user_id=p_owner for update;
 if p_action in ('reserve','probe') then
  return pg_catalog.jsonb_build_object('media',pg_catalog.to_jsonb(v_media),'job',case when v_job.media_id is null then null else pg_catalog.to_jsonb(v_job) end,
   'final',(select pg_catalog.jsonb_build_object('id',o.id,'version',to_jsonb(o)->>'version','metadata',o.metadata) from storage.objects o where o.bucket_id='private-media' and o.name=v_media.object_path),
   'staging',(select pg_catalog.jsonb_build_object('id',o.id,'version',to_jsonb(o)->>'version','metadata',o.metadata) from storage.objects o where o.bucket_id='private-media-staging' and o.name=v_media.object_path));
 elsif p_action='cancel_media' then
  if v_job.status='processing' and v_job.lease_until>v_now then
   update public.user_media set status='deleting' where id=p_media;
   return '{"cancelled":false,"active":true}'::jsonb;
  end if;
  update app_private.media_upload_jobs set status='failed',lease_token=null,lease_until=null,last_error='MEDIA_DELETED',updated_at=v_now where media_id=p_media;
  update public.user_media set status='deleting' where id=p_media;
  perform app_private.media_event(p_media,p_owner,'cancelled','MEDIA_DELETED');
  return '{"cancelled":true}'::jsonb;
 elsif p_action='unavailable' then
  if v_media.status='ready' and v_media.content_sha256=p_data->>'sha' and v_media.verified_at=(p_data->>'verified_at')::timestamptz then
   update public.user_media set status='unavailable' where id=p_media;
   update app_private.media_upload_jobs set last_error='STORAGE_UNAVAILABLE',updated_at=v_now where media_id=p_media;
   perform app_private.media_event(p_media,p_owner,'retry','STORAGE_UNAVAILABLE');
  end if;
  return '{"unavailable":true}'::jsonb;
 elsif p_action='check_ok' then
  select * into v_obj from storage.objects where bucket_id='private-media' and name=v_media.object_path;
  if v_profile.deletion_requested_at is not null or v_media.status<>'unavailable'
   or v_media.content_sha256 is distinct from p_data->>'sha' or not found
   or v_obj.id::text is distinct from p_data->>'object_id' or (to_jsonb(v_obj)->>'version') is distinct from p_data->>'version' then
   raise exception using errcode='42501',message='verified_object_changed'; end if;
  update public.user_media set status='ready',verified_at=v_now,storage_object_id=v_obj.id,storage_object_version=to_jsonb(v_obj)->>'version' where id=p_media returning * into v_media;
  update app_private.media_upload_jobs set last_error=null,updated_at=v_now where media_id=p_media;
  perform app_private.media_event(p_media,p_owner,'ready','STORAGE_RESTORED');
  return pg_catalog.jsonb_build_object('media',pg_catalog.to_jsonb(v_media));
 elsif p_action='invalidate' then
  if v_media.status in ('ready','unavailable') and v_media.content_sha256=p_data->>'sha' and v_media.verified_at=(p_data->>'verified_at')::timestamptz then
   v_code:=p_data->>'code';
   if v_code not in ('OBJECT_MISSING','CONTENT_MISMATCH','MIME_MISMATCH','OBJECT_CHANGED') then raise exception using errcode='22023',message='invalid_failure_code'; end if;
   update public.user_media set status='failed' where id=p_media;
   update app_private.media_upload_jobs set status='failed',lease_token=null,lease_until=null,last_error=v_code,updated_at=v_now where media_id=p_media;
   perform app_private.media_event(p_media,p_owner,'invalidated',v_code);
  end if;
  return '{"invalidated":true}'::jsonb;
 end if;
 if v_job.media_id is null then raise exception using errcode='22023',message='upload_intent_required'; end if;
 if p_action='claim' then
  if v_media.status='deleting' then
   if v_job.lease_until>v_now then return '{"claimed":false}'::jsonb; end if;
   update app_private.media_upload_jobs set status='failed',last_error='MEDIA_DELETED',lease_token=null,lease_until=null,updated_at=v_now where media_id=p_media;
   return '{"claimed":false,"cancelled":true}'::jsonb;
  end if;
  if v_profile.deletion_requested_at is not null then return '{"claimed":false,"deleting":true}'::jsonb; end if;
  if v_media.status='ready' then return pg_catalog.jsonb_build_object('claimed',false,'media',pg_catalog.to_jsonb(v_media)); end if;
  if v_job.status='processing' and v_job.lease_until>v_now then return pg_catalog.jsonb_build_object('claimed',false,'media',pg_catalog.to_jsonb(v_media)); end if;
  if v_job.next_attempt_at>v_now then return pg_catalog.jsonb_build_object('claimed',false,'media',pg_catalog.to_jsonb(v_media)); end if;
  if v_job.attempts>=3 then
   update app_private.media_upload_jobs set status='failed',last_error='RETRY_EXHAUSTED',lease_token=null,lease_until=null,updated_at=v_now where media_id=p_media;
   update public.user_media set status='failed' where id=p_media;
   perform app_private.media_event(p_media,p_owner,'failed','RETRY_EXHAUSTED');
   return '{"claimed":false,"exhausted":true}'::jsonb;
  end if;
  if v_job.status='failed' and coalesce((p_data->>'from_request')::boolean,false)=false then return '{"claimed":false}'::jsonb; end if;
  update app_private.media_upload_jobs set status='processing',attempts=attempts+1,lease_token=pg_catalog.gen_random_uuid(),
   lease_until=v_now+interval '30 seconds',phase='writing',updated_at=v_now where media_id=p_media returning * into v_job;
  update public.user_media set status='processing' where id=p_media returning * into v_media;
  perform app_private.media_event(p_media,p_owner,'claimed');
  return pg_catalog.jsonb_build_object('claimed',true,'media',pg_catalog.to_jsonb(v_media),'job',pg_catalog.to_jsonb(v_job));
 end if;
 if v_job.status<>'processing' or v_job.lease_token is distinct from p_lease or v_job.lease_until<=v_now then
  raise exception using errcode='42501',message='stale_upload_lease'; end if;
 if p_action='heartbeat' then
  if v_profile.deletion_requested_at is not null or v_media.status='deleting' then raise exception using errcode='42501',message='account_deletion_in_progress'; end if;
  update app_private.media_upload_jobs set lease_until=v_now+interval '30 seconds',updated_at=v_now where media_id=p_media;
  return '{"renewed":true}'::jsonb;
 elsif p_action='finish' then
  if v_profile.deletion_requested_at is not null or v_media.status<>'processing' then raise exception using errcode='42501',message='account_deletion_in_progress'; end if;
  select * into v_obj from storage.objects where bucket_id='private-media' and name=v_media.object_path;
  if not found or v_obj.id::text is distinct from p_data->>'object_id' or (to_jsonb(v_obj)->>'version') is distinct from p_data->>'version'
   or v_job.expected_sha256 is distinct from p_data->>'sha' then raise exception using errcode='22023',message='verified_object_changed'; end if;
  update public.user_media set status='ready',content_sha256=v_job.expected_sha256,verified_at=v_now,
   storage_object_id=v_obj.id,storage_object_version=to_jsonb(v_obj)->>'version' where id=p_media returning * into v_media;
  update app_private.media_upload_jobs set status='ready',phase='ready',lease_token=null,lease_until=null,last_error=null,updated_at=v_now where media_id=p_media;
  perform app_private.media_event(p_media,p_owner,'ready');
  return pg_catalog.jsonb_build_object('media',pg_catalog.to_jsonb(v_media));
 elsif p_action='retry' then
  v_code:=p_data->>'code';
  if v_code not in ('STORAGE_UNAVAILABLE','DB_FINALIZE_FAILED','OBJECT_CHANGED','SOURCE_MISSING','CONTENT_MISMATCH','MIME_MISMATCH') then
   raise exception using errcode='22023',message='invalid_failure_code'; end if;
  update app_private.media_upload_jobs set status=case when attempts>=3 or v_profile.deletion_requested_at is not null or v_media.status='deleting' then 'failed' else 'pending' end,
   phase='failed',last_error=case when v_profile.deletion_requested_at is not null then 'ACCOUNT_DELETING' when v_media.status='deleting' then 'MEDIA_DELETED' when attempts>=3 then 'RETRY_EXHAUSTED' else v_code end,lease_token=null,lease_until=null,
   next_attempt_at=v_now+pg_catalog.make_interval(secs=>pg_catalog.power(2,attempts)::integer),updated_at=v_now where media_id=p_media returning * into v_job;
  update public.user_media set status=v_job.status where id=p_media;
  perform app_private.media_event(p_media,p_owner,case when v_job.status='failed' then 'failed' else 'retry' end,v_job.last_error);
  return pg_catalog.to_jsonb(v_job);
 end if;
 raise exception using errcode='22023',message='invalid_reliability_action';
end;
$$;
revoke all on function public.server_media_reliability(text,uuid,uuid,uuid,uuid,jsonb) from public,anon,authenticated,service_role;
grant execute on function public.server_media_reliability(text,uuid,uuid,uuid,uuid,jsonb) to service_role;

-- These guards run for Storage's service role as well: BYPASSRLS does not bypass triggers.
-- Gate final metadata commit; Storage's actual binary compensation is separately tested.
create function app_private.media_storage_guard() returns trigger
language plpgsql security definer set search_path='' as $$
declare v_owner uuid; v_media public.user_media%rowtype; v_deleted timestamptz; v_key text; v_bucket text;
begin
 if tg_op='DELETE' then v_key:=old.name;v_bucket:=old.bucket_id; else v_key:=new.name;v_bucket:=new.bucket_id; end if;
 if tg_op='UPDATE' and (old.bucket_id in ('private-media','private-media-staging') or new.bucket_id in ('private-media','private-media-staging')) and (new.name<>old.name or new.bucket_id<>old.bucket_id) then raise exception using errcode='42501',message='immutable_media_storage_key'; end if;
 if tg_op='UPDATE' and new.name=old.name and new.bucket_id=old.bucket_id and new.version is not distinct from old.version and new.metadata is not distinct from old.metadata then return new; end if;
 if v_bucket not in ('private-media','private-media-staging') then
  if tg_op='DELETE' then return old; else return new; end if;
 end if;
 if v_key !~ '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\.(png|jpg|webp)$' then
  if tg_op='DELETE' then return old; end if;
  raise exception using errcode='42501',message='unregistered_media_key';
 end if;
 v_owner:=pg_catalog.split_part(v_key,'/',1)::uuid;
 select deletion_requested_at into v_deleted from public.profiles where id=v_owner for update;
 if tg_op<>'DELETE' and (not found or v_deleted is not null) then raise exception using errcode='42501',message='media_owner_unavailable'; end if;
 select * into v_media from public.user_media where user_id=v_owner and object_path=v_key for update;
 if tg_op<>'DELETE' then
  if not found or v_media.status in ('failed','deleting') or exists(select 1 from app_private.media_orphan_claims where bucket_id=v_bucket and object_path=v_key) then
   raise exception using errcode='42501',message='media_write_fenced'; end if;
 end if;
 if v_bucket='private-media' and v_media.status in ('ready','unavailable') and tg_op in ('UPDATE','DELETE') then
  update public.user_media set status='failed' where id=v_media.id;
  update app_private.media_upload_jobs set status='failed',last_error=case when tg_op='DELETE' then 'OBJECT_MISSING' else 'OBJECT_CHANGED' end,
   lease_token=null,lease_until=null,updated_at=pg_catalog.clock_timestamp() where media_id=v_media.id;
  perform app_private.media_event(v_media.id,v_owner,'invalidated',case when tg_op='DELETE' then 'OBJECT_MISSING' else 'OBJECT_CHANGED' end);
 end if;
 if tg_op='DELETE' then return old; else return new; end if;
end;
$$;
revoke all on function app_private.media_storage_guard() from public,anon,authenticated,service_role;
create trigger fitness_media_storage_guard before insert or update or delete on storage.objects for each row execute function app_private.media_storage_guard();

create function app_private.media_auth_delete_guard() returns trigger
language plpgsql security definer set search_path='' as $$
begin
 perform 1 from public.profiles where id=old.id for update;
 if exists(select 1 from storage.objects where bucket_id in ('private-media','private-media-staging') and pg_catalog.split_part(name,'/',1)=old.id::text)
  or exists(select 1 from app_private.media_upload_jobs where user_id=old.id and status in ('pending','processing')) then
  raise exception using errcode='42501',message='media_cleanup_required'; end if;
 delete from app_private.media_orphan_claims where pg_catalog.split_part(object_path,'/',1)=old.id::text;
 return old;
end;
$$;
revoke all on function app_private.media_auth_delete_guard() from public,anon,authenticated,service_role;
create trigger fitness_media_auth_delete_guard before delete on auth.users for each row execute function app_private.media_auth_delete_guard();

commit;
