/** Additional real UI logout/account-delete regression; only local synthetic users. */
import { chromium, expect } from '@playwright/test';
import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import sharp from 'sharp';
import { assertLocalAclAuditTarget, observeUserRows } from '../../tests/helpers/local-acl-observer.mjs';
import { countLocalStorageBinaryFiles } from '../../tests/helpers/local-acl-faults.mjs';
import { beginEvidence, cleanupFixtures, registerSecret, auditedFetch } from '../../tests/helpers/g53-evidence.mjs';
await assertLocalAclAuditTarget();
const cfg=JSON.parse(readFileSync(process.env.FITNESS_ACL_AUDIT_CONFIG,'utf8'));
const admin=createClient(cfg.apiUrl,cfg.serviceRoleKey,{auth:{persistSession:false,autoRefreshToken:false},global:{fetch:auditedFetch}});
const actors=[],checks=[],audit=beginEvidence('additional real browser logout and account deletion',checks);
let browser,current='initialization';
const check=(condition,label)=>{current=label;if(!condition)throw new Error(label);checks.push({label,status:'PASS'});};
try{
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const errors=[];
 for(const email of ['user-a@example.invalid','user-b@example.invalid']){
  const password='BrowserLifecycle!'+randomUUID()+'Aa9';registerSecret(password);
  const created=await admin.auth.admin.createUser({email,password,email_confirm:true});if(created.error)throw created.error;
  const actor={id:created.data.user.id,email,password};actors.push(actor);
  actor.context=await browser.newContext({baseURL:cfg.appUrl});actor.page=await actor.context.newPage();actor.page.on('pageerror',e=>errors.push(e.message));
  await actor.page.goto('/auth/sign-in?next=%2Faccount%2Fprivacy');const form=actor.page.locator('.auth-form:visible');
  await form.getByRole('textbox',{name:'邮箱地址',exact:true}).fill(email);await form.locator('input[name="password"]').fill(password);await form.getByRole('button',{name:'登录账户',exact:true}).click();await expect(actor.page).toHaveURL(/account\/privacy$/);check(true,'actual browser login '+email);
 }
 const [a,b]=actors;
 await expect.poll(async()=>a.page.evaluate(async()=>{const names=await indexedDB.databases();return names.some(x=>x.name?.startsWith('fitness-os-private-'));})).toBe(true);
 check(true,'logged in browser actually has private account IndexedDB');
 const image=await sharp({create:{width:3,height:3,channels:3,background:'blue'}}).png().toBuffer();
 await a.page.getByLabel('选择私人图片',{exact:true}).setInputFiles({name:'local-ui.png',mimeType:'image/png',buffer:image});const uploaded=a.page.waitForResponse(r=>r.url().endsWith('/api/account/media')&&r.request().method()==='POST');await a.page.getByRole('button',{name:'上传私人图片',exact:true}).click();check((await uploaded).status()===201,'actual UI creates verified private image before deletion');
 check((await countLocalStorageBinaryFiles(a.id))>0,'real A binary exists before UI deletion');
 await b.page.goto('/account/security');await b.page.getByRole('button',{name:'退出登录',exact:true}).click();await expect(b.page).toHaveURL(/auth\/sign-in/);check(true,'actual logout UI completes');
 check((await b.page.request.get('/api/account/snapshot')).status()===401,'logged out browser private account API actually denies access');
 const bNames=await b.page.evaluate(async()=>await indexedDB.databases());check(bNames.every(x=>!x.name?.includes(b.id)),'logout deletes B private IndexedDB');
 check((await a.page.request.get('/api/account/snapshot')).status()===200,'B logout leaves A session usable');
 await a.page.getByRole('button',{name:'开始删除账号',exact:true}).click();await a.page.getByRole('checkbox',{name:/我已确认删除不可撤销/}).check();await a.page.getByLabel('输入 DELETE 确认',{exact:true}).fill('DELETE');await a.page.getByLabel('当前密码（再次验证身份）',{exact:true}).fill(a.password);
 const removed=a.page.waitForResponse(r=>r.url().endsWith('/api/account/delete')&&r.request().method()==='POST');await a.page.getByRole('button',{name:'最终确认：永久删除我的账号',exact:true}).click();check((await removed).status()===200,'actual password-confirmed account-delete UI returns success');
 await expect(a.page).toHaveURL(/auth\/sign-in/);
 const gone=await admin.auth.admin.getUserById(a.id);check(gone.error?.status===404&&gone.error?.code==='user_not_found','UI deletion is independently confirmed by actual Auth Admin 404');
 check((await countLocalStorageBinaryFiles(a.id))===0,'UI deletion removes real binary files from both buckets');
 for(const table of ['profiles','user_media','account_deletion_jobs'])check((await observeUserRows(table,a.id)).length===0,'UI deletion physical SQL cascade '+table);
 const aNames=await a.page.evaluate(async()=>await indexedDB.databases());check(aNames.every(x=>!x.name?.includes(a.id)),'UI deletion deletes A private IndexedDB');
 check((await admin.auth.admin.getUserById(b.id)).data.user?.id===b.id,'A UI deletion does not delete B Auth account');
 check(errors.length===0,'UI logout/delete has no unhandled browser errors');
}catch(error){audit.fail(error,current);}finally{
 if(browser)await browser.close();await audit.finish(()=>cleanupFixtures(admin,actors,{stopServer:true}));
}
