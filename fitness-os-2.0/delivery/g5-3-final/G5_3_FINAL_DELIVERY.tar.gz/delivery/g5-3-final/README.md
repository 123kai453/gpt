# G5.3 最终本地修订交付

先读 docs/G5_3_FULL_REMEDIATION_REPORT.md 和 G5_3_INDEPENDENT_EVIDENCE.md。

- TEST_RESULTS.json：最终选择的真实执行、逐例名称/结果、计数与源哈希。
- runs/：所有开发和最终原始命令、日志、子命令、清理与源快照；旧失败保留。
- META_FAILURE_REPORT.json：故意失败必须保持FAIL/exit1，清理PASS。
- SOURCE_MANIFEST.json：实际被测源码124文件；额外UI2文件单独记录。
- PATCH_TARGETS.json、files/：33个目标（32代码/测试/配置和1新SQL）完整字节副本。
- nextjs-upload-reliability.final_proposed.patch：对实际原工作区检查可应用；未替原项目应用。
- g53-to-final-sql.review.diff：审查差异，不是前向迁移。
- FINAL_MIGRATION_ROLLBACK_REPORT.json：仅本轮本地空fixture的原子/重复执行验证。
- FORCED_ROLLBACK_TEST_INPUT.sql：故意失败输入，绝不可部署。
- LOCAL_CATALOG_SNAPSHOT/LOCAL_VERSIONS/PHYSICAL_STORAGE_CHECK/MAIL_CHECK/LOCAL_SHUTDOWN.json：实际目录/环境/真实文件/邮件和停止证据。
- ORIGINAL_WORKSPACE_PRESERVATION.json：原447文件及Git基准不变。
- ARTIFACT_MANIFEST.json、SHA256SUMS：交付完整性。私密配置、node_modules、.next及本地key不在归档。

只在Linux /proc + Docker Unix socket的独立本地条件可重跑；临时0600配置需自行重新生成，不包含生产密钥。未提供一键生产执行指令。正式初始候选不可与旧initial连续执行，托管状态需重新核实。
