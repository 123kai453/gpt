from pathlib import Path
import hashlib,json,datetime
from zoneinfo import ZoneInfo
app=Path(__file__).resolve().parents[2]
files=[]
for directory in ['src','scripts','tests']:
 for f in (app/directory).rglob('*'):
  if f.is_file() and f.suffix in ('.ts','.tsx','.mjs','.mts','.js'):files.append(f)
for name in ['public/sw.js','public/manifest.json','package.json','pnpm-lock.yaml','vitest.config.mts','tsconfig.json','next.config.ts','supabase/reviews/20261110000200_account_upload_reliability.final_proposed.sql','delivery/g5-3-final/run-command.py','delivery/g5-3-final/run-local-check.py']:
 f=app/name
 if f.is_file():files.append(f)
manifest={'root':str(app),'generated_at':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'scope':'actual local test application, tests, current SQL and evidence runner; not copied config hashes','files':[{'path':str(f.relative_to(app)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(set(files))]}
(app/'delivery/g5-3-final/SOURCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'sourceFiles':len(files),'sqlSHA256':next(x['sha256'] for x in manifest['files'] if x['path'].endswith('final_proposed.sql'))}))
