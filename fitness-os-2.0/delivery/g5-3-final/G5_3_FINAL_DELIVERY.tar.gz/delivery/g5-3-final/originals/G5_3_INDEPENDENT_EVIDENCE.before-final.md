# G5.3 独立审查测试证据

整理时间：2026-11-10T21:24:01.597417+08:00（北京时间）。本轮仅读取现有源码、补丁与证据，新增本报告；未修改代码、SQL 候选或旧结果，未启动容器、重跑测试、连接数据库或部署。

## 1. 证据性质与当前核验范围

本报告从现有 JSON 原件逐项提取名称和结果，不重建测试日志。R/H/L/U 编号是本报告按原始数组顺序添加的引用编号，不是原套件原有的 case ID；重复名称保留。70、97、104 中包含夹具创建、查询和故障准备等断言步骤，不能解释为 271 个彼此独立的端到端业务场景。28 项离线测试也不等于数据库集成测试。

| 套件 | 原始记录 | 本轮读取检查 |
|---|---|---|
| 角色 | status=PASS，assertions=70，70 条字符串 checks | 数组数量吻合；通过后入列机制经源代码核对 |
| API 回归 | status=PASS，assertions=97，每条有 PASS | 97 条均为 PASS，无已登记 knownGaps |
| 可靠性 | status=PASS，assertions=104，每条有 PASS | 104 条均为 PASS，候选 SHA 与原件吻合 |
| 离线 | success=true，28 passed、0 failed、0 pending | 逐个 assertionResults 提取 28 个 fullName |

角色 JSON 没有逐条 status 字段；其 ok/denied/rejected 都在实际断言成功后 checks.push(label)，所以表中标注“PASS（通过后入列）”，不向原 JSON 添加不存在的字段。HTTP/可靠性的 label/status 和离线 passed 均照录。源角色脚本保留早期 design-only 注释，不能用注释推断是否执行；实际结果依据本轮候选 SHA 绑定的结果原件。

当前读取既有 61 项 ARTIFACT_MANIFEST 文件均与登记 SHA256 一致，原 SHA256SUMS 校验命令退出 0。开始登记的 365 个原文件、原分支、原暂存/未暂存 diff 保持不变。本报告为新文件，未修改旧 manifest 来把新文件追加入历史记录。

## 2. 三个原件及证据文件的 SHA256

下面均为实际存在的文件路径，相对应用根目录 `/workspace/fitness-os-phase2/fitness-os-2.0`。前三项正是用户要求的三个原件，未重生成或重命名。SQL 是 fresh 初始化审阅候选，不是已应用的生产迁移。

| 路径 | 字节数 | 本轮实际 SHA256 |
|---|---|---|
| `supabase/reviews/20261110000100_account_upload_reliability.proposed.sql` | 62506 | `56ec5bce2f92876a931c1b845077535e4906840fe20563856a2a6cb5e4d07af2` |
| `delivery/g5-3/files/src/lib/account/media-reliability.ts.proposed` | 12946 | `221fd51c1f7df55a0002a2cd38774f92d0cc3411d41fea8403db169958b32338` |
| `delivery/g5-3/RELIABILITY_TEST_RESULTS.json` | 9829 | `8e20b5af390c4bc763ff13ac4c176ea3bb45451626fb46d62d2346a2446883b3` |
| `delivery/g5-3/ROLE_TEST_RESULTS.json` | 3303 | `b1434cf5cd5e5a3be6cc0d1b18a724e775c4d9997491cfee945407ba2626ba04` |
| `delivery/g5-3/HTTP_TEST_RESULTS.json` | 9446 | `b4b5d6926dad15042d1b4eae1d4a65d4302399f1b44f51776fd3c8f2f7f4964a` |
| `delivery/g5-3/UNIT_TEST_RESULTS.json` | 16699 | `f6178d2b014ae0d6fdfcf8ccbf6a3ee7436cb05ef1e9f36e52deaae02f18aa52` |
| `delivery/g5-3/NETWORK_FAULT_EVIDENCE.json` | 1054 | `f829391485b99afb56ed238b67172abc1675746019d288f4ff2711c946c6cdfc` |
| `delivery/g5-3/LOCAL_VERSIONS.json` | 1463 | `c44dafe81702621068e8c059ca08f5de0498e04b9dc1fefd8d5d2b674d694800` |
| `delivery/g5-3/STATIC_CHECK_RESULTS.json` | 614 | `40da659c7bd46018256642a79be7fe8b82d28b0352d375b65f1edfc9dfaffced` |
| `delivery/g5-3/CANDIDATE_APPLICATION.json` | 670 | `c7fb115556f6e37a6d8f1f639e67cdeaae1a91d4351c15204fc225ebc9380860` |
| `delivery/g5-3/EXECUTION_TIMELINE.json` | 402 | `dc5a35d9f3c7461dffe6e46bbce562e87d3ff6ad3130a94a93f35b54eb8b7d1f` |
| `delivery/g5-3/LOCAL_CATALOG_SNAPSHOT.json` | 10748 | `1a8a41d4926ec38bef6bd73fb49c8cf3b9d99291edab080d16ebaed95b54d855` |
| `delivery/g5-3/PHYSICAL_STORAGE_CHECK.json` | 276 | `ac7ce6c1268613b5b8b98cb5a44ba9b02d3cc65a5f2b339db035b10911708ae2` |
| `delivery/g5-3/LOCAL_SHUTDOWN.json` | 1210 | `d637fbd1bff49d27de714972b522c41e0fcccb89e916377c5ca66588ae1b4926` |
| `delivery/g5-3/run-local-check.py` | 3352 | `7371ab74a1435b027e66c08b2109854ee0be66773a0601a4119248531158259b` |
| `delivery/g5-3/fault-proxy.mjs` | 2723 | `ba1acfb63eaa353723397d418b61e9da25d954ffb12b9b12840e565b2765dfaf` |
| `delivery/g5-3/files/tests/integration/g53-reliability.mjs.proposed` | 27385 | `576e5d3dc28a8c3958835d7fc3eb9724e4c4208dac6580c88968fe9ce8de31eb` |
| `delivery/g5-3/files/src/lib/account/verified-image.ts.proposed` | 1765 | `7d1c88d272d197f4a64f46c9d15209659f3fafa5a6923e94bda682ffd696cd3a` |

## 3. 70 项角色检查原始名称及结果

来源：`delivery/g5-3/ROLE_TEST_RESULTS.json`。对照源码：`delivery/g5-3/files/tests/integration/g53-role-regression.mjs.proposed`。实际检查的是新 G5.3 候选，仍包含原 service-only 兼容 RPC；不是用此套件替代新的 Next 可靠性链路。

| 审查编号 | 原始名称（保持顺序与重复项） | 记录结果 |
|---|---|---|
| R001 | fresh local Auth accessible | PASS（通过后入列） |
| R002 | local fictional Auth user created without mail | PASS（通过后入列） |
| R003 | real local user session | PASS（通过后入列） |
| R004 | local fictional Auth user created without mail | PASS（通过后入列） |
| R005 | real local user session | PASS（通过后入列） |
| R006 | service role has no direct profiles read | PASS（通过后入列） |
| R007 | anon has no direct profiles read | PASS（通过后入列） |
| R008 | service role has no direct user_preferences read | PASS（通过后入列） |
| R009 | anon has no direct user_preferences read | PASS（通过后入列） |
| R010 | service role has no direct user_consents read | PASS（通过后入列） |
| R011 | anon has no direct user_consents read | PASS（通过后入列） |
| R012 | service role has no direct sync_metadata read | PASS（通过后入列） |
| R013 | anon has no direct sync_metadata read | PASS（通过后入列） |
| R014 | service role has no direct user_data_exports read | PASS（通过后入列） |
| R015 | anon has no direct user_data_exports read | PASS（通过后入列） |
| R016 | service role has no direct user_media read | PASS（通过后入列） |
| R017 | anon has no direct user_media read | PASS（通过后入列） |
| R018 | service role has no direct account_deletion_jobs read | PASS（通过后入列） |
| R019 | anon has no direct account_deletion_jobs read | PASS（通过后入列） |
| R020 | anon cannot invoke trusted deletion RPC | PASS（通过后入列） |
| R021 | authenticated cannot insert forged ready | PASS（通过后入列） |
| R022 | authenticated cannot invoke trusted RPC | PASS（通过后入列） |
| R023 | trusted pending reservation | PASS（通过后入列） |
| R024 | authenticated cannot promote pending to ready | PASS（通过后入列） |
| R025 | nonexistent object cannot become ready | PASS（通过后入列） |
| R026 | direct final upload denied | PASS（通过后入列） |
| R027 | direct staging upload denied | PASS（通过后入列） |
| R028 | trusted object upload | PASS（通过后入列） |
| R029 | trusted object upload | PASS（通过后入列） |
| R030 | even owner cannot read staging | PASS（通过后入列） |
| R031 | trusted staging cleanup | PASS（通过后入列） |
| R032 | trusted valid object finalization | PASS（通过后入列） |
| R033 | A reads own ready binary | PASS（通过后入列） |
| R034 | B cannot read A binary | PASS（通过后入列） |
| R035 | anon cannot read A binary | PASS（通过后入列） |
| R036 | B delete affects no rows | PASS（通过后入列） |
| R037 | A binary survives B delete attempt | PASS（通过后入列） |
| R038 | authenticated cannot insert completed export | PASS（通过后入列） |
| R039 | trusted export begin | PASS（通过后入列） |
| R040 | authenticated cannot complete export | PASS（通过后入列） |
| R041 | trusted export serialization completion | PASS（通过后入列） |
| R042 | consent append allowed | PASS（通过后入列） |
| R043 | consent history update denied | PASS（通过后入列） |
| R044 | consent history delete denied | PASS（通过后入列） |
| R045 | client cannot forge server sync time | PASS（通过后入列） |
| R046 | B reservation | PASS（通过后入列） |
| R047 | B object | PASS（通过后入列） |
| R048 | B ready | PASS（通过后入列） |
| R049 | user deletion request remains available | PASS（通过后入列） |
| R050 | authenticated cannot forge deletion stage | PASS（通过后入列） |
| R051 | trusted delete start | PASS（通过后入列） |
| R052 | uncleared objects block Auth stage | PASS（通过后入列） |
| R053 | trusted failure persisted | PASS（通过后入列） |
| R054 | trusted retry | PASS（通过后入列） |
| R055 | remove only A object | PASS（通过后入列） |
| R056 | empty owner prefix allows Auth stage | PASS（通过后入列） |
| R057 | Auth admin delete with SQL cascade | PASS（通过后入列） |
| R058 | A physical profiles rows cascaded (read-only local observer) | PASS（通过后入列） |
| R059 | A physical user_preferences rows cascaded (read-only local observer) | PASS（通过后入列） |
| R060 | A physical user_consents rows cascaded (read-only local observer) | PASS（通过后入列） |
| R061 | A physical sync_metadata rows cascaded (read-only local observer) | PASS（通过后入列） |
| R062 | A physical user_data_exports rows cascaded (read-only local observer) | PASS（通过后入列） |
| R063 | A physical user_media rows cascaded (read-only local observer) | PASS（通过后入列） |
| R064 | A physical account_deletion_jobs rows cascaded (read-only local observer) | PASS（通过后入列） |
| R065 | A physical account_mutation_receipts rows cascaded (read-only local observer) | PASS（通过后入列） |
| R066 | A physical rate_limit_counters rows cascaded (read-only local observer) | PASS（通过后入列） |
| R067 | B survives A deletion | PASS（通过后入列） |
| R068 | B session for revocation test | PASS（通过后入列） |
| R069 | B local logout | PASS（通过后入列） |
| R070 | revoked B JWT cannot download after logout | PASS（通过后入列） |

## 4. 97 项 API 回归原始名称及结果

来源：`delivery/g5-3/HTTP_TEST_RESULTS.json`；测试源：`delivery/g5-3/files/tests/integration/g53-http.mjs.proposed`。测试经真实本地 Next、Auth、PostgREST、Storage；部分 raw SQL 用于独立本地角色拒绝检查与故障夹具。G5.2 原有 98 项中的反例期望已调整，不能称旧 98 项原样执行；调整原件是 `g5_2_to_g5_3_http_test.proposed.diff`。

| 审查编号 | 原始名称（保持顺序与重复项） | 记录结果 |
|---|---|---|
| H001 | fresh Auth for HTTP fixture | PASS |
| H002 | SDK suite left no users | PASS |
| H003 | local confirmed synthetic user | PASS |
| H004 | real Auth password session and SSR cookies | PASS |
| H005 | real distinct authenticated JWT claims | PASS |
| H006 | local confirmed synthetic user | PASS |
| H007 | real Auth password session and SSR cookies | PASS |
| H008 | real distinct authenticated JWT claims | PASS |
| H009 | Next profile snapshot works | PASS |
| H010 | Next profile CAS update works under hardened ACL | PASS |
| H011 | Next preference CAS update works under hardened ACL | PASS |
| H012 | preference data actually updated | PASS |
| H013 | read own server sync timestamps | PASS |
| H014 | sync values use server clock near actual request time | PASS |
| H015 | Next rejects client-supplied server timestamp | PASS |
| H016 | direct REST sync timestamp write denied | PASS |
| H017 | Next upload image/png returns 201 | PASS |
| H018 | Next upload image/png returns 201 | PASS |
| H019 | Next upload returns server-verified ready row | PASS |
| H020 | Next download binary matches committed verification digest | PASS |
| H021 | private HTTP media is not cacheable | PASS |
| H022 | B cannot read A through Next | PASS |
| H023 | B cannot delete A through Next | PASS |
| H024 | anonymous Next download denied | PASS |
| H025 | direct REST cannot rewrite server verification | PASS |
| H026 | direct owner Storage replacement denied | PASS |
| H027 | direct owner Storage deletion affects no object | PASS |
| H028 | object survives denied direct deletion | PASS |
| H029 | Next upload image/jpeg returns 415 | PASS |
| H030 | Next upload image/jpeg returns 415 | PASS |
| H031 | Next upload image/png returns 400 | PASS |
| H032 | media rows after invalid inputs | PASS |
| H033 | invalid content and forged multipart state create no metadata | PASS |
| H034 | Next upload image/png returns 201 | PASS |
| H035 | Next upload image/png returns 200 | PASS |
| H036 | same idempotency header reuses one ready media ID | PASS |
| H037 | Next owner media deletion works through narrow RPC | PASS |
| H038 | install disposable ready failure trigger | PASS |
| H039 | Next upload image/png returns 202 | PASS |
| H040 | inspect retriable ready transaction | PASS |
| H041 | failed ready transaction remains recoverable with same ID | PASS |
| H042 | verified final binary retained for safe recovery after database failure | PASS |
| H043 | remove only this run temporary ready trigger | PASS |
| H044 | real trusted worker recovers committed Storage after failed DB finalization | PASS |
| H045 | recovered row is truly ready | PASS |
| H046 | Next export works with server-only task writes | PASS |
| H047 | Next export contains only A account data | PASS |
| H048 | read actual export task | PASS |
| H049 | export status reflects serialization completion with no fabricated path | PASS |
| H050 | direct REST export completion denied | PASS |
| H051 | Next rejects forged export state fields | PASS |
| H052 | Next consent append true | PASS |
| H053 | Next consent withdrawal appends new false | PASS |
| H054 | Next consent history readable | PASS |
| H055 | prior consent remains and latest false takes effect | PASS |
| H056 | raw SQL authenticated cannot forge ready | PASS |
| H057 | raw SQL authenticated cannot forge completed | PASS |
| H058 | raw SQL authenticated cannot change deletion job | PASS |
| H059 | raw SQL consent UPDATE denied | PASS |
| H060 | raw SQL consent DELETE denied | PASS |
| H061 | raw SQL private schema denied | PASS |
| H062 | raw SQL anon profile denied | PASS |
| H063 | raw SQL service role direct table SELECT denied | PASS |
| H064 | raw SQL authenticated own SELECT succeeds | PASS |
| H065 | raw SQL RLS filters other user | PASS |
| H066 | Next deletion requires correct password before mutations | PASS |
| H067 | wrong password creates no deletion job | PASS |
| H068 | physical A/B binaries exist before cleanup | PASS |
| H069 | Next real Storage failure is retryable error | PASS |
| H070 | server persists failed job and first attempt | PASS |
| H071 | direct REST cannot forge retry state | PASS |
| H072 | B download unaffected by A cleanup fault | PASS |
| H073 | Next deletion retry succeeds through Auth Admin | PASS |
| H074 | Next confirms completed account removal | PASS |
| H075 | A Auth user actually removed | PASS |
| H076 | A physical profiles cascade complete | PASS |
| H077 | A physical user_preferences cascade complete | PASS |
| H078 | A physical user_consents cascade complete | PASS |
| H079 | A physical sync_metadata cascade complete | PASS |
| H080 | A physical user_data_exports cascade complete | PASS |
| H081 | A physical user_media cascade complete | PASS |
| H082 | A physical account_deletion_jobs cascade complete | PASS |
| H083 | A physical account_mutation_receipts cascade complete | PASS |
| H084 | A physical rate_limit_counters cascade complete | PASS |
| H085 | A physical media binary removed | PASS |
| H086 | B physical media binary unchanged | PASS |
| H087 | old deleted-user cookies cannot download | PASS |
| H088 | reserve synthetic interrupted upload | PASS |
| H089 | pending media can be safely cancelled and removed through fenced API | PASS |
| H090 | cancelled pending row removed | PASS |
| H091 | simulate trusted out-of-band replacement | PASS |
| H092 | trusted replacement invalidates readiness and is not served | PASS |
| H093 | simulate out-of-band loss of B ready object | PASS |
| H094 | read metadata after actual object loss | PASS |
| H095 | actual missing binary is represented as failed rather than ready | PASS |
| H096 | B normal account deletion after controlled fixture cleanup | PASS |
| H097 | local mail capture contains zero messages | PASS |

## 5. 104 项可靠性原始名称及结果

来源：`delivery/g5-3/RELIABILITY_TEST_RESULTS.json`；测试源：`delivery/g5-3/files/tests/integration/g53-reliability.mjs.proposed`。JSON 登记 realNetworkFaults=true、realNextProcessKilled=true、productionRequests=false，下面的故障源码与独立代理事件进一步支撑这些标签。

| 审查编号 | 原始名称（保持顺序与重复项） | 记录结果 |
|---|---|---|
| L001 | fresh Auth | PASS |
| L002 | no existing fixture users | PASS |
| L003 | create synthetic user | PASS |
| L004 | real password sign in | PASS |
| L005 | create synthetic user | PASS |
| L006 | real password sign in | PASS |
| L007 | authenticated Cookie cannot call trusted recovery | PASS |
| L008 | authenticated cannot call recovery RPC | PASS |
| L009 | client cannot read private journal | PASS |
| L010 | same request sequential retry uses one business record | PASS |
| L011 | local readonly evidence query | PASS |
| L012 | same request creates only one final Storage object | PASS |
| L013 | same idempotency key different actual file conflicts | PASS |
| L014 | idempotency is scoped to user A/B | PASS |
| L015 | concurrent same request has one canonical media ID | PASS |
| L016 | trusted probe | PASS |
| L017 | only one worker acquired initial concurrent upload lease | PASS |
| L018 | actual committed Storage response dropped; readback recovers | PASS |
| L019 | network interruption retry does not create another object | PASS |
| L020 | database finish committed but HTTP acknowledgement lost; result safely recovered | PASS |
| L021 | lost DB acknowledgement retains stable identity | PASS |
| L022 | trusted reserve | PASS |
| L023 | persist real staged source | PASS |
| L024 | local disposable fixture transaction | PASS |
| L025 | two real worker processes complete trusted HTTP sweeps | PASS |
| L026 | trusted probe | PASS |
| L027 | aged pending recovered once under exclusive lease | PASS |
| L028 | trusted probe | PASS |
| L029 | repeated recovery does not create records or consume attempts again | PASS |
| L030 | trusted reserve | PASS |
| L031 | local disposable fixture transaction | PASS |
| L032 | trusted probe | PASS |
| L033 | missing source records first recoverable failure | PASS |
| L034 | trusted probe | PASS |
| L035 | backoff blocks immediate repeated retry | PASS |
| L036 | trusted probe | PASS |
| L037 | second due attempt recorded | PASS |
| L038 | trusted probe | PASS |
| L039 | maximum attempts becomes audited terminal failure | PASS |
| L040 | local readonly evidence query | PASS |
| L041 | recovery audit retains bounded failure reasons | PASS |
| L042 | exact owned Next process selected | PASS |
| L043 | local readonly evidence query | PASS |
| L044 | actual killed process leaves durable processing task | PASS |
| L045 | trusted probe | PASS |
| L046 | live lease is not stolen immediately after crash | PASS |
| L047 | trusted probe | PASS |
| L048 | new worker recovers same media from actual committed bytes after lease expiry | PASS |
| L049 | old worker lease cannot finalize task | PASS |
| L050 | trusted replacement writes real new bytes | PASS |
| L051 | replacement invalidates old verification, never serves different bytes | PASS |
| L052 | actual replacement changes size | PASS |
| L053 | size-changed file is not served under old verification | PASS |
| L054 | API rejects actual bytes/MIME disagreement | PASS |
| L055 | trusted declaration differs from real PNG | PASS |
| L056 | MIME replacement never retains ready | PASS |
| L057 | replace after old snapshot was fetched | PASS |
| L058 | TOCTOU detects new version/state rather than returning stale proof | PASS |
| L059 | trusted probe | PASS |
| L060 | only exact synthetic backend version altered | PASS |
| L061 | real byte corruption is rejected by SHA256 even without Storage metadata event | PASS |
| L062 | trusted probe | PASS |
| L063 | SHA256 mismatch safely invalidates the old verification | PASS |
| L064 | trusted probe | PASS |
| L065 | only exact synthetic backend version altered | PASS |
| L066 | trusted probe | PASS |
| L067 | ambiguous provider 500 becomes unavailable, never falsely declared missing | PASS |
| L068 | B profile before transient outage | PASS |
| L069 | set valid verified avatar reference | PASS |
| L070 | real backend outage is transient API 503 | PASS |
| L071 | trusted probe | PASS |
| L072 | transient network/server error preserves verification without declaring loss | PASS |
| L073 | read profile during actual Storage outage | PASS |
| L074 | temporary unavailable state preserves avatar reference | PASS |
| L075 | same healthy file works after actual outage | PASS |
| L076 | remove actual ready object | PASS |
| L077 | trusted probe | PASS |
| L078 | confirmed object loss no longer remains ready | PASS |
| L079 | user has a valid new-upload recovery path | PASS |
| L080 | register orphan fixture before actual upload | PASS |
| L081 | real Storage orphan source | PASS |
| L082 | local disposable fixture transaction | PASS |
| L083 | orphan Storage object actually cleaned | PASS |
| L084 | orphan cleanup does not touch B binaries | PASS |
| L085 | B cannot access A after reliability changes | PASS |
| L086 | direct client upload still cannot bypass verification | PASS |
| L087 | B own media remains normally available | PASS |
| L088 | trusted reserve | PASS |
| L089 | trusted claim | PASS |
| L090 | local disposable fixture transaction | PASS |
| L091 | active upload cannot be reported deleted before writer settles | PASS |
| L092 | cancelled late writer cannot commit Storage metadata | PASS |
| L093 | trusted retry | PASS |
| L094 | safe deletion retry succeeds after the known writer ended | PASS |
| L095 | local disposable fixture transaction | PASS |
| L096 | A deletion cancels jobs, cleans binaries and removes Auth | PASS |
| L097 | A physical registered binaries gone | PASS |
| L098 | local readonly evidence query | PASS |
| L099 | media_upload_jobs cascades with A Auth | PASS |
| L100 | local readonly evidence query | PASS |
| L101 | media_job_events cascades with A Auth | PASS |
| L102 | B unaffected by A complete deletion | PASS |
| L103 | B normal deletion retained | PASS |
| L104 | no emails sent | PASS |

## 6. 28 项离线测试原始名称及结果

来源：`delivery/g5-3/UNIT_TEST_RESULTS.json`。按 testResults/assertionResults 的实际顺序：8 项 G5.3 静态断言、9 项旧 trusted_state 静态断言、4 项真实 sharp 离线解码、5 项 mock 上传编排、2 项 mock 删除/重试。最后 7 项确实使用 mock transport；不据此宣称 Supabase 集成成功。旧候选的“八个函数不变”断言属于旧 G5 trusted_state，不否定新候选 clear_removed_avatar 为 unavailable 的明确修订。

| 审查编号 | 原始 fullName | 原结果 | 来源/性质 |
|---|---|---|
| U001 | G5.3 static security contracts (not database integration) contains durable per-user idempotency fingerprints | passed | `media-reliability-sql.test.ts`；G5.3 SQL/源码静态断言 |
| U002 | G5.3 static security contracts (not database integration) uses token leases, bounded retries and a fresh post-lock clock | passed | `media-reliability-sql.test.ts`；G5.3 SQL/源码静态断言 |
| U003 | G5.3 static security contracts (not database integration) grants only the bounded new maintenance function to service_role | passed | `media-reliability-sql.test.ts`；G5.3 SQL/源码静态断言 |
| U004 | G5.3 static security contracts (not database integration) has managed-version precondition and content-change/cancellation fences | passed | `media-reliability-sql.test.ts`；G5.3 SQL/源码静态断言 |
| U005 | G5.3 static security contracts (not database integration) retains one atomic initial and seven original functions and transient avatar references | passed | `media-reliability-sql.test.ts`；G5.3 SQL/源码静态断言 |
| U006 | G5.3 static security contracts (not database integration) maintenance has a separate private credential and no cookie-based privilege fallback | passed | `media-reliability-sql.test.ts`；G5.3 SQL/源码静态断言 |
| U007 | G5.3 static security contracts (not database integration) reads actual bytes rather than trusting ETag or client SHA | passed | `media-reliability-sql.test.ts`；G5.3 SQL/源码静态断言 |
| U008 | G5.3 static security contracts (not database integration) client retains only the logical request identity in memory, not a private file cache | passed | `media-reliability-sql.test.ts`；G5.3 SQL/源码静态断言 |
| U009 | trusted candidate static boundary (not database execution) authenticated has no broad writes; consent INSERT remains column-limited | passed | `trusted-state-sql.test.ts`；旧 trusted_state 候选/源码静态断言 |
| U010 | trusted candidate static boundary (not database execution) trusted finalizers are granted only to service_role with fixed search_path and role guard | passed | `trusted-state-sql.test.ts`；旧 trusted_state 候选/源码静态断言 |
| U011 | trusted candidate static boundary (not database execution) Storage gives clients only own ready-object SELECT, never staging writes | passed | `trusted-state-sql.test.ts`；旧 trusted_state 候选/源码静态断言 |
| U012 | trusted candidate static boundary (not database execution) missing objects and pending uploads are explicit server-side fences | passed | `trusted-state-sql.test.ts`；旧 trusted_state 候选/源码静态断言 |
| U013 | trusted candidate static boundary (not database execution) export paths are NULL and media keys bind owner/id/type | passed | `trusted-state-sql.test.ts`；旧 trusted_state 候选/源码静态断言 |
| U014 | trusted candidate static boundary (not database execution) preserves all eight old RPC/trigger implementations and consent append rules | passed | `trusted-state-sql.test.ts`；旧 trusted_state 候选/源码静态断言 |
| U015 | trusted candidate static boundary (not database execution) owns one explicit transaction and does not introduce dynamic SQL | passed | `trusted-state-sql.test.ts`；旧 trusted_state 候选/源码静态断言 |
| U016 | trusted candidate static boundary (not database execution) sync clocks are written by bounded mutation RPC, not client payload | passed | `trusted-state-sql.test.ts`；旧 trusted_state 候选/源码静态断言 |
| U017 | trusted candidate static boundary (not database execution) retains password reauthentication before cleanup and final Auth Admin delete | passed | `trusted-state-sql.test.ts`；旧 trusted_state 候选/源码静态断言 |
| U018 | trusted image decoding (offline, actual sharp) fully decodes and normalizes a valid image | passed | `trusted-state.test.ts`；真实 sharp 解码，离线 |
| U019 | trusted image decoding (offline, actual sharp) rejects a JPEG-shaped marker sequence without a decodable image | passed | `trusted-state.test.ts`；真实 sharp 解码，离线 |
| U020 | trusted image decoding (offline, actual sharp) rejects forged MIME | passed | `trusted-state.test.ts`；真实 sharp 解码，离线 |
| U021 | trusted image decoding (offline, actual sharp) rejects empty and oversized inputs before decode | passed | `trusted-state.test.ts`；真实 sharp 解码，离线 |
| U022 | trusted upload orchestration (mock transport; no Supabase) only finalizes after stage/final readback and deletes staging | passed | `trusted-state.test.ts`；mock transport，无 Supabase |
| U023 | trusted upload orchestration (mock transport; no Supabase) missing final object never gets a ready call | passed | `trusted-state.test.ts`；mock transport，无 Supabase |
| U024 | trusted upload orchestration (mock transport; no Supabase) corrupt stored bytes never get a ready call | passed | `trusted-state.test.ts`；mock transport，无 Supabase |
| U025 | trusted upload orchestration (mock transport; no Supabase) uncertain upload outcome retains pending fence even after apparent cleanup | passed | `trusted-state.test.ts`；mock transport，无 Supabase |
| U026 | trusted upload orchestration (mock transport; no Supabase) lost finalization acknowledgement inspects committed state without deleting ready binary | passed | `trusted-state.test.ts`；mock transport，无 Supabase |
| U027 | owner-scoped deletion and retry (mock transport) rejects cross-owner, encoded and dot-segment keys | passed | `trusted-state.test.ts`；mock transport，无 Supabase |
| U028 | owner-scoped deletion and retry (mock transport) failure marks retryable stage; retry clears only A including nested orphan and preserves B | passed | `trusted-state.test.ts`；mock transport，无 Supabase |

## 7. 四项原始缺陷与测试用例对应

| 原始缺陷 | 本轮对应记录 | 证据要点 |
|---|---|---|
| 上传重试不幂等 | H034–H036；L010–L021 | 同 key 顺序/并发同媒体 ID、真实最终对象数 1、不同文件 409、A/B key 隔离；两类提交后丢响应仍复用 |
| pending 缺少恢复入口 | H038–H045、H088–H090；L022–L049 | 实际 DB finalization 异常保留源、可信 worker 恢复；老 pending、双 worker、退避耗尽、真实崩溃与租约到期、旧 token 拒绝 |
| 可信文件替换缺少摘要验证 | H019–H020、H091–H092；L050–L063 | 真实替换/大小/MIME、读取竞态、实际底层字节损坏；服务端真实读回、摘要与版本检查 |
| Storage 丢失仍 ready | H093–H095；L064–L079 | 已知删除转 failed；含糊 500 转 unavailable；真实停服/恢复不误判丢失，头像引用保留 |

R021–R037、H025–H028、L007–L009/L085–L087 共同覆盖可信入口和客户端 Storage 绕过边界；L080–L087 覆盖孤儿与 A/B，L088–L103/H066–H087 覆盖取消、迟到写入、删号及失败重试。

## 8. 并发与真实故障注入

| 类型 | 实际源码行为与记录 | 能证明/不能证明 |
|---|---|---|
| 同 key 并发上传 | 可靠性源第 142–144 行附近 Promise.all 两个实际 Next POST，L015/L017 | 同 ID 且 attempts=1；不是仅 mock 一个并发结果 |
| 双恢复工作者 | workerProcess 以 spawn 启动两个实际 Node worker，L025 断言两者真实 code===0，L027/L029 查真实任务 | 两个子进程退出码 0 有具体断言；不是所有父测试命令退出码的代替证据 |
| 网络应答中断 | 透明本地代理转发真实 Storage/RPC，在上游真实 200 后 destroy 下游；L018–L021 | 已提交但应答丢失恢复；不是公网 DNS/TCP 或生产网络验收 |
| 进程崩溃 | 精确检查本轮 app.pid 对应 next-server，在 finish 转发前 hold，再 process.kill(SIGKILL)，重启同副本、实际等租约到期；L042–L049 | 真实进程被终止并恢复；没有伪造一个 crashed 字段。并未持久保存被杀进程 wait status=137 原件，故不补写 137 |
| TOCTOU | hold-after 真实 GET 字节，可信 Storage update 再 release，L057/L058 | 前后版本/状态变化时拒绝；不是用客户端摘要声明 |
| Storage 暂停 | 精确 Storage 容器 stop/start，L070/L072/L075 | 真实局部后端服务不可用；不是 mock fetch 500 |
| 实际文件变坏/消失 | 精确本轮虚构 owner/key/version 后端文件改一个字节或 unlink，L060–L067 | 检查实际二进制独立于 metadata，含糊 500 保守处理 |
| DB finalize 异常 | H038–H045 本地临时 trigger 真实抛异常后移除 | 已写 Storage、不成功 commit ready 时保留恢复来源 |
| 晚到写入取消 | L088–L095，本地临时 trigger/sequence 暂扣实际 metadata commit，期间确认二进制存在并发起删除 | 删除先拒绝、后提交被屏障拦截、补偿清理后重试；依赖受测后端，不推广为任意 Storage 分布式事务 |

透明代理 `fault-proxy.mjs` 只操作真实上游响应，不生成假的数据库成功结果。原始故障摘要如下，保留没有 status 的事件为空缺，不推测其 HTTP 码。

| 故障 ID | 阶段 | 真实 HTTP 状态 | 北京时间 |
|---|---|---|---|
| storage-ack | upstream-complete | 200 | 2026-11-10T14:03:05.284+08:00 |
| storage-ack | dropped | 200 | 2026-11-10T14:03:05.285+08:00 |
| finish-ack | upstream-complete | 200 | 2026-11-10T14:03:05.952+08:00 |
| finish-ack | dropped | 200 | 2026-11-10T14:03:05.952+08:00 |
| process-crash | held | 未记录 | 2026-11-10T14:03:15.172+08:00 |
| process-crash | cancelled | 未记录 | 2026-11-10T14:03:15.276+08:00 |
| read-race | upstream-complete | 200 | 2026-11-10T14:03:48.046+08:00 |
| read-race | held | 200 | 2026-11-10T14:03:48.046+08:00 |


## 9. SHA256 是否从真实 Storage 字节计算

**是，新的实际上传/读取链路确实由服务端下载对象再计算。** `media-reliability.ts.proposed` 第 44–62 行 snapshot：Storage download → Blob.arrayBuffer → Uint8Array → validateBytes；第 34–42 行 validateBytes 比较实际长度、服务端 digestBytes、MIME、单帧及完整 sharp 解码。`verified-image.ts.proposed` 第 8–9 行用 Node createHash("sha256").update(bytes).digest("hex")。

request_sha 是服务端从原始请求字节计算；expected_sha 是服务端真实解码并规范化后的 bytes 摘要；写入 staging/final 后仍执行真实 Storage readback，比对 expected_sha，不能仅靠请求 SHA 成功就 ready。finish 还核对当前对象 ID/版本及 lease。下载返回已验证的内存快照，不重定向至可被之后替换的 URL。

L061 的“后台实际字节损坏、无 Storage metadata 事件”仍被拒绝，独立验证内容检查没有仅信 ETag/元数据。但未验证所有下载入口：外部既存签名 URL、客户端直接 Storage 读取和其他后端不能自动继承 Next GET 的每次字节校验结论。R031/R032 等旧 service-only RPC 兼容测试也不是这段服务端读回链路的证明，完整链路应看 H020 与 L050–L063。

## 10. 暂不可用与确实不存在的区分

`media-reliability.ts.proposed` 第 28–32 行仅对可信 Admin download 的明确 400/404 且消息严格匹配 not-found 集合识别 absent；第 48–55 行要求第二次同样明确不存在、对象引用前后稳定，才返回 missing。403、超时、普通网络失败和通用 5xx 不作为不存在。

- 真实 UPDATE/DELETE Storage metadata 的触发器使旧验证失效；已知删除/内容改变经 L076–L078、H093–H095 验证为 failed/409。
- 模糊故障经 verifiedDownload 第 137–143 行进入 unavailable/503，保留 SHA/ref；不是 false missing，也不删正常对象。恢复后真实读回再 check_ok，L070–L075 验证重新 ready，头像引用仍在。
- 元数据存在但底层实际文件被 unlink 的受测后端返回通用 500/ENOENT，不可仅凭错误文字断言丢失；L067 正确记录 unavailable。实际无法从这种 500 确证文件永久丢失时，需要后续运营/后端核实。

## 11. 孤儿清理与双用户隔离

**有真实 A/B 检查，但清理边界必须按实际断言理解。** L080/L081 建实际 A 对象，L082 只删其隔离数据库媒体行形成孤儿，L083 通过可信 worker 后 Admin 下载失败，L084 读取 B 实际二进制计数不变，L085/L087 确认跨用户拒绝与 B 自己仍可下载；源码第 247–257 行。L097 进一步检查删号后 A 实际文件数 0，H085/H086 分别检查 A 删除/B 实际二进制不变。

孤儿清理源码第 161–168 行限定两个桶、规范 owner/key、RPC orphan_claim 绑定 ID/版本/lease 后才 Storage remove，orphan_done 再确认；不依据任意客户端路径批量删除。本轮原件中的 L083 直接断言是下载结果 data===null，不是逐个孤儿物理 unlink 审计；实际文件计数和最终 PHYSICAL_STORAGE_CHECK 是附加证据，两者不可混称同一条断言。

该组主要检查 A 的孤儿清理保留 B 的合法文件，不宣称已经覆盖 B 同时有孤儿、跨桶所有未知路径、所有后端删除队列故障或所有长期压力交错。

## 12. 实际命令、退出码证据与缺口

本轮没有执行以下测试命令。命令来自既有 runner、README、测试源和已保存结果；API/角色/可靠性底层命令可由 runner 精确核对。原运行 cwd 为 `/workspace/fitness-g53-ab833666/fitness-os-2.0`；控制脚本从原应用根目录调用。

**恢复后的 `/tmp/fitness-g53-current-plan.json` 已不存在。** 因此无法重新读取当时 mode-0600 局部 profile、私密 stdout/stderr、unit.json 或 runner 当时打印的 exit 记录。本轮不重建这些日志、不从 PASS 倒推每个进程的真实退出码，也不为补日志重新运行测试。

| 历史实际命令/调用 | 已存结果 | 可独立核实的退出码 |
|---|---|---|
| python3 delivery/g5-3/verify-apply-local.py | CANDIDATE_APPLICATION：新完整候选 fresh 应用 PASS | 父进程原始数字退出回执未持久存于交付包；缺失 |
| python3 delivery/g5-3/run-local-check.py roles → node tests/integration/g53-role-regression.mjs | ROLE_TEST_RESULTS：70/PASS | 原父进程退出码未持久保存；缺失 |
| python3 delivery/g5-3/run-local-check.py http → node tests/integration/g53-http.mjs | HTTP_TEST_RESULTS：97/PASS | 原父进程退出码未持久保存；缺失 |
| python3 delivery/g5-3/run-local-check.py reliability → node tests/integration/g53-reliability.mjs | RELIABILITY_TEST_RESULTS：104/PASS | 原父进程退出码未持久保存；缺失 |
| node scripts/media-reconcile-worker.mjs --once（两个真实子进程） | L025 与源代码断言 two.every(code===0) | **两个 0，由已通过的显式断言支持**；原 child stdout 原件未保留 |
| python3 delivery/g5-3/run-local-check.py build → node node_modules/next/dist/bin/next build --webpack | STATIC_CHECK_RESULTS：PASS，build log SHA 已登记 | 原数字退出回执未持久保存；缺失。build 是本地生产模式构建，不是发布 |
| python3 delivery/g5-3/run-local-check.py lint → node node_modules/eslint/bin/eslint.js（参数详见 runner） | STATIC_CHECK_RESULTS：PASS | 原数字退出回执未持久保存；缺失 |
| node node_modules/typescript/bin/tsc --noEmit | STATIC_CHECK_RESULTS：PASS | 原数字退出回执未持久保存；缺失 |
| node node_modules/eslint/bin/eslint.js src/lib/supabase/admin.ts src/lib/account/types.ts tests/unit/media-reliability-sql.test.ts | STATIC_CHECK_RESULTS 附加 lint：PASS | 原数字退出回执未持久保存；缺失 |
| node node_modules/vitest/vitest.mjs run tests/unit/trusted-state.test.ts tests/unit/trusted-state-sql.test.ts tests/unit/media-reliability-sql.test.ts --reporter=json | README 登记命令；UNIT_TEST_RESULTS：28 passed | 原数字退出回执未持久保存；实际命令启动 argv 独立日志缺失，不能声称逐字可还原全部选项 |
| node node_modules/next/dist/bin/next start --hostname 127.0.0.1 --port 3353 | runner 与可靠性恢复源码 | 常驻服务被真实 SIGKILL 后重启；没有原 wait-status，不填猜测数字 |
| python3 delivery/g5-3/stop-owned-local.py | LOCAL_SHUTDOWN：6 容器 stopped | 容器各自记录 exitCode=0；这不是测试父进程退出码 |

新整理过程实际运行 `sha256sum --check --quiet delivery/g5-3/SHA256SUMS`，本轮工具回执退出 0；它只证明文件完整性，不是任何集成测试重跑。已有 STATIC_CHECK_RESULTS 中 type/lint 的空日志 SHA 为 e3b0c442...，只说明登记日志字节为空，不是可恢复的 exit 记录。

runner 保存 stdout/stderr 到 /tmp，打印 exit 后退出；没有将命令 argv/开始结束时间/数字退出码与 stdout/stderr 一并持久化，是本次独立审查的证据缺口。补齐须先找回原工具执行回执或原私密日志归档；无法找回则记录缺失，只有以后另行授权的新验证才能产生新日志，不能冒充历史原件。

## 13. 当时环境版本、时间与作用域

| 项目 | 实际已存值 |
|---|---|
| Cloud environment ID | `ccarenv_b64_Y2NhcmVudl85N2MzZGJlZTljZDQ4MTkxOGQzMjk1NTBiNWY1YWQ0YQ` |
| 本地项目 | `fitness-os-acl-audit-g53-ab833666` |
| PostgreSQL server | `17.11` |
| Docker | `28.4.0` |
| node | `v24.19.0` |
| next | `16.4.4` |
| typescript | `5.9.3` |
| vitest | `5.1.0` |
| sharp | `0.35.5` |
| db 镜像 | `supabase/postgres:17.11.0.011` |
| inbucket 镜像 | `axllent/mailpit:v1.31.3` |
| auth 镜像 | `supabase/gotrue:v2.197.0` |
| rest 镜像 | `postgrest/postgrest:v16.5` |
| storage 镜像 | `supabase/storage-api:v1.88.0` |
| kong 镜像 | `kong:2.8.1` |

精确容器 ID、标签在 LOCAL_VERSIONS 中；数据库容器为 `f1a4acfd76177c6673e202e301e696e7ac8d4931b216753ec7f644ead0865f44`。本地回环 API 58321、代理 58421、Next 3353、Mailpit 58324。真实 Supabase Auth/REST/Storage 手动编排，未把普通 PostgreSQL 模型当成完整集成；同时也不宣称包含 Realtime/Edge/S3/TUS 等完整平台。

时间来自 EXECUTION_TIMELINE：开始基准 2026-11-10T12:54:25.590634+08:00；最终可靠性完成 2026-11-10T14:04:15.011+08:00；目录快照 14:08:11.404179+08:00。这是既有记录，不是本次重跑时间。不能为没有记录的每个 case 补造开始/结束时间或响应正文。

## 14. 审查结论

现存逐项 JSON 可核对：70/97/104 的已登记断言均通过，28 离线断言均 passed；四缺陷映射、真实故障源码和代理事件、Storage 字节校验与双用户隔离证据均有对应原件，三个指定原件的 SHA 与历史交付清单一致。

**结果原件核对：PASS；历史命令/数字退出码与私密原始日志的完整独立复核：PENDING（证据缺失）；托管生产验收/正式迁移：PENDING，未批准、未执行。** 不因只有结果摘要就把缺失的原始退出回执补成 0。本报告不变更此前代码，不重新授予生产迁移或后续阶段权限。
