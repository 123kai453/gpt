# G5.3 真实故障与清理证据

生成时间：2026-11-11T20:03:31.938730+08:00（北京时间）。

本轮副本：`/workspace/fitness-g53-audit-a4774697/fitness-os-2.0`；独立基准commit `6b86090beef3909efa90e0055b1268711b1d97a8`。原仓库仍为 `/workspace/fitness-os-phase2`，分支 `delivery/phase2-hosted-migration-plan`，HEAD `be66fc7a52dc35de9443419bba580845b530be4a`。上一轮独立副本 HEAD `cf75281e39fec4db623b163619db2fec5e14da12`；原447文件和上一轮3418文件本轮结束逐项哈希、分支/HEAD/status/diff/cached diff均未改变，旧6.6MB压缩包也未改变。

本轮使用全新本地 PostgreSQL17.11、Auth2.197.0、Storage1.88.0、PostgREST16.5、Kong2.8.1、Mailpit1.31.3官方缓存镜像，独立网络/卷/新UUID用户；API60321、代理60421、Next3553、Mailpit60324均只绑定127.0.0.1。Node/Next/TS/Chromium的实际版本见LOCAL_VERSIONS.json。未安装工具、升级依赖或连接生产。新本地注册启用自动确认，仅虚构 `.invalid` 地址；真实邮箱验证不在验收范围。

| 场景 | 实际注入/操作 | 真实观察 |
|---|---|---|
| Storage删除失败 | setLocalStorageDeleteFault创建本轮临时BEFORE DELETE触发器 | API503、原文件/Auth/任务保留；解除后自动重试、二进制0/Auth404、B不受影响 |
| 丢Storage/DB应答 | 本轮60421代理在真实上游提交后丢弃回应 | 同一幂等ID找回原任务和对象，无重复 |
| 进程崩溃 | 核对身份后SIGKILL真实Next | processing持久化、活租约不抢占、真实30秒到期后新worker从真实文件恢复，旧token拒绝 |
| 迟到上传/未知I/O | 真实存储写入配合本地受控SQL延迟，过期租约并同时申请删除 | 未知结果阻止误报成功，原请求确定终止才结算并安全删；无对象但io_pending仍独立阻止Auth删除 |
| TOCTOU | 下载已取字节时实际替换Storage对象 | ID/version/当前引用变化被识别，拒绝旧证明 |
| 真实字节损坏 | 仅定位当前合成对象的实际backend/version文件并翻转字节 | 元数据不变仍因服务端重新SHA而拒绝 |
| 真实缺失/临时不可用 | API实际移除对象；另停再起本轮Storage容器、模糊provider500 | 确认缺失failed；临时故障unavailable/503、保留证明与头像，健康后复验恢复 |
| 后页公平性/清理 | 超过10项pending/ready、12个孤儿前11个A删除受故障 | worker重启和两worker能扫后页；B合法文件保留，后续B孤儿不被A前页失败饿死 |
| 测试中途受控失败 | 真实A/B、文件、故障触发器/函数/序列后故意断言失败 | FAIL/exit1/完整堆栈；finally每步独立、所有夹具清理，Next实际退出 |
| 测试空结果 | 真实node子进程exit0且无结果文件 | 驱动FAIL/exit1，不算业务PASS；无DB/用户资源创建 |
| 内部异常误导文本 | 实际SQL主XX000，message含42501 | 新分类拒绝该内部异常，不误报权限PASS |
| 子进程超时/环境 | 真node定时循环触发timeout；父进程放虚构敏感哨兵 | 子进程不继承无关哨兵，超时SIGKILL并回收/记录 |

原始故障事件在NETWORK_FAULT_EVIDENCE.jsonl；每个SQL/进程/HTTP的实际状态在各run/CHILD_RESULTS.jsonl、SUITE_RESULT.json、COMMAND.json。监督进程实际退出时间早于结果生成时间，见SUPERVISOR_ORDER_EVIDENCE.json；监督包装进程随服务停止返回1是实际生命周期记录，不伪报0。

最终只读目录：Auth0、Storage对象0；13张用户相关表0，5行全局维护游标是设计状态；两桶真实二进制0、Mailpit实际0。所有临时测试函数/触发器/序列均核对无残留；清理逐项失败会阻止整体PASS。仅停止本轮6容器，卷和网络保留；其他容器停止阶段身份/状态未变。最终扫当前应用cwd，排除检查器真实祖先链后无残留进程，未杀未知进程或删除未知卷。

历史相同56db SQL的事务/重复initial回滚证据单独复核并标为HISTORICAL，不重新重置本轮数据库、不混算为本轮通过数。所有故障均限合成数据与新本地服务，未用模拟结果冒充数据库/Storage集成。

## 保留的边界与生产门禁

租约过期不代表远端写入结束。未知I/O没有终止回应或匹配提交标记时，系统继续阻止删除，不能为了恢复可用性盲目释放屏障；若进程已消失且没有可核实终止证据，仍可能需要受控人工核实。已经验证“不误报成功”的安全合同，没有声称所有未知provider结果都能自动恢复。

当前Storage1.88.0为真实本地文件后端；托管版对象version/user_metadata/canUpload和删除补偿仍需独立只读核对及后续授权测试。没有将本地测试、事务回滚或浏览器路由200冒充生产验收、完整备份恢复，或训练/营养/AI/穿戴模块已完工。

生产门禁只能是PENDING：尚缺最新生产只读核查、托管Storage兼容性、生产凭据与worker配置、正式数据库备份、Storage文件备份、完整恢复演练、迁移审批、正式部署和真实用户验收。历史public-only归档/9个TOC/pg_restore --list不是完整数据库恢复证明；Windows私密原件和原始云端管理元数据的缺口不能由本轮补造。

本轮SQL哈希仍为 `56db7fe0b71ebfc2ffa5a6e6d7c57508da500014e8e6b185bc6db0334b96488d`，无新SQL候选或生产迁移。它是独立完整initial，只在本轮空白本地实例应用一次，不与旧initial连续执行；正式目标若已初始化，后续须根据新快照另做前向迁移。

没有生产连接/SQL、db push、dry-run、部署、Secret修改、真实邮件或购买。停止在G5.3；G5.4/G5.5/PHASE2.1 BRAND STUDIO/PHASE3均未启动，后续既定阶段保留。
