# G5.3 历史、已交付和当前版本比较

生成时间：2026-11-11T20:03:31.938730+08:00（北京时间）。

本轮副本：`/workspace/fitness-g53-audit-a4774697/fitness-os-2.0`；独立基准commit `6b86090beef3909efa90e0055b1268711b1d97a8`。原仓库仍为 `/workspace/fitness-os-phase2`，分支 `delivery/phase2-hosted-migration-plan`，HEAD `be66fc7a52dc35de9443419bba580845b530be4a`。上一轮独立副本 HEAD `cf75281e39fec4db623b163619db2fec5e14da12`；原447文件和上一轮3418文件本轮结束逐项哈希、分支/HEAD/status/diff/cached diff均未改变，旧6.6MB压缩包也未改变。

本轮使用全新本地 PostgreSQL17.11、Auth2.197.0、Storage1.88.0、PostgREST16.5、Kong2.8.1、Mailpit1.31.3官方缓存镜像，独立网络/卷/新UUID用户；API60321、代理60421、Next3553、Mailpit60324均只绑定127.0.0.1。Node/Next/TS/Chromium的实际版本见LOCAL_VERSIONS.json。未安装工具、升级依赖或连接生产。新本地注册启用自动确认，仅虚构 `.invalid` 地址；真实邮箱验证不在验收范围。

## 文件与完整性

实际检查四份G5_3最终报告、PATCH_TARGETS/ARTIFACT_MANIFEST/SHA256SUMS及运行原件。上一轮manifest的3066条实际文件SHA全部匹配；登记旧SQL56ec、最终SQL56db、旧最终API补丁6bc02均匹配，详见VERSION_COMPARISON.json。当前原仓库没有突然获得G5.3运行代码；实际整合一直在独立副本中，不能把原分支HEAD当最终运行源码版本。

历史上传测试原件在 `delivery/g5-3/files/tests/integration/g53-reliability.mjs.proposed`，业务原件在 `delivery/g5-3/files/src/lib/account/media-reliability.ts.proposed`；最新运行文件分别为 `tests/integration/g53-reliability.mjs`、`src/lib/account/media-reliability.ts`。完整旧原件→已交付差异保存在两个 `.historical-to-delivered.diff`，本轮已交付→当前差异在 `current-round.proposed.patch`。不覆盖任何旧原件或登记SHA。

本轮85个src/及scripts/业务文件与上一轮最终交付字节相同，业务源码修改0；最终SQL未变。新代码仅补测试与构建证据边界：21个目标文件（含9个新执行/取证脚本），完整整合相对原项目47个目标。两份补丁均git apply --check实际退出0，未应用回受保护工作区；`complete.proposed.patch`用于原项目基准，`current-round.proposed.patch`用于已经拥有上一轮最终代码的副本，不能混用或连续应用。

## 历史问题如何归类

按本报告明确列出的27个既有检查条目计：17项业务合同、5项主测试能力已经修复（22项ALREADY_FIXED）；5组剩余工具缺口初查为CONFIRMED_ISSUE，本轮定向修复并重新验证。没有把旧脚本缺陷未经核实贴到最终业务代码上。

Mailpit58324属于最初G5.3实例，59324属于上一轮最终实例；两者不同本身不证明旧结果错误。原件端口绑定和旧MAIL_CHECK支持这一点。真实问题是新实例仍沿用硬编码，缺少当前Mailpit的完整身份/端口核验；本轮60324实测，旧URL在发送请求前被拒绝。证据见PORT_PROVENANCE.json。

文字要求中的`createVerifiedMedia`在实际src中不存在；实际遗留helper名为`uploadVerifiedMedia`，仅定义于trusted-state.ts。公开POST上传调用submitUpload，GET调用verifiedDownload；旧server_media_write的deleting/remove仍用于正规删除，不能简单移除整个RPC。没有发现未经审查的公开begin/ready调用入口，完整搜索结果和业务源哈希见BUSINESS_SOURCE_PRESERVATION.json及下文业务报告。

## 保留的边界与生产门禁

租约过期不代表远端写入结束。未知I/O没有终止回应或匹配提交标记时，系统继续阻止删除，不能为了恢复可用性盲目释放屏障；若进程已消失且没有可核实终止证据，仍可能需要受控人工核实。已经验证“不误报成功”的安全合同，没有声称所有未知provider结果都能自动恢复。

当前Storage1.88.0为真实本地文件后端；托管版对象version/user_metadata/canUpload和删除补偿仍需独立只读核对及后续授权测试。没有将本地测试、事务回滚或浏览器路由200冒充生产验收、完整备份恢复，或训练/营养/AI/穿戴模块已完工。

生产门禁只能是PENDING：尚缺最新生产只读核查、托管Storage兼容性、生产凭据与worker配置、正式数据库备份、Storage文件备份、完整恢复演练、迁移审批、正式部署和真实用户验收。历史public-only归档/9个TOC/pg_restore --list不是完整数据库恢复证明；Windows私密原件和原始云端管理元数据的缺口不能由本轮补造。

本轮SQL哈希仍为 `56db7fe0b71ebfc2ffa5a6e6d7c57508da500014e8e6b185bc6db0334b96488d`，无新SQL候选或生产迁移。它是独立完整initial，只在本轮空白本地实例应用一次，不与旧initial连续执行；正式目标若已初始化，后续须根据新快照另做前向迁移。

没有生产连接/SQL、db push、dry-run、部署、Secret修改、真实邮件或购买。停止在G5.3；G5.4/G5.5/PHASE2.1 BRAND STUDIO/PHASE3均未启动，后续既定阶段保留。
