"""Read executed evidence and write reports; never connects to any database."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess
from zoneinfo import ZoneInfo
app=Path(__file__).resolve().parents[2];out=app/'delivery/g5-3-final-audit';previous=Path('/workspace/fitness-g53-final-227cfffd/fitness-os-2.0')
now=datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat();load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,j):(out/name).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
env={k:os.environ[k] for k in ('PATH','HOME','USER','LANG','DOCKER_CONFIG') if k in os.environ}
protected=[]
for baseline in load(out/'WORKSPACE_BASELINE.json'):
 root=Path(baseline['root']);checks={};changed=[]
 for key,args in [('head',['rev-parse','HEAD']),('branch',['branch','--show-current']),('status',['status','--porcelain=v1','--untracked-files=all']),('diff',['diff','--binary']),('cached',['diff','--cached','--binary'])]:
  data=subprocess.check_output(['git','-C',str(root),*args],env=env);checks[key]=hashlib.sha256(data).hexdigest()==baseline[key+'_sha256']
 for name,h in baseline['files'].items():
  p=root/name
  if not p.is_file() or sha(p)!=h:changed.append(name)
 assert all(checks.values()) and not changed
 protected.append({'root':str(root),'status':'PASS','files_verified':len(baseline['files']),'git_checks':checks,'changed_or_missing':changed,'baseline_head':baseline['head'].strip(),'baseline_branch':baseline['branch'].strip()})
save('ORIGINAL_WORKSPACE_PRESERVATION.json',{'observed_at':now,'status':'PASS','repositories':protected,'old_archive_unchanged':sha(previous.parent/'G5_3_FINAL_DELIVERY.tar.gz')=='35608b33e237a9ae5e194be990249db5c7acc2737e9da6f18bf25290bd8b1a69'})
manifest=load(out/'SOURCE_MANIFEST.json');core={x['path']:x['sha256'] for x in manifest['files']};assert len(core)==134 and all(sha(app/k)==v for k,v in core.items())
attempts=[(p,load(p/'COMMAND.json')) for p in sorted((out/'runs').iterdir()) if (p/'COMMAND.json').exists()]
selected=[]
for mode in ['unit','controls','roles','http','reliability','extra','boundary','browser','ui-lifecycle','typecheck','lint','build']:
 valid=[(p,j) for p,j in attempts if j['mode']==mode and j['status']=='PASS' and not j.get('expected_failure_probe') and not j.get('expected_missing_evidence_control') and j.get('source_hashes_before')==core and j.get('source_hashes_after')==core]
 assert valid,'No final actual passing execution for '+mode
 p,j=valid[-1];assert j['exit_code']==j['driver_exit_code']==0
 rows=[];cleanup=None
 if (p/'SUITE_RESULT.json').exists():
  s=load(p/'SUITE_RESULT.json');assert s['status']=='PASS' and s['cleanup']['status']=='PASS' and not s['cleanup']['errors'] and not s['cleanup']['residuals'];cleanup=s['cleanup']
  for i,c in enumerate(s['checks'],1):
   label=c if isinstance(c,str) else c['label'];t=s['timings'][i-1];rows.append({'id':mode+'-'+str(i).zfill(3),'name':label,'objective':label,'status':'PASS','command':j['command'],'exit_code':0,'started_at':t['started_at'],'ended_at':t['ended_at'],'timing_scope':t['timing_scope']})
 elif mode=='unit':
  u=load(p/'UNIT_RESULTS.json');assert u['numTotalTests']==u['numPassedTests']==108 and u['numFailedTests']==0
  for file in u['testResults']:
   for c in file['assertionResults']:
    assert c['status']=='passed';rows.append({'id':'unit-'+str(len(rows)+1).zfill(3),'name':c['fullName'],'objective':c['title'],'status':'PASS','command':j['command'],'exit_code':0,'duration_ms':c.get('duration'),'file':str(Path(file['name']).relative_to(app)),'timing_scope':'actual Vitest duration; suite start/end below'})
 selected.append({'mode':mode,'status':'PASS','command':j['command'],'cwd':str(app),'started_at':j['started_at'],'ended_at':j['ended_at'],'exit_code':0,'driver_exit_code':0,'evidence_directory':str(p.relative_to(app)),'registered_checks':len(rows),'checks':rows,'cleanup':cleanup,'source_hashes_before':j['source_hashes_before'],'source_hashes_after':j['source_hashes_after']})
counts={x['mode']:x['registered_checks'] for x in selected if x['checks']};assert sum(counts.values())==774
negative=[]
for p,j in attempts:
 if j.get('expected_failure_probe'):
  s=load(p/'SUITE_RESULT.json');assert j['exit_code']==j['driver_exit_code']==1 and s['status']=='FAIL' and s['cleanup']['status']=='PASS' and s['failure']['stack'] and not s['cleanup']['errors'] and not s['cleanup']['residuals']
  negative.append({'control':'intentional assertion with actual users/files/fault objects','expected_result':'FAIL','actual_result':'FAIL','child_exit_code':1,'driver_exit_code':1,'failure':s['failure'],'cleanup':s['cleanup'],'setup_checks_before_failure':s['assertions'],'evidence_directory':str(p.relative_to(app))})
 if j.get('expected_missing_evidence_control'):
  assert j['status']=='FAIL' and j['exit_code']==0 and j['driver_exit_code']==1 and j['error']['name']=='MissingSuiteEvidence'
  negative.append({'control':'child exits zero without any structured suite evidence','expected_result':'FAIL','actual_result':'FAIL','child_exit_code':0,'driver_exit_code':1,'driver_error':j['error'],'child_exception_stack':'NOT_APPLICABLE: no child exception; normal zero exit is the negative control','cleanup':'NOT_APPLICABLE: creates no users, objects or service','evidence_directory':str(p.relative_to(app))})
assert len(negative)==2
save('META_CONTROL_RESULTS.json',{'meta_validation':'PASS','underlying_controls':negative,'not_added_to_business_pass_count':True})
catalog=load(out/'LOCAL_CATALOG_SNAPSHOT.json');versions=load(out/'LOCAL_VERSIONS.json');shutdown=load(out/'LOCAL_SHUTDOWN.json');assert shutdown['status']=='PASS' and load(out/'FINAL_PROCESS_CHECK.json')['status']=='PASS'
targets=load(out/'PATCH_TARGETS.json');assert len(targets['current_round_changes'])==21 and len(targets['full_integration_changes'])==47
business=load(out/'BUSINESS_SOURCE_PRESERVATION.json');assert business['status']=='PASS' and len(business['files'])==85
oldrollback=app/'delivery/g5-3-final/FINAL_MIGRATION_ROLLBACK_REPORT.json';assert load(oldrollback)['candidate_sha256']==core['supabase/reviews/20261110000200_account_upload_reliability.final_proposed.sql']
save('REUSED_EVIDENCE.json',{'scope':'historical evidence reused only where the reviewed SQL bytes and platform versions are unchanged; never included as this round executions','items':[{'path':str(oldrollback.relative_to(app)),'sha256':sha(oldrollback),'status':'HISTORICAL_VERIFIED_BYTES','reason':'same 56db candidate; atomic rollback/repeated-initial behavior already tested. No need to reset this new local instance again.'}],'previous_759_passes_not_counted_as_current':True})
timeline=[];chosen={x['evidence_directory'] for x in selected}
for p,j in attempts:
 row={k:j.get(k) for k in ['mode','command','started_at','ended_at','status','exit_code','driver_exit_code','error','checks','cleanup_status','expected_failure_probe','expected_missing_evidence_control']};row['evidence_directory']=str(p.relative_to(app));row['selected_final']=row['evidence_directory'] in chosen
 row['category']='service lifecycle, not business PASS/FAIL' if j['mode'] in ['start','proxy'] else 'expected negative control' if j.get('expected_failure_probe') or j.get('expected_missing_evidence_control') else 'final execution' if row['selected_final'] else 'earlier development attempt, preserved without replacement'
 timeline.append(row)
save('EXECUTION_TIMELINE.json',{'all_attempts':timeline,'development_notes':['First new typecheck/build failed because minimalChildEnv declaration was missing and archived failing TS snapshots were active compiler input. Fixed declaration and excluded only delivery/**/runs/**/source/**; strict and active source/tests remain checked.','Initial final process sweep flagged the sandbox launcher ancestor. Corrected to exclude actual OS ancestry; no unknown process was killed.'],'no_failed_records_deleted':True})
gates={'A_business':'PASS','B_test_trustworthiness':'PASS','C_local_security_reliability':'PASS','D_original_workspace_protection':'PASS','E_production_migration_backup_restore':'PENDING'}
final={'generated_at':now,'gates':gates,'workspace':str(app),'environment':'fresh isolated official local Supabase services, real Next.js and Chromium','counts':counts,'total_registered_pass':774,'business_fail':0,'critical_blocked':0,'offline_unit_tests':108,'live_registered_assertions':666,'counting_note':'Registered assertions include setup/observer checks and are not 774 distinct business scenarios; expected negative-control failures and service SIGTERM exits are counted separately.','negative_controls':negative,'selected_executions':selected,'versions':versions,'sql_sha256':core['supabase/reviews/20261110000200_account_upload_reliability.final_proposed.sql'],'source_manifest_sha256':sha(out/'SOURCE_MANIFEST.json'),'source_file_count':134,'code_patches':load(out/'PATCH_APPLICABILITY.json'),'runtime_business_files_unchanged':85,'current_round_changed_targets':21,'complete_integration_targets':47,'historical_delivery_manifest_entries_verified':3066,'cleanup_evidence':{'auth_users':catalog['auth_users'],'storage_objects':catalog['storage_objects'],'row_counts':catalog['row_counts'],'physical_binary_files':load(out/'PHYSICAL_STORAGE_CHECK.json'),'mail':load(out/'MAIL_CHECK.json'),'shutdown':'PASS','residual_process_check':'PASS'},'production_connections':False,'production_sql':False,'production_migration':False,'deployment':False,'remaining_production_items':['fresh read-only hosted database snapshot','hosted Storage version compatibility','production credentials and worker configuration','formal database backup','Storage binary backup','complete isolated restore drill','explicit production migration approval','deployment and real user acceptance'],'historical_evidence_not_relabelled_as_current':True}
save('FINAL_TEST_RESULTS.json',final)

tools_already=[('T01','worker/replacement child environment','tests/integration/g53-reliability.mjs workerProcess/replacementServer already used explicit minimalChildEnv'),('T02','REST/Storage denial distinctions','tests/helpers/g53-evidence.mjs strictDenied already checks HTTP/type/SQLSTATE'),('T03','paged teardown/Auth and physical file checks','cleanupFixtures already drains pages and fails on residuals'),('T04','owned Next identity before kill','assertOwnedServer already checks PID, start ticks, exact cmdline and cwd'),('T05','actual before/after source hashes','SOURCE_MANIFEST and runner already calculate files, not just cfg.candidateSha256')]
confirmed=[('C01','legacy observer/fault subprocess boundary and diagnostics','tests/helpers/local-acl-observer.mjs; local-acl-faults.mjs','The main runner was sanitized, but direct legacy helper calls used process.env minus a blacklist and discarded useful child errors.','g53-process.mjs central whitelist, bounded child execution, actual exit/stdout/stderr and append-only redacted JSONL. No actual production credential leakage was observed.'),('C02','raw SQL permission substring accepted false proof','tests/integration/g53-http.mjs and g53-final-security.mjs sqlDenied','Nonzero psql plus any occurrence of 42501 could accept primary XX000 with misleading text.','Require psql exit3, no timeout/signal and primary verbose ERROR SQLSTATE42501. Actual XX000 containing42501 is rejected.'),('C03','hardcoded Mailpit endpoint and incomplete ownership binding','mail checks and auditedFetch in tests/helpers/g53-evidence.mjs','58324 and59324 belong to different historical instances; no evidence the prior59324 result was fabricated. Current helpers nevertheless hardcoded it instead of current config.','Current mailUrl60324, owned Mailpit ID/name/labels/running/port binding checked; reject old endpoint before request.'),('C04','final PASS generated before replacement supervisor termination','tests/integration/g53-reliability.mjs finally','finish wrote the result before waiting for the replacement runner; a later failure could escape final status.','Wait/capture supervisor inside the cleanup callback, before finish decides status; actual exit operation timestamp precedes suite result.'),('C05','zero child exit without result could become driver PASS','delivery/g5-3-final/run-command.py','A suite exiting0 without SUITE_RESULT could satisfy the generic driver success condition.','Mandatory structured result for integration modes; actual child exit0/no output is FAIL with driver exit1.')]
business_items=['upload idempotency, raw bytes conflict and tombstone','same request concurrency and A/B scoping','actual PNG/JPEG/WebP decode and limits','server-computed raw and normalized SHA256','Storage object id/version/current reference','pending/processing/ready/unavailable/failed/deleting transitions','independent I/O operation receipts','30s lease, expired lease and old worker fencing','lost Storage/DB acknowledgement recovery','durable sweep cursor and retry fairness','orphan/staging retries and owner isolation','media/account cancellation and deletion barrier','password reauthentication before trusted cleanup authorization','owner/job-bound cleanup authorization and retry','actual Auth Admin deletion plus binary/SQL verification','real A/B RLS and file isolation','RLS/ACL/SECURITY DEFINER and server-only RPC scope']
issues={'counting_scope':'27 preexisting review items: 17 business contracts and 10 test-framework concerns','already_fixed_count':22,'confirmed_initial_issues_fixed_this_round':5,'unresolved_confirmed_local_issues':0,'already_fixed':[{'id':i,'topic':t,'evidence':e,'classification':'ALREADY_FIXED'}for i,t,e in tools_already]+[{'id':'B'+str(i).zfill(2),'topic':name,'classification':'ALREADY_FIXED','current_revalidation':'PASS in selected live suites'}for i,name in enumerate(business_items,1)],'fixed_this_round':[{'id':i,'topic':t,'source':src,'initial_classification':'CONFIRMED_ISSUE','finding':finding,'resolution':resolution,'final_status':'FIXED_THIS_ROUND'}for i,t,src,finding,resolution in confirmed],'unverified':[{'topic':'production state, backups and hosted compatibility','classification':'UNVERIFIED','gate':'PENDING'},{'topic':'unbounded provider outcome cannot be resolved from lease expiry alone','classification':'UNVERIFIED for automatic eventual recovery without terminal proof; documented fail-closed behavior itself tested','gate':'production operational limitation, not a claim of exposed user data'}],'development_corrections_this_round':['missing minimalChildEnv declaration for new tests','archived evidence source snapshots included in TypeScript compilation','process inventory checker needed actual ancestor-chain exclusion'],'not_claimed_as_prior_business_defects':True}
save('ISSUES.json',issues)
def write(name,text):(out/name).write_text(text)
table='| 类别 | 实际结果 | 数量 | 命令退出码 | 北京时间开始 / 结束 | 证据 |\n|---|---|---:|---:|---|---|\n'
for s in selected:table+='| '+s['mode']+' | PASS | '+str(s['registered_checks'] or '检查命令')+' | 0 | '+s['started_at']+' / '+s['ended_at']+' | `'+s['evidence_directory']+'/COMMAND.json` |\n'
context='''生成时间：'''+now+'''（北京时间）。

本轮副本：`'''+str(app)+'''`；独立基准commit `6b86090beef3909efa90e0055b1268711b1d1d97a8`（实际值以WORKSPACE_BASELINE/Git检查及下文更正字段为准）。原仓库仍为 `/workspace/fitness-os-phase2`，分支 `delivery/phase2-hosted-migration-plan`，HEAD `be66fc7a52dc35de9443419bba580845b530be4a`。上一轮独立副本 HEAD `cf75281e39fec4db623b163619db2fec5e14da12`；原447文件和上一轮3418文件本轮结束逐项哈希、分支/HEAD/status/diff/cached diff均未改变，旧6.6MB压缩包也未改变。

本轮使用全新本地 PostgreSQL17.11、Auth2.197.0、Storage1.88.0、PostgREST16.5、Kong2.8.1、Mailpit1.31.3官方缓存镜像，独立网络/卷/新UUID用户；API60321、代理60421、Next3553、Mailpit60324均只绑定127.0.0.1。Node/Next/TS/Chromium的实际版本见LOCAL_VERSIONS.json。未安装工具、升级依赖或连接生产。新本地注册启用自动确认，仅虚构 `.invalid` 地址；真实邮箱验证不在验收范围。
'''
# Derive the actual baseline commit rather than repeating historical context typos.
actual_head=subprocess.check_output(['git','-C',str(app.parent),'rev-parse','HEAD'],env=env,text=True).strip()
context=context.replace('6b86090beef3909efa90e0055b1268711b1d1d97a8`（实际值以WORKSPACE_BASELINE/Git检查及下文更正字段为准）',actual_head+'`')
limits='''## 保留的边界与生产门禁

租约过期不代表远端写入结束。未知I/O没有终止回应或匹配提交标记时，系统继续阻止删除，不能为了恢复可用性盲目释放屏障；若进程已消失且没有可核实终止证据，仍可能需要受控人工核实。已经验证“不误报成功”的安全合同，没有声称所有未知provider结果都能自动恢复。

当前Storage1.88.0为真实本地文件后端；托管版对象version/user_metadata/canUpload和删除补偿仍需独立只读核对及后续授权测试。没有将本地测试、事务回滚或浏览器路由200冒充生产验收、完整备份恢复，或训练/营养/AI/穿戴模块已完工。

生产门禁只能是PENDING：尚缺最新生产只读核查、托管Storage兼容性、生产凭据与worker配置、正式数据库备份、Storage文件备份、完整恢复演练、迁移审批、正式部署和真实用户验收。历史public-only归档/9个TOC/pg_restore --list不是完整数据库恢复证明；Windows私密原件和原始云端管理元数据的缺口不能由本轮补造。

本轮SQL哈希仍为 `56db7fe0b71ebfc2ffa5a6e6d7c57508da500014e8e6b185bc6db0334b96488d`，无新SQL候选或生产迁移。它是独立完整initial，只在本轮空白本地实例应用一次，不与旧initial连续执行；正式目标若已初始化，后续须根据新快照另做前向迁移。

没有生产连接/SQL、db push、dry-run、部署、Secret修改、真实邮件或购买。停止在G5.3；G5.4/G5.5/PHASE2.1 BRAND STUDIO/PHASE3均未启动，后续既定阶段保留。
'''
write('VERSION_COMPARISON.md','# G5.3 历史、已交付和当前版本比较\n\n'+context+'''
## 文件与完整性

实际检查四份G5_3最终报告、PATCH_TARGETS/ARTIFACT_MANIFEST/SHA256SUMS及运行原件。上一轮manifest的3066条实际文件SHA全部匹配；登记旧SQL56ec、最终SQL56db、旧最终API补丁6bc02均匹配，详见VERSION_COMPARISON.json。当前原仓库没有突然获得G5.3运行代码；实际整合一直在独立副本中，不能把原分支HEAD当最终运行源码版本。

历史上传测试原件在 `delivery/g5-3/files/tests/integration/g53-reliability.mjs.proposed`，业务原件在 `delivery/g5-3/files/src/lib/account/media-reliability.ts.proposed`；最新运行文件分别为 `tests/integration/g53-reliability.mjs`、`src/lib/account/media-reliability.ts`。完整旧原件→已交付差异保存在两个 `.historical-to-delivered.diff`，本轮已交付→当前差异在 `current-round.proposed.patch`。不覆盖任何旧原件或登记SHA。

本轮85个src/及scripts/业务文件与上一轮最终交付字节相同，业务源码修改0；最终SQL未变。新代码仅补测试与构建证据边界：21个目标文件（含9个新执行/取证脚本），完整整合相对原项目47个目标。两份补丁均git apply --check实际退出0，未应用回受保护工作区；`complete.proposed.patch`用于原项目基准，`current-round.proposed.patch`用于已经拥有上一轮最终代码的副本，不能混用或连续应用。

## 历史问题如何归类

按本报告明确列出的27个既有检查条目计：17项业务合同、5项主测试能力已经修复（22项ALREADY_FIXED）；5组剩余工具缺口初查为CONFIRMED_ISSUE，本轮定向修复并重新验证。没有把旧脚本缺陷未经核实贴到最终业务代码上。

Mailpit58324属于最初G5.3实例，59324属于上一轮最终实例；两者不同本身不证明旧结果错误。原件端口绑定和旧MAIL_CHECK支持这一点。真实问题是新实例仍沿用硬编码，缺少当前Mailpit的完整身份/端口核验；本轮60324实测，旧URL在发送请求前被拒绝。证据见PORT_PROVENANCE.json。

文字要求中的`createVerifiedMedia`在实际src中不存在；实际遗留helper名为`uploadVerifiedMedia`，仅定义于trusted-state.ts。公开POST上传调用submitUpload，GET调用verifiedDownload；旧server_media_write的deleting/remove仍用于正规删除，不能简单移除整个RPC。没有发现未经审查的公开begin/ready调用入口，完整搜索结果和业务源哈希见BUSINESS_SOURCE_PRESERVATION.json及下文业务报告。

'''+limits)
issue_md='# G5.3 已确认问题与归类\n\n'+context+'\n## 已交付版本已修复的能力\n\n| 编号 | 项目 | 初查分类 | 当前验证 |\n|---|---|---|---|\n'
for row in issues['already_fixed']:issue_md+='| '+row['id']+' | '+row['topic']+' | ALREADY_FIXED | PASS（本轮重验） |\n'
issue_md+='\n## 本轮确认并修复的5组工具问题\n\n'
for i,t,src,finding,resolution in confirmed:issue_md+='### '+i+' '+t+'\n\n位置：`'+src+'`。初查：CONFIRMED_ISSUE；结束：FIXED_THIS_ROUND。\n\n'+finding+'\n\n'+resolution+'\n\n'
issue_md+='''## 本轮开发错误与未验证事项

新增测试漏minimalChildEnv的.d.mts声明，首次typecheck/build实际失败；同时编译器收录了历史失败TS快照。已补声明、只排除delivery/**/runs/**/source/**；strict、当前src、当前tests仍检查，新增单元断言保护该范围。失败原件未删除。末尾进程清点第一次把Codex sandbox启动祖先识别为残留，已按真实/proc祖先链排除检查器自身；两个清点均未杀未知进程，FINAL_PROCESS_CHECK有说明。

追加式JSONL避免多个测试进程对同一日志做读改写；这是结构加固，未声称观察到旧日志已丢行。未发现当前业务源码需要重写的已证实新缺陷。生产相关项及无终止证据的未知I/O自动最终恢复标记UNVERIFIED/生产PENDING，不夸大为已利用漏洞。

'''+limits
write('CONFIRMED_ISSUES.md',issue_md)
write('TEST_HARDENING_REPORT.md','# G5.3 测试可信度修复报告\n\n'+context+'''
## 本轮实际修改

- 新g53-process.mjs统一子进程白名单、超时、回收、真实退出码、stdout/stderr、脱敏、明确输出预算与截断失败；旧observer/fault helpers也使用此路径，不再仅删几个已知变量。保留HOME/DOCKER_CONFIG原值，不改全局设置。
- rawSql在每次SQL前核对本次容器；权限断言读取psql verbose ERROR主SQLSTATE，不匹配任意消息里的42501。真实XX000含42501的反例已执行，不能误报PASS。
- Mailpit完全从当前profile取地址；检查本次容器ID/name/labels/running、真实8025映射，再请求计数。未启动服务时不会凭空报0。
- Next杀进程保留PID/start_ticks/完整cmdline/cwd检查；替代监督进程退出现在纳入cleanup，先完成退出观察再决定PASS。所有worker/SQL/Docker子命令有界、记录退出；JSONL追加取代易竞态的日志读改写。
- 集成模式缺少结构化结果时，即使子进程exit0也FAIL。真实负向控制child0/driver1保留，不伪造异常堆栈。
- 新增4个离线单元、11个真实定向断言；保留此前全部测试名称/断言。新测试声明和历史证据快照的编译范围已修正，未关掉strict、未排除当前测试。

## 实际结果

'''+table+'''
774项最终通过包括108个离线单元和666个真实集成/浏览器登记断言，包含夹具/观察断言，不是774个互不重复业务场景。负向控制2项保持FAIL：真实断言失败child1/driver1/cleanup PASS；空结果控制child0/driver1，无资源可清理所以N/A。SQL权限和内部异常的预期exit3、超时子进程SIGKILL以及服务有意停止的143/监督进程1不当作业务断言失败，原始命令均可查。

失败记录有阶段/断言/错误名/信息/脱敏堆栈；编译器诊断保留真实文件行号。正常exit0的空结果子进程本来没有异常栈，不补造；驱动错误名、源码SHA和命令/时间足以追溯。每个测试套件前后134个实际文件SHA一致，SQL/核心TS/测试/helper/执行器纳入；不是复制cfg.candidateSha256。时间字段assertion_result_recorded只代表记录断言完成的时间，不虚构逐用例耗时；HTTP与子命令另有真实起止，Vitest有实际duration。

完整逐项名称、目标、命令、退出码见FINAL_TEST_RESULTS.json。所有旧失败、首次类型/构建失败、预期控制和服务生命周期见EXECUTION_TIMELINE.json与runs/；没有删除失败测试、扩大授权或用Mock冒充集成。离线资源fetch模拟仅标为离线；定向控制的SQL/注册/Mailpit/子进程为真实执行。

'''+limits)
write('BUSINESS_REGRESSION_REPORT.md','# G5.3 业务与隔离回归\n\n'+context+'''
## 保留的业务行为

85个业务/worker文件与已交付最终版完全一致，未为适应测试撤销权限或删除功能。公开上传requireAccount确认本人后submitUpload；原始/规范化SHA由服务端计算，读取真实Storage字节再核验尺寸、MIME、对象ID/version、当前引用和摘要。下载返回已验证的内存快照，用户不能直接ready/completed或写删除状态。

仍保留独立I/O凭证和30秒租约：旧worker/旧token不能提交，未知写入不启动竞争写者；明确丢失/损坏安全失败，网络/5xx等暂不可用保持unavailable和原验证/头像引用，恢复后重新实际验证。五类数据库持久游标、CAS推进/尾页重扫和单项隔离保证后页不被前页失败饿死。

保留资料/偏好CAS、server同步时间、同意记录追加、数据流式导出、头像、密码复验、owner/job绑定cleanup authorization、失败重试和Auth Admin删除。导出completed是服务器完成内容生成，不证明用户磁盘保存。注册用本地公开Auth接口和自动确认，实际产生自己的默认资料及会话；未发送或验收真实邮箱。

## 实际安全与删除证明

本轮真实A/B、anon/authenticated/service_role完成角色、API、直接SQL、Storage和浏览器回归。7个public表的非空双方数据、7个private表、函数EXECUTE/owner/search_path由测试和目录双重核查。14表RLS，15函数owner postgres/固定空search_path，7触发器、9策略、2私有5MiB桶；没有增加service_role表ALL或对authenticated开放维护RPC。完整ACL/函数定义在LOCAL_CATALOG_SNAPSHOT.json。

A本人文件存在且可读，B404或Storage不可见；反向读写删同样核对，拒绝后实际字节/行未变，不能只看到404就当成功。真实Storage删除触发器故障使API503，Auth和重试信息保留；解除后后台重试，Admin404/user_not_found、两桶真实文件0、所属SQL/私有job审计级联0，B正常。用户仅调用删除申请RPC不等于获得后台Auth删除授权。

真实Chromium完成43个页面、深浅主题、390x844手机导航、资料保存、同意追加/撤回、上传/摘要下载/导出、PWA缓存隐私、注销后API401和IndexedDB清除、密码确认删除后的Auth404/文件0/SQL级联。页面路由200不代表训练/营养/AI/穿戴业务已经实现；PHASE1.1视觉未重做，后续产品功能和BRAND STUDIO仍保留。未声称真机手机/手表硬件验收完成。

## 遗留工具入口核查

createVerifiedMedia是历史报告用名，实际代码无此函数；实际uploadVerifiedMedia仍为server-only兼容工具。当前公开API不导入该旧上传工具，而是submitUpload/verifiedDownload；server_media_write在正常删除中仍有deleting/remove用途，保留它不会给浏览器开放begin/ready权限。后续新增服务器调用路径需再次审查，不能把旧工具当新I/O协议入口。

'''+table+'\n'+limits)
reliability_dir=next(x['evidence_directory'] for x in selected if x['mode']=='reliability');r=load(app/reliability_dir/'SUITE_RESULT.json');supervisors=[v for v in r['operations'] if v.get('kind')=='owned_supervisor_exit'];assert supervisors and all(x['ended_at']<=r['ended_at'] for x in supervisors)
save('SUPERVISOR_ORDER_EVIDENCE.json',{'status':'PASS','supervisor_exit_operations':supervisors,'suite_finalized_at':r['ended_at'],'evidence_directory':reliability_dir,'comparison':'actual ISO UTC timestamps; supervisor observed before final result'})
write('REAL_FAULT_TEST_REPORT.md','# G5.3 真实故障与清理证据\n\n'+context+'''
| 场景 | 实际注入/操作 | 真实观察 |
|---|---|---|
| Storage删除失败 | setLocalStorageDeleteFault创建本轮临时BEFORE DELETE触发器 | API503、原文件/Auth/任务保留；解除后自动重试、二进制0/Auth404、B不受影响 |
| 丢Storage/DB应答 | 本轮60421代理在真实上游提交后丢弃回应 | 同一幂等ID找回原任务和对象，无重复 |
| 进程崩溃 | 核对身份后SIGKILL真实Next | processing持久化、活租约不抢占、真实30秒到期后新worker从真实文件恢复，旧token拒绝 |
| 迟到上传/未知I/O | 真实存储写入配合本地受控SQL延迟，过期租约并同时申请删除 | 未知结果阻止误报成功，原请求确定终止才结算并安全删；无对象但io_pending仍独立阻止Auth删除 |
| TOCTOU | 下载已取字节时实际替换Storage对象 | ID/version/当前引用变化被识别，拒绝旧证明 |
| 真实字节损坏 | 仅定位当前合成对象的实际backend/version文件并翻转字节 | 元数据不变仍因服务端重新SHA而拒绝 |
| 真实缺失/临时不可用 | API实际移除对象；另停再起本轮Storage容器、模糊provider500 | 确认缺失failed；临时故障unavailable/503、保留证明与头像，健康后复验恢复 |
| 后页公平性/清理 | 超过10项pending/ready、12个孤儿前11个A删除受故障 | worker重启和两worker能扫后页；B合法文件保留，后续B孤儿不被A前页失败饿死 |
| 测试中途受控失败 | 真实A/B、文件、故障触发器/函数/序列后故意断言失败 | FAIL/exit1/完整堆栈；finally每步独立、所有夹具清理，Next实际退出 |
| 测试空结果 | 真实node子进程exit0且无结果文件 | 驱动FAIL/exit1，不算业务PASS；无DB/用户资源创建 |
| 内部异常误导文本 | 实际SQL主XX000，message含42501 | 新分类拒绝该内部异常，不误报权限PASS |
| 子进程超时/环境 | 真node定时循环触发timeout；父进程放虚构敏感哨兵 | 子进程不继承无关哨兵，超时SIGKILL并回收/记录 |

原始故障事件在NETWORK_FAULT_EVIDENCE.jsonl；每个SQL/进程/HTTP的实际状态在各run/CHILD_RESULTS.jsonl、SUITE_RESULT.json、COMMAND.json。监督进程实际退出时间早于结果生成时间，见SUPERVISOR_ORDER_EVIDENCE.json；监督包装进程随服务停止返回1是实际生命周期记录，不伪报0。

最终只读目录：Auth0、Storage对象0；13张用户相关表0，5行全局维护游标是设计状态；两桶真实二进制0、Mailpit实际0。所有临时测试函数/触发器/序列均核对无残留；清理逐项失败会阻止整体PASS。仅停止本轮6容器，卷和网络保留；其他容器停止阶段身份/状态未变。最终扫当前应用cwd，排除检查器真实祖先链后无残留进程，未杀未知进程或删除未知卷。

历史相同56db SQL的事务/重复initial回滚证据单独复核并标为HISTORICAL，不重新重置本轮数据库、不混算为本轮通过数。所有故障均限合成数据与新本地服务，未用模拟结果冒充数据库/Storage集成。

'''+limits)
gate='# G5.3 最终本地验收\n\n'+context+'\n| 门禁 | 结果 | 依据 |\n|---|---|---|\n| A 业务功能 | PASS | 实际API/注册/浏览器回归，85业务文件未改 |\n| B 测试可信度 | PASS | 精确权限反例、2项预期FAIL、真实退出码/清理/134文件前后SHA |\n| C 本地安全与可靠性 | PASS | 实际A/B、Storage、租约/I/O、崩溃、真实字节与删除恢复 |\n| D 原始工作区保护 | PASS | 原447及上一轮3418文件/Git状态保持 |\n| E 生产迁移与备份恢复 | PENDING | 本轮无生产授权/连接/部署，缺口不变 |\n\n'+table+'''
## 给用户的12个直接回答

1. 按本报告27个明确检查条目计，22项在上一轮最终版已经修复（17项业务、5项工具），本轮重新验证；没有重复重写这些业务。
2. 仍存在的真实问题主要是5组测试工具缺口：旧helper环境/诊断、SQL错误分类、Mailpit硬编码与身份、结论早于监督进程退出、无结果也可能算成功。这5组已修复。没有证实新的业务数据泄露缺陷。
3. 本轮实际修改21个测试/构建/执行工具目标；85个业务与worker源码、SQL均未改。新增测试漏类型声明和历史快照混入编译的问题也已纠正，首次失败保留。
4. 既有功能在覆盖范围内保留。注册用本地自动确认测试，登录/注销/资料/偏好/同意/同步/导出/头像/图片/删除/PWA/主题/手机导航/43路由均有相应回归；未来健身业务未冒称完工。
5. A/B真实本地用户隔离通过。本人资源存在可用，再验证另一人不能读取/修改/删除，拒绝后真实内容不变。
6. 正常、重复/并发、实际损坏、MIME/大小/像素/动画、丢应答和替换竞态均验证；未知I/O继续安全阻止删除，不能保证所有远端未知结果自动消失。
7. 删除不只看HTTP200。真实Auth Admin404、两个桶实际文件0及数据库/私有审计级联均核对；删除失败保留任务并自动重试，B未受影响。
8. 新反例中主错误XX000即使含42501文本也不会被当权限拒绝；网络/缺失RPC/参数/内部错误与权限/404隐藏资源分开核对。
9. 本轮实际测试用户、文件、临时对象、Next/worker/监督进程均清理完；只停止本轮6个新容器，保留卷，不清理原项目或未知资源。
10. 最终774项通过，0项业务失败，0项关键阻塞：108离线单元+666真实集成/浏览器登记断言。另2项故意负向控制保持FAIL（符合预期），开发阶段typecheck/build失败另列，不抹去或混进最终PASS。
11. 原Git447文件和上轮独立交付3418文件、各自branch/HEAD/status/diff/cached diff与本轮开始一致，旧压缩包未变。代码补丁只在临时比较区检查可应用，未应用回受保护仓库。
12. 离生产还缺最新云端只读核查、托管兼容、生产凭据/worker、正式DB与Storage备份、完整恢复演练、迁移审批、部署和真实用户验收。不得由本地PASS替代。

## 交付与版本选择

`current-round.proposed.patch`用于已有上轮最终代码的副本（21目标）；`complete.proposed.patch`用于原项目实际基准（47目标，包含前轮业务整合和本轮修复），两者均只检查未回写。必要完整文件在files/，基准/最终哈希在PATCH_TARGETS.json；SQL保持旧最终56db文件，未创建新的initial或前向迁移。完整用例/命令/时间/退出码在FINAL_TEST_RESULTS.json，失败与旧尝试在runs/和EXECUTION_TIMELINE.json。SHA256SUMS覆盖全部交付。

本轮不进入下一阶段，不自动上传GitHub或发布。等待用户审阅。

'''+limits
write('FINAL_GATE_REPORT.md',gate)
print(json.dumps({'current_passes':774,'offline':108,'live':666,'negative_controls':'2 real expected FAIL','business_changes':0,'protected_files':[r['files_verified'] for r in protected],'gates':gates},ensure_ascii=False))
