import { beginEvidence, cleanupFixtures, strictDenied, registerSecret, runChild, minimalChildEnv, killOwnedServer, auditedFetch, strictSqlDenied, localMailCount, captureOwnedSupervisor, waitOwnedSupervisor } from '../helpers/g53-evidence.mjs';
/** Real Next HTTP + isolated Supabase. No mocks and no hosted target. */
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { randomUUID, createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { createClient } from '@supabase/supabase-js';
import { createServerClient } from '@supabase/ssr';
import sharp from 'sharp';
import { assertLocalAclAuditTarget, observeUserRows } from '../helpers/local-acl-observer.mjs';
import { setLocalStorageDeleteFault, countLocalStorageBinaryFiles } from '../helpers/local-acl-faults.mjs';

await assertLocalAclAuditTarget();
const cfg = JSON.parse(readFileSync(process.env.FITNESS_ACL_AUDIT_CONFIG, 'utf8'));
assert.equal(cfg.productionCredentialsLoaded, false);
assert.equal(new URL(cfg.appUrl).hostname, '127.0.0.1');
const origin = cfg.appUrl;
const admin = createClient(cfg.apiUrl, cfg.serviceRoleKey, { auth: { persistSession: false, autoRefreshToken: false }, global:{fetch:auditedFetch} });
const actors = [], checks = [], knownGaps = [], ownedPaths = [];
const evidence=beginEvidence('g53-guard-boundaries',checks);
let fault = false, readyFault = false, current = 'initialization';
assert.match(cfg.runId, /^[a-f0-9]{8}$/);
const readyFaultName = 'g52_ready_fault_' + cfg.runId;
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
function check(condition, label) { current = label; assert.ok(condition, label); checks.push({ label, status: 'PASS' }); }
function db(result, label) { current = label; assert.equal(result.error, null, label); checks.push({ label, status: 'PASS' }); return result.data; }
function denied(result, label) { current=label;strictDenied(result,label,{kind:label==='client cannot read private journal'?'schema-not-exposed':'database'});check(true,label); }
async function request(actor, path, method = 'GET', body, extraHeaders = {}) {
  assert.ok(path.startsWith('/api/account/'));
  const headers = { Origin: origin, ...extraHeaders };
  if (actor) headers.Cookie = [...actor.cookies].map(([name, value]) => `${name}=${value}`).join('; ');
  if (body && !(body instanceof FormData)) headers['Content-Type'] = 'application/json';
  return auditedFetch(origin + path, { method, headers, body: body instanceof FormData ? body : body ? JSON.stringify(body) : undefined, redirect: 'error' });
}
async function jsonRequest(actor, path, method, body, expected, label) {
  const response = await request(actor, path, method, body);
  check(response.status === expected, label);
  return response.json();
}
const png = await sharp({ create: { width: 3, height: 2, channels: 3, background: 'green' } }).png().toBuffer();
async function upload(actor, bytes = png, mime = 'image/png', expected = 201, extra, idempotencyKey) {
  const form = new FormData(); form.append('file', new File([bytes], 'local.png', { type: mime }));
  if (extra) form.append('status', extra);
  const r = await request(actor, '/api/account/media', 'POST', form, { 'Idempotency-Key': idempotencyKey ?? randomUUID() });
  check(r.status === expected, `Next upload ${mime} returns ${expected}`);
  const data = await r.json();
  if (data.media) ownedPaths.push(['private-media', data.media.object_path]);
  return data.media;
}
const docker = ['--host=unix:///var/run/docker.sock'];
async function rawSql(query, role = 'postgres', claims = {}, commit = false) {
  await assertLocalAclAuditTarget();
  assert.ok(['postgres','anon','authenticated','service_role'].includes(role));
  const claimText = JSON.stringify(claims).replaceAll("'", "''");
  const result=await runChild('docker', [...docker, 'exec', '-i', cfg.containerId, 'psql', '-X', '-w', '-U', 'postgres', '-d', 'postgres', '-v', 'ON_ERROR_STOP=1', '-Atq'], {
    env: minimalChildEnv(), input: `\\set VERBOSITY verbose\nbegin; set local role ${role}; set local request.jwt.claims='${claimText}';\n${query}\n${commit ? 'commit' : 'rollback'};\n`,  timeout: 15000,
  });
  return {...result,status:result.code};
}
async function sqlDenied(query, role, claims, label) {
  const r = await rawSql(query, role, claims);
  strictSqlDenied(r,label);check(true,label);
}
// Appended to the actual HTTP helper prefix. All calls use real isolated services.
import { spawn } from 'node:child_process';
import { openSync, closeSync } from 'node:fs';
const privateRoot = new URL('.', 'file://' + process.env.FITNESS_ACL_AUDIT_CONFIG).pathname;
const control = privateRoot + 'proxy-control.json', eventFile = privateRoot + 'proxy-events.jsonl';
const eventOffset = readFileSync(eventFile,'utf8').length;
const phaseFile = privateRoot + 'reliability-progress.json';
let replacementServer;let replacementSpawnError;
function phase(name) { evidence.phase(name); writeFileSync(phaseFile, JSON.stringify({ phase:name, checks:checks.length, time:new Date().toISOString() })); }
const sleep = ms => new Promise(r=>setTimeout(r,ms));
async function poll(fn,label,timeout=10000) {
  const end=Date.now()+timeout;
  while(Date.now()<end){if(await fn())return;await sleep(100);}
  current=label;throw new Error(label);
}
function rule(id,action,path,method='POST',rpcAction) { writeFileSync(control,JSON.stringify({rules:[{id,action,path,method,rpcAction,remaining:1}],release:[]})); }
function release(id){const x=JSON.parse(readFileSync(control,'utf8'));x.release=[id];writeFileSync(control,JSON.stringify(x));}
function saw(id,stage) { return readFileSync(eventFile,'utf8').slice(eventOffset).split('\n').filter(Boolean).some(l=>{const e=JSON.parse(l);return e.id===id&&e.phase===stage;}); }
async function post(actor,key,bytes=png,mime='image/png') {
  const data=new FormData();data.set('file',new File([bytes],'synthetic.png',{type:mime}));
  const response=await request(actor,'/api/account/media','POST',data,{'Idempotency-Key':key});
  const body=await response.json();
  if(body.media)ownedPaths.push(['private-media',body.media.object_path],['private-media-staging',body.media.object_path]);
  return {status:response.status,body};
}
async function job(action,actor,id=null,key=null,lease=null,data={}) {
  return db(await admin.rpc('server_media_reliability',{p_action:action,p_owner:actor?.id??null,p_media:id,p_request:key,p_lease:lease,p_data:data}),`trusted ${action}`);
}
async function worker(token=cfg.workerToken,actor=null) {
  const headers={'Content-Type':'application/json'};if(token)headers.Authorization='Bearer '+token;
  if(actor)headers.Cookie=[...actor.cookies].map(([n,v])=>n+'='+v).join('; ');
  const response=await auditedFetch(origin+'/api/internal/media/reconcile',{method:'POST',headers,body:'{}'});
  return {status:response.status,body:await response.json()};
}
async function reserve(actor,key=randomUUID()) {
  const bytes=await sharp(png).rotate().png().toBuffer();
  const state=await job('reserve',actor,null,key,null,{request_sha:sha(png),expected_sha:sha(bytes),mime:'image/png',size:bytes.length});
  ownedPaths.push(['private-media',state.media.object_path],['private-media-staging',state.media.object_path]);
  return {...state,bytes,key};
}
async function stage(actor,state) { db(await admin.storage.from('private-media-staging').upload(state.media.object_path,state.bytes,{contentType:'image/png',upsert:false}),'persist real staged source'); }
async function query(text){const r=await rawSql(text);check(r.status===0,'local readonly evidence query');return r.stdout.trim();}
async function fixture(text){const r=await rawSql(text,'postgres',{},true);check(r.status===0,'local disposable fixture transaction');}
async function workerProcess(){
 return runChild('node',['scripts/media-reconcile-worker.mjs','--once'],{env:minimalChildEnv({MEDIA_WORKER_APP_ORIGIN:origin,FITNESS_MEDIA_WORKER_TOKEN:cfg.workerToken}),timeout:65000});
}
async function dockerChecked(args){
 await assertLocalAclAuditTarget();
 const probe=await runChild('docker',[...docker,'inspect','--format','{"Id":{{json .Id}},"Name":{{json .Name}},"Labels":{{json .Config.Labels}},"Mounts":{{json .Mounts}},"Running":{{json .State.Running}}}',cfg.storageContainerId],{env:minimalChildEnv(),timeout:20000});
 assert.equal(probe.code,0,probe.stderr);const actual=JSON.parse(probe.stdout);assert.deepEqual(actual.Labels,cfg.storageContainerLabels);assert.equal(actual.Id,cfg.storageContainerId);assert.equal(actual.Name,'/'+cfg.storageContainerName);assert.ok(actual.Mounts.some(m=>m.Destination==='/mnt'));if(args[0]!=='start')assert.ok(actual.Running);
 const result=await runChild('docker',[...docker,...args],{env:minimalChildEnv(),timeout:20000});assert.equal(result.code,0,result.stderr);return result.stdout;
}
try {
 phase('fresh real A/B and real Next uploads');
 check(db(await admin.auth.admin.listUsers({perPage:2}),'fresh Auth for final suite').users.length===0,'final suite starts with zero users');
 for(const email of ['user-a@example.invalid','user-b@example.invalid']){
  const password='FinalG53!'+randomUUID()+'Aa9';registerSecret(password);
  const user=db(await admin.auth.admin.createUser({email,password,email_confirm:true}),'create final synthetic user').user;
  const cookies=new Map();const client=createServerClient(cfg.apiUrl,cfg.anonKey,{global:{fetch:auditedFetch},cookies:{getAll:()=>[...cookies].map(([name,value])=>({name,value})),setAll:values=>values.forEach(({name,value})=>cookies.set(name,value))}});
  const session=db(await client.auth.signInWithPassword({email,password}),'real final local Auth password session').session;
  actors.push({id:user.id,password,client,cookies,claims:JSON.parse(Buffer.from(session.access_token.split('.')[1],'base64url').toString())});
 }
 const [a,b]=actors;const ma=(await post(a,randomUUID())).body.media,mb=(await post(b,randomUUID())).body.media;
 check(ma.status==='ready'&&mb.status==='ready','A/B real upload ready before fault tests');
 let writingPromise;
 try{
  const premature=await admin.auth.admin.deleteUser(a.id,false);
  console.log(JSON.stringify({observedAuthGuard:{status:premature.error?.status,code:premature.error?.code,name:premature.error?.name,message:premature.error?.message}}));
  check(premature.error!==null,'Admin Auth deletion remains blocked while actual files exist');
  const blocked=await rawSql(`delete from auth.users where id='${a.id}';`);check(blocked.status!==0&&/42501/.test(blocked.stderr)&&/media_cleanup_required/.test(blocked.stderr),'exact Auth SQL trigger prevents deletion');
  const late=await reserve(a),claim=await job('claim',a,late.media.id,null,null,{from_request:true});
  const fn='g53_late_fn_'+cfg.runId,seq='g53_late_seq_'+cfg.runId;
  await fixture(`create sequence app_private.${seq};create function app_private.${fn}() returns trigger language plpgsql security definer set search_path='' as $$begin if new.bucket_id='private-media' and new.name='${late.media.object_path}' and new.version='1' then if pg_catalog.nextval('app_private.${seq}'::regclass)=2 then perform pg_catalog.pg_sleep(5);end if;end if;return new;end;$$;revoke all on function app_private.${fn}() from public,anon,authenticated,service_role;create trigger a_g53_late before insert on storage.objects for each row execute function app_private.${fn}();`);
  const registered=await admin.rpc('server_media_reliability',{p_action:'write_start',p_owner:a.id,p_media:late.media.id,p_lease:claim.job.lease_token,p_data:{bucket:'private-media'}});assert.equal(registered.error,null);const ioToken=registered.data.write_token;
  const before=await countLocalStorageBinaryFiles(a.id);
  writingPromise=Promise.resolve(admin.storage.from('private-media').upload(late.media.object_path,late.bytes,{contentType:'image/png',metadata:{fitness_write_token:ioToken}}));
  await poll(async()=>await countLocalStorageBinaryFiles(a.id)>before,'actual bytes exist while expired writer still in flight');
  await fixture(`update app_private.media_upload_jobs set lease_until=clock_timestamp()-interval '1 second' where media_id='${late.media.id}';`);
  const response=await request(a,'/api/account/media/'+late.media.id,'DELETE');const physical=await countLocalStorageBinaryFiles(a.id);
  check(response.status===409,'expired lease cannot prove in-flight writer ended; actual HTTP '+response.status+', physical '+physical+' vs '+before);
  const outcome=await writingPromise;check(outcome.error!==null,'expired cancelled writer returns actual Storage failure');
  const settled=await admin.rpc('server_media_reliability',{p_action:'write_settle',p_owner:a.id,p_media:late.media.id,p_data:{write_token:ioToken,outcome:'rejected',http_status:Number(outcome.error.statusCode)}});assert.equal(settled.error,null);check(settled.data.settled,'terminal provider response settles the exact old write independently of expired lease');
  check((await request(a,'/api/account/media/'+late.media.id,'DELETE')).status===200,'deletion retries successfully only after known writer terminal response');
  check(await countLocalStorageBinaryFiles(a.id)===before,'expired writer final physical bytes are gone before deletion success');

  await jsonRequest(a,'/api/account/media/'+ma.id,'DELETE',undefined,200,'remove settled A baseline before isolated unknown-I/O guard');
  const unknown=await reserve(a),unknownClaim=await job('claim',a,unknown.media.id,null,null,{from_request:true});
  const pendingWrite=await admin.rpc('server_media_reliability',{p_action:'write_start',p_owner:a.id,p_media:unknown.media.id,p_lease:unknownClaim.job.lease_token,p_data:{bucket:'private-media'}});assert.equal(pendingWrite.error,null);
  await fixture(`update app_private.media_upload_jobs set lease_until=clock_timestamp()-interval '1 second' where media_id='${unknown.media.id}';`);
  const attemptedClaim=await job('claim',a,unknown.media.id,null,null,{from_request:true});check(attemptedClaim.claimed===false&&attemptedClaim.uncertain===true,'expired unknown I/O never launches a competing writer');
  check((await request(a,'/api/account/media/'+unknown.media.id,'DELETE')).status===409,'unknown write with no object still blocks media deletion');
  await fixture(`update app_private.media_upload_jobs set status='failed' where media_id='${unknown.media.id}';`);
  check(await countLocalStorageBinaryFiles(a.id)===0,'isolated I/O guard fixture has no visible or physical A objects');
  await jsonRequest(a,'/api/account/delete','POST',{confirmation:'DELETE',password:a.password},503,'I/O receipt alone blocks premature account success even when job status failed');
  const guardedDelete=await rawSql(`delete from auth.users where id='${a.id}';`);check(guardedDelete.status!==0&&/42501/.test(guardedDelete.stderr)&&/media_cleanup_required/.test(guardedDelete.stderr),'Auth guard independently rejects unresolved I/O even without objects');
  check((await admin.auth.admin.getUserById(a.id)).data.user?.id===a.id,'Auth retained while the provider outcome is genuinely unknown');
  // Resume the one original not-yet-dispatched request, not a second competing write.
  const resumed=await admin.storage.from('private-media').upload(unknown.media.object_path,unknown.bytes,{contentType:'image/png',metadata:{fitness_write_token:pendingWrite.data.write_token}});
  check(resumed.error?.name==='StorageApiError'&&[400,403].includes(Number(resumed.error.statusCode))&&resumed.error.message==='media_owner_unavailable','resumed old request receives exact trusted Storage deletion fence');
  const ended=await admin.rpc('server_media_reliability',{p_action:'write_settle',p_owner:a.id,p_media:unknown.media.id,p_data:{write_token:pendingWrite.data.write_token,outcome:'rejected',http_status:Number(resumed.error.statusCode)}});assert.equal(ended.error,null);check(ended.data.settled,'only the actual old provider response releases its I/O receipt');
  await jsonRequest(a,'/api/account/delete','POST',{confirmation:'DELETE',password:a.password},200,'password reauthenticated account retry succeeds after real old write termination');
  check((await admin.auth.admin.getUserById(a.id)).error?.code==='user_not_found','A Auth absence independently proven after terminal writer');
  check(await countLocalStorageBinaryFiles(a.id)===0,'A real binary count zero after complete guarded deletion');
  check((await request(b,'/api/account/media/'+mb.id)).status===200,'B survives the complete unknown-I/O deletion scenario');
 }finally{if(writingPromise)await writingPromise;}
}catch(error){evidence.fail(error,current);}finally{await evidence.finish(()=>cleanupFixtures(admin,actors,{stopServer:true}));}
