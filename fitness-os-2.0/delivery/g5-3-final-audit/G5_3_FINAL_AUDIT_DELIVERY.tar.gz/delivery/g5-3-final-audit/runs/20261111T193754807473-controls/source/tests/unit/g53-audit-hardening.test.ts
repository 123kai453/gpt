import { afterEach, describe, expect, it, vi } from "vitest";
import { minimalChildEnv, runChild, strictSqlDenied } from "../helpers/g53-evidence.mjs";
afterEach(()=>vi.unstubAllEnvs());
describe("G5.3 current audit controls, offline and local child only",()=>{
 it("accepts only psql exit3 with primary ERROR 42501",()=>{expect(()=>strictSqlDenied({code:3,stderr:"ERROR:  42501: permission denied\n"},"expected permission")).not.toThrow();});
 it("rejects internal errors that mention 42501, connectivity failures and killed children",()=>{
  for(const r of [{code:3,stderr:"ERROR:  XX000: diagnostic contains 42501 permission denied\n"},{code:2,stderr:"connection failed 42501"},{code:0,stderr:"ERROR: 42501: fake"},{code:3,stderr:"ERROR:  42501: permission denied",signal:"SIGKILL"}])expect(()=>strictSqlDenied(r,"not permission proof")).toThrow();
 });
 it("does not inherit unrelated sensitive variables into a real child",async()=>{
  vi.stubEnv("UNRELATED_PRODUCTION_TOKEN_SENTINEL","synthetic-only-not-a-real-key");
  expect(minimalChildEnv()).not.toHaveProperty("UNRELATED_PRODUCTION_TOKEN_SENTINEL");
  const r=await runChild("node",["-e","console.log(JSON.stringify({leaked:Object.hasOwn(process.env,'UNRELATED_PRODUCTION_TOKEN_SENTINEL')}))"],{env:minimalChildEnv()});expect(r.code).toBe(0);expect(JSON.parse(r.stdout).leaked).toBe(false);
 });
});
