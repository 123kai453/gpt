/** Local-only fault injection and physical binary evidence. Never a hosted helper. */
import { minimalChildEnv, runObservedChild } from './g53-process.mjs';
import { readFileSync } from 'node:fs';
import { assertLocalAclAuditTarget } from './local-acl-observer.mjs';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const SOCKET = 'unix:///var/run/docker.sock';
const fail = () => { throw new Error('Fresh local fault/evidence target check failed.'); };

async function docker(args,input=''){
 const r=await runObservedChild('docker',['--host',SOCKET,...args],{env:minimalChildEnv(),timeout:20000,input});
 if(r.code!==0)throw Object.assign(new Error('Local fault/evidence Docker operation failed; actual sanitized command evidence retained'),{result:r});
 return r.stdout;
}
async function config() {
  await assertLocalAclAuditTarget();
  const value = JSON.parse(readFileSync(process.env.FITNESS_ACL_AUDIT_CONFIG, 'utf8'));
  if (!/^[a-f0-9]{8}$/.test(value.runId) || value.database !== 'postgres') fail();
  return value;
}

/** Only one fixture UUID can be targeted; this does not alter candidate policies. */
export async function setLocalStorageDeleteFault(userId, enabled, bucket='private-media') {
  if (!UUID.test(userId) || typeof enabled !== 'boolean' || !['private-media','private-media-staging'].includes(bucket)) fail();
  const c = await config();
  const name = `acl_audit_storage_delete_fault_${c.runId}`;
  const statement = enabled ? `
create function app_private.${name}() returns trigger
language plpgsql set search_path='' as $$
begin
  if old.bucket_id='${bucket}' and pg_catalog.split_part(old.name,'/',1)='${userId.toLowerCase()}' then
    raise exception using errcode='42501',message='acl_audit_storage_delete_injected';
  end if;
  return old;
end; $$;
revoke all on function app_private.${name}() from public,anon,authenticated,service_role;
create trigger ${name} before delete on storage.objects for each row execute function app_private.${name}();
` : `drop trigger if exists ${name} on storage.objects; drop function if exists app_private.${name}();`;
  await docker(['exec', '-i', c.containerId, 'psql', '-X', '-w', '-h', '/var/run/postgresql', '-p', '5432',
    '-U', 'postgres', '-d', 'postgres', '-q', '-v', 'ON_ERROR_STOP=1', '--single-transaction', '-f', '-'], statement);
}

/** Counts files, never reads binary contents; a positive pre-delete count is mandatory in tests. */
export async function countLocalStorageBinaryFiles(userId) {
  if (!UUID.test(userId)) fail();
  const c = await config();
  if (!/^[a-f0-9]{64}$/.test(c.storageContainerId ?? '')
    || c.storageContainerName !== `supabase_storage_${c.projectId}`
    || !c.storageMountDestinations?.includes('/mnt')) fail();
  const format = '{"id":{{json .Id}},"name":{{json .Name}},"labels":{{json .Config.Labels}},"running":{{json .State.Running}}}';
  const actual = JSON.parse(await docker(['inspect', '--format', format, c.storageContainerId]));
  const sorted = (o) => JSON.stringify(Object.entries(o).sort(([a], [b]) => a.localeCompare(b)));
  if (actual.id !== c.storageContainerId || actual.name !== `/${c.storageContainerName}` || !actual.running
    || sorted(actual.labels) !== sorted(c.storageContainerLabels)) fail();
  const program = `const fs=require('node:fs'),path=require('node:path');
const base='/mnt',uid=process.argv[1];if(!fs.statSync(base).isDirectory())process.exit(2);
let count=0;function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){
const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(e.isFile()){
const parts=p.split(path.sep),bucket=parts.findIndex(x=>x==='private-media'||x==='private-media-staging');
if(bucket>=0&&parts[bucket+1]===uid)count++;
}
}}walk(base);process.stdout.write(JSON.stringify({count,verifiedRoot:true}));`;
  const observed = JSON.parse(await docker(['exec', c.storageContainerId, 'node', '-e', program, userId.toLowerCase()]));
  if (observed.verifiedRoot !== true || !Number.isSafeInteger(observed.count) || observed.count < 0) fail();
  return observed.count;
}
