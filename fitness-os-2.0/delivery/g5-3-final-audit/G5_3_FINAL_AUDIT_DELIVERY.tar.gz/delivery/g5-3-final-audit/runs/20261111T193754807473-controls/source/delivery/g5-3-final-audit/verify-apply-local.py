from urllib.parse import urlparse
"""Exact local-container guard and single selected candidate application.
No remote connection string is accepted; psql uses the new container Unix socket.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import urllib.request

p = json.loads(Path(os.environ.get('FITNESS_G53_FINAL_PLAN','/tmp/fitness-g53-current-audit-plan.json')).read_text())
c = json.loads((Path(p['private']) / 'local-audit-config.json').read_text())
assert c['productionCredentialsLoaded'] is False
assert c['environment'] == 'isolated-local-supabase-acl-audit'
assert urlparse(c['apiUrl']).hostname=='127.0.0.1'
e={k:os.environ[k] for k in ('PATH','HOME','LANG','DOCKER_CONFIG') if k in os.environ}
docker = ['docker', '--host=unix:///var/run/docker.sock']
actual = json.loads(subprocess.check_output(docker + ['inspect', c['containerId']], env=e, text=True))[0]
assert actual['Id'] == c['containerId'] and actual['Name'] == '/' + c['containerName']
assert actual['Config']['Labels'] == c['requiredContainerLabels'] and actual['State']['Running']
assert list(actual['NetworkSettings']['Networks']) == [c['network']]
assert any(m['Name'] == c['dbVolume'] for m in actual['Mounts'])
network = json.loads(subprocess.check_output(docker + ['network', 'inspect', c['network']], env=e, text=True))[0]
assert network['Internal'] is True
assert network['Labels']['fitness.g53.run'] == p['runId']

def sql(text):
    identity=json.loads(subprocess.check_output(docker+['inspect','--format','{"Id":{{json .Id}},"Name":{{json .Name}},"Labels":{{json .Config.Labels}},"Running":{{json .State.Running}}}',c['containerId']],env=e,text=True))
    assert identity['Id']==c['containerId'] and identity['Name']=='/'+c['containerName'] and identity['Labels']==c['requiredContainerLabels'] and identity['Running']
    a = subprocess.run(docker + ['exec', '-i', c['containerId'], 'psql', '-X', '-w', '-h', '/var/run/postgresql', '-U', 'postgres', '-d', 'postgres', '-Atq', '-v', 'ON_ERROR_STOP=1'], env=e, input=text, capture_output=True, text=True, timeout=35)
    if a.returncode:
        (Path(p['private']) / 'candidate-error.log').write_text(a.stderr)
        raise RuntimeError('Selected candidate failed locally; sanitized SQL error: ' + a.stderr[-2000:])
    return a.stdout.strip()

opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))  # Only fixed loopback URLs.
for path in ['/auth/v1/health', '/rest/v1/', '/storage/v1/status']:
    request = urllib.request.Request(c['apiUrl'] + path, headers={'apikey': c['anonKey']})
    with opener.open(request, timeout=8) as response:
        assert response.status == 200
    print(json.dumps({'localHealth': path, 'status': 200}))
baseline = json.loads(sql("""begin read only;
select json_build_object('database',current_database(),'role',current_user,'version',current_setting('server_version'),
 'authUsers',(select count(*) from auth.users),'storageObjects',(select count(*) from storage.objects),
 'storageBuckets',(select count(*) from storage.buckets),'privateSchema',to_regnamespace('app_private'),
 'targetTable',to_regclass('public.user_media'),
 'objectsRls',(select relrowsecurity from pg_class where oid='storage.objects'::regclass),
 'bucketsRls',(select relrowsecurity from pg_class where oid='storage.buckets'::regclass),
 'storagePolicyCount',(select count(*) from pg_policy where polrelid='storage.objects'::regclass));
commit;"""))
assert baseline['database'] == 'postgres' and baseline['role'] == 'postgres'
assert baseline['version'].startswith('17.11')
assert baseline['authUsers'] == baseline['storageObjects'] == baseline['storageBuckets'] == baseline['storagePolicyCount'] == 0
assert baseline['privateSchema'] is None and baseline['targetTable'] is None
assert baseline['objectsRls'] and baseline['bucketsRls']
(Path(p['private']) / 'before-candidate.json').write_text(json.dumps(baseline, indent=2))
candidate = Path(p['app']) / p['candidatePath']
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == c['candidateSha256']
sql(candidate.read_text())
sql("notify pgrst, 'reload schema';")  # Local-only cache refresh, not migration history.
result = {'status': 'PASS', 'candidateSha256': c['candidateSha256'], 'target': c['containerId'],
    'database': baseline['database'], 'role': baseline['role'], 'version': baseline['version'],
    'freshBaseline': baseline, 'executedOnlySelectedCandidate': True, 'hostedConnection': False,
    'migrationLedgerRegistered': False}
(Path(p['private']) / 'candidate-apply.json').write_text(json.dumps(result, indent=2))
print(json.dumps({'selectedCandidateApplication': 'PASS', 'version': baseline['version'], 'freshBaseline': True}))
