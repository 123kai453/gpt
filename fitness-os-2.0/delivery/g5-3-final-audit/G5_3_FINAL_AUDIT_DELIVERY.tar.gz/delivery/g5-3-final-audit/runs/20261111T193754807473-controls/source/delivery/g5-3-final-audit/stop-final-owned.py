"""Stop only the six new containers and exact processes created by this run."""
from pathlib import Path
import base64,datetime,json,os,signal,subprocess,time
from zoneinfo import ZoneInfo
app=Path(__file__).resolve().parents[2];out=app/'delivery/g5-3-final-audit';p=json.loads(Path(os.environ.get('FITNESS_G53_FINAL_PLAN','/tmp/fitness-g53-current-audit-plan.json')).read_text());private=Path(p['private']);owned=json.loads((private/'owned-containers.json').read_text());ids={v['id'] for v in owned};assert len(ids)==6
env={k:os.environ[k] for k in ('PATH','HOME','LANG','DOCKER_CONFIG') if k in os.environ};docker=['docker','--host=unix:///var/run/docker.sock'];records=[]
def run(args):
 r=subprocess.run(args,env=env,text=True,capture_output=True,timeout=30);assert r.returncode==0;return r.stdout
def others():
 return sorted([json.loads(x) for x in run(docker+['ps','-a','--no-trunc','--format','{"id":{{json .ID}},"name":{{json .Names}},"state":{{json .State}},"image":{{json .Image}}}']).splitlines() if json.loads(x)['id'] not in ids],key=lambda x:x['id'])
before=others()
for kind in ('app','proxy'):
 f=private/(kind+'-process.json')
 if not f.exists():continue
 q=json.loads(f.read_text());root=Path('/proc')/str(q['pid'])
 if not root.exists():records.append({'process':kind,'pid':q['pid'],'already_exited':True});continue
 st=(root/'stat').read_text();assert st[st.rfind(')')+2:].split()[19]==q['start_ticks'];assert (root/'cmdline').read_bytes()==base64.b64decode(q['cmdline_base64']);assert os.readlink(root/'cwd')==str(app)
 os.kill(q['pid'],signal.SIGTERM)
 deadline=time.monotonic()+12
 while root.exists() and time.monotonic()<deadline:time.sleep(.05)
 assert not root.exists();records.append({'process':kind,'pid':q['pid'],'exact_identity_checked':True,'signal':'SIGTERM','exit_confirmed':True})
for item in reversed(owned):
 actual=json.loads(run(docker+['inspect','--format','{"Id":{{json .Id}},"Name":{{json .Name}},"Labels":{{json .Config.Labels}},"Running":{{json .State.Running}}}',item['id']]))
 assert actual['Id']==item['id'] and actual['Name']=='/'+item['name'] and actual['Labels']['fitness.g53.run']==p['runId']
 if actual['Running']:
  args=docker+['stop','--time','10',item['id']];run(args);records.append({'container':item['name'],'id':item['id'],'command':args,'exit_code':0})
 assert run(docker+['inspect','--format','{{.State.Running}}',item['id']]).strip()=='false'
after=others();assert before==after
(out/'LOCAL_SHUTDOWN.json').write_text(json.dumps({'status':'PASS','observed_at':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'scope':'six containers of run '+p['runId']+' only; volumes/networks preserved','actions':records,'other_containers_before_shutdown':before,'other_containers_after_shutdown':after,'other_container_identity_and_state_unchanged_during_shutdown':True,'production_access':False},indent=2)+'\n')
print(json.dumps({'owned_shutdown':'PASS','stopped_owned_containers':6,'other_containers_unchanged_during_shutdown':True,'volumes_preserved':True}))
