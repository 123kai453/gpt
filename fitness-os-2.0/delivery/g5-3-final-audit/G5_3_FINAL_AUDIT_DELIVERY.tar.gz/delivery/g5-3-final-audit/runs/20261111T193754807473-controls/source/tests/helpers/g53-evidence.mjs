/** Test infrastructure only. All operations remain bound to the fresh local Docker identity. */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, statSync, existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { minimalChildEnv, runObservedChild } from './g53-process.mjs';
export { minimalChildEnv };
import { assertLocalAclAuditTarget, observeUserRows } from './local-acl-observer.mjs';
import { setLocalStorageDeleteFault, countLocalStorageBinaryFiles } from './local-acl-faults.mjs';
const profile = process.env.FITNESS_ACL_AUDIT_CONFIG;
const cfg = profile ? JSON.parse(readFileSync(profile,'utf8')) : null;
const operations=[];
const secrets = new Set(cfg ? [cfg.serviceRoleKey,cfg.anonKey,cfg.workerToken].filter(Boolean) : []);
export const registerSecret = value => { if (value) secrets.add(value); };
export function redact(value) {
  let s=String(value??''); for(const secret of secrets) s=s.split(secret).join('[REDACTED]');
  return s.replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g,'[REDACTED_JWT]')
    .replace(/(Bearer\s+)[^\s"']+/gi,'$1[REDACTED]')
    .replace(/postgres(?:ql)?:\/\/[^\s"']+/gi,'[REDACTED_CONNECTION]')
    .replace(/((?:password|secret|token|apikey)["']?\s*[:=]\s*)["']?[^\s,}"']+/gi,'$1[REDACTED]');
}
export function errorRecord(error, phase) {
  return { phase, assertion:redact(error?.message?.split('\n')[0]??''), name:redact(error?.name??'Error'), message:redact(error?.message??error),
    code:redact(error?.code??''), stack:redact(error?.stack??''), observed_at:new Date().toISOString() };
}
export function strictDenied(result,label,{kind='database',codes=['42501'],messages,httpStatus=403}={}) {
  assert.ok(result?.error,label+': expected structured denial, not success');
  const e=result.error;
  if(kind==='schema-not-exposed') {
    assert.equal(Number(result.status),406,label+': expected schema exposure rejection');
    assert.equal(e.code,'PGRST106',label+': expected schema exposure error, not missing RPC');
    assert.equal(e.message,'Invalid schema: app_private',label+': expected exact private-schema exposure rejection');
  } else if(kind==='database') {
    assert.equal(Number(result.status),httpStatus,label+': expected exact role-specific permission HTTP status');
    assert.ok(codes.includes(e.code),label+': expected exact permission SQLSTATE, not transport/RPC/input error');
    if(messages) assert.ok(messages.includes(e.message),label+': expected specific denial reason');
  } else {
    const status=Number(e.statusCode??e.status??result.status);
    assert.ok(e.name==='StorageApiError',label+': expected Storage API error, not network failure');
    if(kind==='storage-fence') assert.ok([400,403].includes(status)&&e.message==='media_write_fenced',label+': expected explicit media_write_fenced; observed '+redact(JSON.stringify({status,name:e.name,message:e.message})));
    else if(kind==='storage-update') assert.ok([400,403,404].includes(status)&&/^(Object not found|The resource was not found|not found)$|row.level security|unauthorized|permission denied/i.test(e.message),label+': expected specific update RLS invisibility/denial');
    else if(kind==='storage-write') assert.ok([400,403].includes(status)&&/row.level security|unauthorized|permission denied/i.test(e.message),label+': expected RLS denial');
    else assert.ok([400,404].includes(status)&&/^(Object not found|The resource was not found|not found)$/i.test(e.message),label+': expected private object invisibility');
  }
}
function actualHashes() {
  const manifest=JSON.parse(readFileSync(process.env.FITNESS_SOURCE_MANIFEST,'utf8'));
  return manifest.files.map(row=>{
    const actual=createHash('sha256').update(readFileSync(resolve(manifest.root,row.path))).digest('hex');
    assert.equal(actual,row.sha256,'Test source/SQL changed: '+row.path);return {path:row.path,sha256:actual};
  });
}
export function beginEvidence(suite,checks) {
  const started_at=new Date().toISOString();const before=actualHashes();let failed=null;let active='initialization';
  const times=[];
  const originalPush=checks.push.bind(checks);
  checks.push=(...rows)=>{const at=new Date().toISOString();for(const row of rows)times.push({name:typeof row==='string'?row:row.label,started_at:at,ended_at:at,timing_scope:'assertion_result_recorded',status:'PASS'});return originalPush(...rows);};
  return {
    phase(name){active=name;},
    fail(error,current){failed=errorRecord(error,current||active);process.exitCode=1;},
    async finish(cleanup){
      let cleanupResult;
      try { cleanupResult=await cleanup(); } catch(error) { cleanupResult={status:'FAIL',errors:[errorRecord(error,'cleanup')],residuals:['Cleanup did not complete']}; }
      let after;try{after=actualHashes();assert.deepEqual(after,before,'Source/manifest changed during suite');}catch(error){failed??=errorRecord(error,'source_hash_after');}
      if(cleanupResult.status!=='PASS')failed??=errorRecord(new Error('Cleanup failed; inspect residuals'),'cleanup');
      const status=failed?'FAIL':'PASS';if(failed)process.exitCode=1;
      const result={suite,status,started_at,ended_at:new Date().toISOString(),assertions:checks.length,checks,timings:times,
        failure:failed,cleanup:cleanupResult,operations,source_hashes_before:before,source_hashes_after:after??null,
        process_exit_code:failed?1:0,process_exit_code_kind:'requested by suite; actual OS code recorded by run-command.py',
        productionRequests:false};
      const path=process.env.FITNESS_SUITE_RESULT;assert.ok(path,'Durable suite result path required');
      writeFileSync(path,JSON.stringify(result,null,2)+'\n',{mode:0o600});
      console.log(JSON.stringify({suite,status,assertions:checks.length,result_path:path}));return result;
    }
  };
}
export function runChild(command,args,options={}) { return runObservedChild(command,args,{cwd:cfg?.app,...options,redact}); }
/** Require psql's verbose primary ERROR SQLSTATE, never a message substring. */
export function strictSqlDenied(result,label) {
 assert.equal(result.code??result.status,3,label+': expected psql SQL-error exit3');
 assert.ok(!result.signal&&!result.timedOut,label+': not a timeout or process signal');
 const match=result.stderr?.match(/^ERROR:\s+([A-Z0-9]{5}):/m);
 assert.equal(match?.[1],'42501',label+': expected primary permission SQLSTATE');
}
export async function localMailCount(){
 const response=await auditedFetch(cfg.mailUrl+'/api/v1/messages');assert.equal(response.status,200,'actual owned Mailpit response');
 const body=await response.json();assert.ok(Number.isSafeInteger(body.total)&&body.total>=0);return body.total;
}
export async function waitOwnedSupervisor(child,identity,timeout=10000){
 const started_at=new Date().toISOString();let timer;
 try {
  const result=await Promise.race([new Promise(resolve=>{if(child.exitCode!==null)return resolve({code:child.exitCode,signal:child.signalCode});child.once('close',(code,signal)=>resolve({code,signal}));}),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Owned replacement supervisor did not exit after server teardown')),timeout);})]);
  operations.push({kind:'owned_supervisor_exit',pid:child.pid,started_at,ended_at:new Date().toISOString(),...result});return result;
 }catch(error){
  if(existsSync('/proc/'+child.pid)){
   const stat=readFileSync('/proc/'+child.pid+'/stat','utf8');assert.equal(stat.slice(stat.lastIndexOf(')')+2).split(' ')[19],identity.start_ticks);assert.equal(readFileSync('/proc/'+child.pid+'/cmdline').toString('base64'),identity.cmdline_base64);
   const {readlinkSync}=await import('node:fs');assert.equal(readlinkSync('/proc/'+child.pid+'/cwd'),identity.cwd);child.kill('SIGKILL');
   await new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(new Error('Owned supervisor still did not exit')),5000);child.once('close',()=>{clearTimeout(t);resolve();});});
  }
  throw error;
 }finally{clearTimeout(timer);}
}
export async function captureOwnedSupervisor(child){
 const {readlinkSync}=await import('node:fs');const cwd=readlinkSync('/proc/'+child.pid+'/cwd');assert.equal(cwd,cfg.app);
 const cmd=readFileSync('/proc/'+child.pid+'/cmdline');assert.ok(cmd.toString().includes(cfg.app+'/delivery/g5-3-final-audit/run-command.py'));
 const stat=readFileSync('/proc/'+child.pid+'/stat','utf8');return {pid:child.pid,cwd,start_ticks:stat.slice(stat.lastIndexOf(')')+2).split(' ')[19],cmdline_base64:cmd.toString('base64')};
}
export async function checkedSql(sql) {
  await assertLocalAclAuditTarget();
  return runChild('docker',['--host=unix:///var/run/docker.sock','exec','-i',cfg.containerId,'psql','-X','-w','-h','/var/run/postgresql','-U','postgres','-d','postgres','-Atq','-v','ON_ERROR_STOP=1'],{input:sql,env:minimalChildEnv(),timeout:20000});
}
export async function assertOwnedServer(pid) {
  assert.ok(Number.isInteger(pid)&&pid>1);const identity=JSON.parse(readFileSync(dirname(profile)+'/app-process.json','utf8'));
  assert.equal(identity.pid,pid);
  const {readlinkSync}=await import('node:fs');assert.equal(readlinkSync('/proc/'+pid+'/cwd'),cfg.app);
  const stat=readFileSync('/proc/'+pid+'/stat','utf8');const ticks=stat.slice(stat.lastIndexOf(')')+2).split(' ')[19];
  assert.equal(ticks,identity.start_ticks);assert.equal(readFileSync('/proc/'+pid+'/cmdline').toString('base64'),identity.cmdline_base64);
  assert.ok(Buffer.from(identity.cmdline_base64,'base64').toString().includes('next-server'));
  assert.equal(identity.source_root,cfg.app);return identity;
}
export async function killOwnedServer(pid,signal='SIGTERM') {
  await assertOwnedServer(pid);process.kill(pid,signal);
  const until=Date.now()+10000;while(existsSync('/proc/'+pid)&&Date.now()<until)await new Promise(r=>setTimeout(r,50));
  assert.ok(!existsSync('/proc/'+pid),'Owned Next process must actually exit');
}
/** Teardown is infrastructure, never evidence that the business deletion API worked. */
export async function cleanupFixtures(admin,actors,{stopServer=false}={}) {
  const errors=[],actions=[],residuals=[];const attempt=async(label,fn)=>{try{await fn();actions.push({label,status:'PASS'});}catch(error){errors.push(errorRecord(error,label));}};
  await attempt('clear local proxy faults',async()=>{const f=dirname(profile)+'/proxy-control.json';if(existsSync(f))writeFileSync(f,'{"rules":[],"release":[]}');});
  if(stopServer)await attempt('wait for exact owned Next exit',async()=>{const f=dirname(profile)+'/app.pid';if(existsSync(f)){const pid=Number(readFileSync(f));if(existsSync('/proc/'+pid))await killOwnedServer(pid);}});
  await attempt('remove only this-run fixture triggers/functions/sequences',async()=>{
    await assertLocalAclAuditTarget();
    const suffix=cfg.runId;assert.match(suffix,/^[a-f0-9]{8}$/);
    const q=`begin;drop function if exists public.g53_internal_${suffix}();drop trigger if exists a_g53_late on storage.objects;drop function if exists app_private.g53_late_fn_${suffix}();drop sequence if exists app_private.g53_late_seq_${suffix};drop trigger if exists g52_ready_fault_${suffix} on public.user_media;drop function if exists app_private.g52_ready_fault_${suffix}();commit;`;
    const r=await checkedSql(q);assert.equal(r.code,0,'Fixture DDL cleanup');
  });
  let listed=[];
  await attempt('enumerate synthetic Auth users with complete pagination',async()=>{
    for(let page=1;;page++){const r=await admin.auth.admin.listUsers({page,perPage:100});assert.equal(r.error,null);listed.push(...r.data.users);if(r.data.users.length<100)break;assert.ok(page<1000,'Auth cleanup pagination budget exceeded');}
  });
  for(const user of listed){
    if(!['user-a@example.invalid','user-b@example.invalid'].includes(user.email)){residuals.push({kind:'unexpected_user',id:user.id});continue;}
    const owner=user.id;await attempt('clear delete fault for '+owner,()=>setLocalStorageDeleteFault(owner,false));
    // All SDK requests are awaited, owned servers stopped when requested. This is a
    // synthetic test teardown cancellation, NOT a production recovery algorithm.
    await attempt('quiescent synthetic upload cancellation '+owner,async()=>{
      assert.match(owner,/^[a-f0-9-]{36}$/);const r=await checkedSql(`begin;update public.profiles set deletion_requested_at=clock_timestamp() where id='${owner}';update app_private.media_upload_jobs set status='failed',lease_token=null,lease_until=null where user_id='${owner}';update public.user_media set status='deleting' where user_id='${owner}';commit;`);assert.equal(r.code,0);
    });
    for(const bucket of ['private-media','private-media-staging'])await attempt('drain every page '+bucket+'/'+owner,async()=>{
      let operations=0;const queue=[owner];
      while(queue.length){const prefix=queue[queue.length-1];const r=await admin.storage.from(bucket).list(prefix,{limit:100,offset:0,sortBy:{column:'name',order:'asc'}});assert.equal(r.error,null);assert.ok(++operations<=10000,'Cleanup budget exceeded; residuals retained');
        if(!r.data.length){queue.pop();continue;}
        const files=r.data.filter(x=>x.id);const dirs=r.data.filter(x=>!x.id);
        for(const item of files){assert.ok(!item.name.includes('/')&&!item.name.includes('..'));const key=prefix+'/'+item.name;assert.ok(key.startsWith(owner+'/'));const removed=await admin.storage.from(bucket).remove([key]);assert.equal(removed.error,null);}
        if(dirs.length)for(const item of dirs){assert.ok(!item.name.includes('/')&&!item.name.includes('..'));queue.push(prefix+'/'+item.name);}
      }
    });
    await attempt('all real physical owner binaries zero '+owner,async()=>assert.equal(await countLocalStorageBinaryFiles(owner),0));
    await attempt('delete and verify Auth '+owner,async()=>{
      const deleted=await admin.auth.admin.deleteUser(owner,false);assert.equal(deleted.error,null);
      const gone=await admin.auth.admin.getUserById(owner);assert.equal(gone.error?.status,404);assert.equal(gone.error?.code,'user_not_found');
    });
    for(const table of ['profiles','user_preferences','user_consents','sync_metadata','user_data_exports','user_media','account_deletion_jobs','account_mutation_receipts','rate_limit_counters'])await attempt('physical SQL cascade '+owner+'/'+table,async()=>assert.deepEqual(await observeUserRows(table,owner),[]));
    await attempt('new private owner rows zero '+owner,async()=>{const r=await checkedSql(`begin read only;select (select count(*) from app_private.media_upload_jobs where user_id='${owner}')+(select count(*) from app_private.media_job_events where user_id='${owner}')+(select count(*) from app_private.account_cleanup_authorizations where user_id='${owner}');commit;`);assert.equal(r.code,0);assert.equal(r.stdout.trim(),'0');});
  }
  await attempt('final global residual scan',async()=>{
    const r=await checkedSql("begin read only;select json_build_object('users',(select count(*) from auth.users),'objects',(select count(*) from storage.objects),'fixture_functions',(select count(*) from pg_proc where proname like 'g53_internal_%' or proname like 'g53_late_fn_%' or proname like 'g52_ready_fault_%' or proname like 'acl_audit_storage_delete_fault_%'),'fixture_sequences',(select count(*) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='app_private' and c.relkind='S' and c.relname like 'g53_late_seq_%'),'fixture_triggers',(select count(*) from pg_trigger where not tgisinternal and (tgname='a_g53_late' or tgname like 'g52_ready_fault_%' or tgname like 'acl_audit_storage_delete_fault_%')));commit;");assert.equal(r.code,0);const state=JSON.parse(r.stdout);for(const [key,n] of Object.entries(state))if(n!==0)residuals.push({kind:key,count:n});
  });
  void actors;return {status:errors.length||residuals.length?'FAIL':'PASS',actions,errors,residuals};
}

/** Real request timing/status only; no headers, JWT, body or response data are logged. */
export async function auditedFetch(input,init={}) {
  assert.ok(cfg,'Only the explicit local profile is permitted');
  const url=new URL(input instanceof Request?input.url:String(input));
  const origins=new Set([cfg.apiUrl,cfg.appUrl,cfg.proxyUrl,cfg.mailUrl]);
  assert.ok(origins.has(url.origin),'No cross-origin test credential request');
  await assertLocalAclAuditTarget();
  const owned=JSON.parse(readFileSync(dirname(profile)+'/owned-containers.json','utf8'));const mailRequest=url.origin===cfg.mailUrl;const gateway=owned.find(x=>x.kind===(mailRequest?'inbucket':'kong'));assert.ok(gateway,'This run must own the requested service');
  const verified=await runChild('docker',['--host=unix:///var/run/docker.sock','inspect','--format','{"id":{{json .Id}},"name":{{json .Name}},"labels":{{json .Config.Labels}},"running":{{json .State.Running}},"ports":{{json .NetworkSettings.Ports}}}',gateway.id],{env:minimalChildEnv(),timeout:15000});
  assert.equal(verified.code,0);const actual=JSON.parse(verified.stdout);assert.equal(actual.id,gateway.id);assert.equal(actual.name,'/'+gateway.name);assert.equal(actual.labels['fitness.g53.run'],cfg.runId);assert.ok(actual.running);const serviceUrl=new URL(mailRequest?cfg.mailUrl:cfg.apiUrl);assert.equal(serviceUrl.hostname,'127.0.0.1');assert.deepEqual(actual.ports[mailRequest?'8025/tcp':'8000/tcp'],[{HostIp:'127.0.0.1',HostPort:serviceUrl.port}]);
  const entry={kind:'real_http',method:init.method??(input instanceof Request?input.method:'GET'),origin:url.origin,path:url.pathname,started_at:new Date().toISOString()};
  try{const response=await fetch(input,{...init,redirect:'error',signal:init.signal?AbortSignal.any([init.signal,AbortSignal.timeout(15000)]):AbortSignal.timeout(15000)});entry.status=response.status;if(response.status>=400&&response.headers.get('content-type')?.includes('application/json')){const payload=await response.clone().json().catch(()=>null);if(payload)entry.failure_response={code:redact(payload.code??payload.error_code??''),message:redact(payload.message??payload.msg??payload.error_description??''),error:typeof payload.error==='string'?redact(payload.error):''};}return response;}
  catch(error){entry.error=errorRecord(error,'real_http');throw error;}
  finally{entry.ended_at=new Date().toISOString();operations.push(entry);}
}
