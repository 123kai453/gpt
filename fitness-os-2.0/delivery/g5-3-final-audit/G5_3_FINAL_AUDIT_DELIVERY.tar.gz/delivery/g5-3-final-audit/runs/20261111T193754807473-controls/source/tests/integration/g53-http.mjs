import { beginEvidence, cleanupFixtures, strictDenied, registerSecret, runChild, minimalChildEnv, killOwnedServer, auditedFetch, strictSqlDenied, localMailCount, captureOwnedSupervisor, waitOwnedSupervisor } from '../helpers/g53-evidence.mjs';
/** Real Next HTTP + isolated Supabase. No mocks and no hosted target. */
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { randomUUID, createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { createClient } from '@supabase/supabase-js';
import { createServerClient } from '@supabase/ssr';
import sharp from 'sharp';
import { assertLocalAclAuditTarget, observeUserRows } from '../helpers/local-acl-observer.mjs';
import { setLocalStorageDeleteFault, countLocalStorageBinaryFiles } from '../helpers/local-acl-faults.mjs';

await assertLocalAclAuditTarget();
const cfg = JSON.parse(readFileSync(process.env.FITNESS_ACL_AUDIT_CONFIG, 'utf8'));
assert.equal(cfg.productionCredentialsLoaded, false);
assert.equal(new URL(cfg.appUrl).hostname, '127.0.0.1');
const origin = cfg.appUrl;
const admin = createClient(cfg.apiUrl, cfg.serviceRoleKey, { auth: { persistSession: false, autoRefreshToken: false }, global:{fetch:auditedFetch} });
const actors = [], checks = [], knownGaps = [], ownedPaths = [];
const evidence=beginEvidence('g53-http',checks);
let fault = false, readyFault = false, current = 'initialization';
assert.match(cfg.runId, /^[a-f0-9]{8}$/);
const readyFaultName = 'g52_ready_fault_' + cfg.runId;
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
function check(condition, label) { current = label; assert.ok(condition, label); checks.push({ label, status: 'PASS' }); }
function db(result, label) { current = label; assert.equal(result.error, null, label); checks.push({ label, status: 'PASS' }); return result.data; }
function denied(result, label) { current=label;strictDenied(result,label,{kind:label==='direct owner Storage replacement denied'?'storage-update':'database'});check(true,label); }
async function request(actor, path, method = 'GET', body, extraHeaders = {}) {
  assert.ok(path.startsWith('/api/account/'));
  const headers = { Origin: origin, ...extraHeaders };
  if (actor) headers.Cookie = [...actor.cookies].map(([name, value]) => `${name}=${value}`).join('; ');
  if (body && !(body instanceof FormData)) headers['Content-Type'] = 'application/json';
  return auditedFetch(origin + path, { method, headers, body: body instanceof FormData ? body : body ? JSON.stringify(body) : undefined, redirect: 'error' });
}
async function jsonRequest(actor, path, method, body, expected, label) {
  const response = await request(actor, path, method, body);
  check(response.status === expected, label);
  return response.json();
}
const png = await sharp({ create: { width: 3, height: 2, channels: 3, background: 'green' } }).png().toBuffer();
async function upload(actor, bytes = png, mime = 'image/png', expected = 201, extra, idempotencyKey) {
  const form = new FormData(); form.append('file', new File([bytes], 'local.png', { type: mime }));
  if (extra) form.append('status', extra);
  const r = await request(actor, '/api/account/media', 'POST', form, { 'Idempotency-Key': idempotencyKey ?? randomUUID() });
  check(r.status === expected, `Next upload ${mime} returns ${expected}`);
  const data = await r.json();
  if (data.media) ownedPaths.push(['private-media', data.media.object_path]);
  return data.media;
}
const docker = ['--host=unix:///var/run/docker.sock'];
async function rawSql(query, role = 'postgres', claims = {}, commit = false) {
  await assertLocalAclAuditTarget();
  assert.ok(['postgres','anon','authenticated','service_role'].includes(role));
  const claimText = JSON.stringify(claims).replaceAll("'", "''");
  const result=await runChild('docker', [...docker, 'exec', '-i', cfg.containerId, 'psql', '-X', '-w', '-U', 'postgres', '-d', 'postgres', '-v', 'ON_ERROR_STOP=1', '-Atq'], {
    env: minimalChildEnv(), input: `\\set VERBOSITY verbose\nbegin; set local role ${role}; set local request.jwt.claims='${claimText}';\n${query}\n${commit ? 'commit' : 'rollback'};\n`,  timeout: 15000,
  });
  return {...result,status:result.code};
}
async function sqlDenied(query, role, claims, label) {
  const r = await rawSql(query, role, claims);
  strictSqlDenied(r,label);check(true,label);
}
try {
  check(db(await admin.auth.admin.listUsers({ perPage: 2 }), 'fresh Auth for HTTP fixture').users.length === 0, 'SDK suite left no users');
  for (const email of ['user-a@example.invalid', 'user-b@example.invalid']) {
    const password = `OnlyLocal!${randomUUID()}Aa9`;registerSecret(password);
    const user = db(await admin.auth.admin.createUser({ email, password, email_confirm: true }), 'local confirmed synthetic user').user;
    const cookies = new Map();
    const client = createServerClient(cfg.apiUrl, cfg.anonKey, { global:{fetch:auditedFetch}, cookies: {
      getAll: () => [...cookies].map(([name, value]) => ({ name, value })),
      setAll: (values) => values.forEach(({ name, value }) => cookies.set(name, value)),
    } });
    const session = db(await client.auth.signInWithPassword({ email, password }), 'real Auth password session and SSR cookies').session;
    const claims = JSON.parse(Buffer.from(session.access_token.split('.')[1], 'base64url').toString());
    check(claims.sub === user.id && claims.role === 'authenticated' && Boolean(claims.session_id), 'real distinct authenticated JWT claims');
    actors.push({ id: user.id, password, client, cookies, claims });
  }
  const [a, b] = actors;
  const snapshot = await jsonRequest(a, '/api/account/snapshot', 'GET', undefined, 200, 'Next profile snapshot works');
  await jsonRequest(a, '/api/account/mutations', 'POST', { mutationId: randomUUID(), deviceId: randomUUID(), entity: 'profile', baseVersion: snapshot.profile.version, patch: { display_name: 'Local A' } }, 200, 'Next profile CAS update works under hardened ACL');
  const prefs = await jsonRequest(a, '/api/account/mutations', 'POST', { mutationId: randomUUID(), deviceId: randomUUID(), entity: 'preferences', baseVersion: snapshot.preferences.version, patch: { theme: 'light', timezone: 'Asia/Shanghai' } }, 200, 'Next preference CAS update works under hardened ACL');
  check(prefs.record.theme === 'light', 'preference data actually updated');
  const sync = db(await a.client.from('sync_metadata').select('*'), 'read own server sync timestamps');
  check(sync.length === 2 && sync.every((r) => Math.abs(Date.now() - Date.parse(r.last_seen_at)) < 60000 && Math.abs(Date.now() - Date.parse(r.last_synced_at)) < 60000), 'sync values use server clock near actual request time');
  await jsonRequest(a, '/api/account/mutations', 'POST', { mutationId: randomUUID(), deviceId: randomUUID(), entity: 'profile', baseVersion: 2, patch: { last_seen_at: '2099-01-01T00:00:00Z' } }, 400, 'Next rejects client-supplied server timestamp');
  denied(await a.client.from('sync_metadata').update({ last_seen_at: '2099-01-01' }).eq('user_id', a.id), 'direct REST sync timestamp write denied');
  const ma = await upload(a), mb = await upload(b);
  check(ma.status === 'ready' && /^[a-f0-9]{64}$/.test(ma.content_sha256) && Boolean(ma.verified_at), 'Next upload returns server-verified ready row');
  const download = await request(a, `/api/account/media/${ma.id}`);
  const bytes = new Uint8Array(await download.arrayBuffer());
  check(download.status === 200 && sha(bytes) === ma.content_sha256, 'Next download binary matches committed verification digest');
  check(download.headers.get('cache-control').includes('no-store'), 'private HTTP media is not cacheable');
  await jsonRequest(b, `/api/account/media/${ma.id}`, 'GET', undefined, 404, 'B cannot read A through Next');
  await jsonRequest(b, `/api/account/media/${ma.id}`, 'DELETE', undefined, 404, 'B cannot delete A through Next');
  await jsonRequest(null, `/api/account/media/${ma.id}`, 'GET', undefined, 401, 'anonymous Next download denied');
  denied(await a.client.from('user_media').update({ status: 'ready', content_sha256: 'a'.repeat(64) }).eq('id', ma.id), 'direct REST cannot rewrite server verification');
  denied(await a.client.storage.from('private-media').update(ma.object_path, png, { contentType: 'image/png' }), 'direct owner Storage replacement denied');
  const removeAttempt = await a.client.storage.from('private-media').remove([ma.object_path]);
  if(removeAttempt.error)strictDenied(removeAttempt,'direct owner Storage deletion',{kind:'storage-write'});else assert.deepEqual(removeAttempt.data,[]);
  check(true, 'direct owner Storage deletion affects no object');
  check((await request(a, `/api/account/media/${ma.id}`)).status === 200, 'object survives denied direct deletion');
  await upload(a, new Uint8Array([255,216,255,217]), 'image/jpeg', 415);
  await upload(a, png, 'image/jpeg', 415);
  await upload(a, png, 'image/png', 400, 'ready');
  const rowsAfterInvalid = db(await a.client.from('user_media').select('id'), 'media rows after invalid inputs');
  check(rowsAfterInvalid.length === 1, 'invalid content and forged multipart state create no metadata');

  // A caller retries the same request with the same proposed idempotency key.
  const retryKey = randomUUID();
  const duplicateOne = await upload(a, png, 'image/png', 201, undefined, retryKey);
  const duplicateTwo = await upload(a, png, 'image/png', 200, undefined, retryKey);
  check(duplicateOne.id === duplicateTwo.id, 'same idempotency header reuses one ready media ID');
  await jsonRequest(a, `/api/account/media/${duplicateTwo.id}`, 'DELETE', undefined, 200, 'Next owner media deletion works through narrow RPC');

  // Inject a real PostgreSQL exception on ready; Storage writes must be undone.
  const readySetup = await rawSql(`create function app_private.${readyFaultName}() returns trigger language plpgsql set search_path='' as $$begin if new.status='ready' and new.user_id='${a.id}'::uuid then raise exception using errcode='P0001',message='g52_ready_fault'; end if; return new; end;$$; revoke all on function app_private.${readyFaultName}() from public,anon,authenticated,service_role; create trigger ${readyFaultName} before update on public.user_media for each row execute function app_private.${readyFaultName}();`, 'postgres', {}, true);
  check(readySetup.status === 0, 'install disposable ready failure trigger'); readyFault = true;
  await upload(a, png, 'image/png', 202);
  const failedMedia = db(await a.client.from('user_media').select('*').eq('status','pending'), 'inspect retriable ready transaction');
  check(failedMedia.length === 1, 'failed ready transaction remains recoverable with same ID');
  const noBinary = await admin.storage.from('private-media').download(failedMedia[0].object_path);
  check(noBinary.data !== null && !noBinary.error, 'verified final binary retained for safe recovery after database failure');
  const readyCleanup = await rawSql(`drop trigger ${readyFaultName} on public.user_media; drop function app_private.${readyFaultName}();`, 'postgres', {}, true);
  check(readyCleanup.status === 0, 'remove only this run temporary ready trigger'); readyFault = false;
  await new Promise(r=>setTimeout(r,2200));
  const recovered=await auditedFetch(origin+'/api/internal/media/reconcile',{method:'POST',headers:{Authorization:'Bearer '+cfg.workerToken,'Content-Type':'application/json'},body:'{}'});
  check(recovered.status===200,'real trusted worker recovers committed Storage after failed DB finalization');
  check((await a.client.from('user_media').select('status').eq('id',failedMedia[0].id).single()).data.status==='ready','recovered row is truly ready');

  const exportResponse = await request(a, '/api/account/export', 'POST', { format: 'json' });
  check(exportResponse.status === 200, 'Next export works with server-only task writes');
  const exported = await exportResponse.json();
  check(exported.account.id === a.id && exported.data.user_media.every((m) => m.user_id === a.id), 'Next export contains only A account data');
  const exportRows = db(await a.client.from('user_data_exports').select('*'), 'read actual export task');
  check(exportRows.length === 1 && exportRows[0].status === 'completed' && exportRows[0].object_path === null && Boolean(exportRows[0].completed_at), 'export status reflects serialization completion with no fabricated path');
  denied(await a.client.from('user_data_exports').update({ status: 'completed' }).eq('id', exportRows[0].id), 'direct REST export completion denied');
  await jsonRequest(a, '/api/account/export', 'POST', { format: 'json', status: 'completed' }, 400, 'Next rejects forged export state fields');
  await jsonRequest(a, '/api/account/consents', 'POST', { scope: 'analytics', granted: true, policy_version: 'g52-v1' }, 201, 'Next consent append true');
  await jsonRequest(a, '/api/account/consents', 'POST', { scope: 'analytics', granted: false, policy_version: 'g52-v1' }, 201, 'Next consent withdrawal appends new false');
  const consents = await jsonRequest(a, '/api/account/consents', 'GET', undefined, 200, 'Next consent history readable');
  check(consents.consents.length === 2 && consents.current.analytics.granted === false, 'prior consent remains and latest false takes effect');

  await sqlDenied(`update public.user_media set status='ready' where id='${ma.id}';`, 'authenticated', a.claims, 'raw SQL authenticated cannot forge ready');
  await sqlDenied(`update public.user_data_exports set status='completed' where user_id='${a.id}';`, 'authenticated', a.claims, 'raw SQL authenticated cannot forge completed');
  await sqlDenied(`update public.account_deletion_jobs set status='completed' where user_id='${a.id}';`, 'authenticated', a.claims, 'raw SQL authenticated cannot change deletion job');
  await sqlDenied(`update public.user_consents set granted=false where user_id='${a.id}';`, 'authenticated', a.claims, 'raw SQL consent UPDATE denied');
  await sqlDenied(`delete from public.user_consents where user_id='${a.id}';`, 'authenticated', a.claims, 'raw SQL consent DELETE denied');
  await sqlDenied('select * from app_private.account_mutation_receipts;', 'authenticated', a.claims, 'raw SQL private schema denied');
  await sqlDenied('select * from public.profiles;', 'anon', {}, 'raw SQL anon profile denied');
  await sqlDenied('select * from public.profiles;', 'service_role', { role: 'service_role' }, 'raw SQL service role direct table SELECT denied');
  const sqlOwn = await rawSql(`select count(*) from public.profiles where id='${a.id}';`, 'authenticated', a.claims);
  check(sqlOwn.status === 0 && sqlOwn.stdout.trim() === '1', 'raw SQL authenticated own SELECT succeeds');
  const sqlOther = await rawSql(`select count(*) from public.profiles where id='${b.id}';`, 'authenticated', a.claims);
  check(sqlOther.status === 0 && sqlOther.stdout.trim() === '0', 'raw SQL RLS filters other user');

  // Real server failure, not a mocked return value: a temporary local trigger.
  await jsonRequest(a, '/api/account/delete', 'POST', { confirmation: 'DELETE', password: 'wrong-local-password' }, 401, 'Next deletion requires correct password before mutations');
  check((await observeUserRows('account_deletion_jobs', a.id)).length === 0, 'wrong password creates no deletion job');
  const beforeA = await countLocalStorageBinaryFiles(a.id), beforeB = await countLocalStorageBinaryFiles(b.id);
  check(beforeA > 0 && beforeB > 0, 'physical A/B binaries exist before cleanup');
  await setLocalStorageDeleteFault(a.id, true); fault = true;
  await jsonRequest(a, '/api/account/delete', 'POST', { confirmation: 'DELETE', password: a.password }, 503, 'Next real Storage failure is retryable error');
  const jobs = await observeUserRows('account_deletion_jobs', a.id);
  check(jobs.length === 1 && jobs[0].status === 'failed' && jobs[0].attempts === 1, 'server persists failed job and first attempt');
  denied(await a.client.from('account_deletion_jobs').update({ status: 'completed', attempts: 0 }).eq('user_id', a.id), 'direct REST cannot forge retry state');
  check((await request(b, `/api/account/media/${mb.id}`)).status === 200, 'B download unaffected by A cleanup fault');
  await setLocalStorageDeleteFault(a.id, false); fault = false;
  const removedA = await jsonRequest(a, '/api/account/delete', 'POST', { confirmation: 'DELETE', password: a.password }, 200, 'Next deletion retry succeeds through Auth Admin');
  check(removedA.deleted === true, 'Next confirms completed account removal');
  check((await admin.auth.admin.getUserById(a.id)).data.user === null, 'A Auth user actually removed');
  for (const table of ['profiles','user_preferences','user_consents','sync_metadata','user_data_exports','user_media','account_deletion_jobs','account_mutation_receipts','rate_limit_counters']) {
    check((await observeUserRows(table, a.id)).length === 0, `A physical ${table} cascade complete`);
  }
  check(await countLocalStorageBinaryFiles(a.id) === 0, 'A physical media binary removed');
  check(await countLocalStorageBinaryFiles(b.id) === beforeB, 'B physical media binary unchanged');
  await jsonRequest(a, `/api/account/media/${ma.id}`, 'GET', undefined, 401, 'old deleted-user cookies cannot download');

  // Counterexamples: collect real evidence of gaps, not expected passes.
  const id = randomUUID();
  db(await admin.rpc('server_media_write', { p_owner: b.id, p_id: id, p_action: 'begin', p_mime: 'image/png', p_size: png.length }), 'reserve synthetic interrupted upload');
  await jsonRequest(b, `/api/account/media/${id}`, 'DELETE', undefined, 200, 'pending media can be safely cancelled and removed through fenced API');
  check((await b.client.from('user_media').select('id').eq('id',id)).data.length===0,'cancelled pending row removed');

  const replacement = await sharp({ create: { width: 3, height: 2, channels: 3, background: 'purple' } }).png().toBuffer();
  db(await admin.storage.from('private-media').update(mb.object_path, replacement, { contentType:'image/png' }), 'simulate trusted out-of-band replacement');
  const replacedResponse = await request(b, `/api/account/media/${mb.id}`);
  const replacedBytes = new Uint8Array(await replacedResponse.arrayBuffer());
  check(replacedResponse.status === 409 && sha(replacedBytes) !== mb.content_sha256, 'trusted replacement invalidates readiness and is not served');

  // Simulate trusted/out-of-band object loss in this disposable test only.
  db(await admin.storage.from('private-media').remove([mb.object_path]), 'simulate out-of-band loss of B ready object');
  const missingDownload = await request(b, `/api/account/media/${mb.id}`);
  const stale = db(await b.client.from('user_media').select('status').eq('id', mb.id).single(), 'read metadata after actual object loss');
  check(missingDownload.status === 409 && stale.status === 'failed', 'actual missing binary is represented as failed rather than ready');
  // Actual app deletion path cleans remaining B SQL records.
  await jsonRequest(b, '/api/account/delete', 'POST', { confirmation: 'DELETE', password: b.password }, 200, 'B normal account deletion after controlled fixture cleanup');
  const mail={total:await localMailCount()};
  check(mail.total === 0, 'local mail capture contains zero messages');
 } catch(error) {
  evidence.fail(error,current);
 } finally {
  await evidence.finish(()=>cleanupFixtures(admin,actors));
 }
