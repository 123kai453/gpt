"""Only create a fresh disposable local stack. Never accepts remote DB credentials.

Uses cached official Supabase images and the existing local CLI-generated platform
bootstrap (not its data or secrets). Run only after reviewing the isolation plan.
Raw service logs/configuration remain private; this script prints only safe state.
"""
import base64
import hashlib
import hmac
import json
import os
from pathlib import Path
import secrets
from urllib.parse import urlparse
import socket
import subprocess
import time

plan = json.loads(Path(os.environ.get('FITNESS_G53_FINAL_PLAN','/tmp/fitness-g53-current-audit-plan.json')).read_text())
private = Path(plan['private'])
project = plan['projectId']
assert project.startswith('fitness-os-acl-audit-g53-')
assert all(urlparse(plan[k]).hostname=='127.0.0.1' and urlparse(plan[k]).port for k in ('apiUrl','appUrl','proxyUrl','mailUrl'))

env={k:os.environ[k] for k in ('PATH','HOME','USER','LANG','LC_ALL','TZ','TMPDIR','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','DOCKER_CONFIG') if k in os.environ}
docker = ['docker', '--host=unix:///var/run/docker.sock']

def run(args, **kw):
    result = subprocess.run(docker + args, env=env, capture_output=True, text=True, timeout=45, **kw)
    if result.returncode:
        (private / 'docker-error.private.log').write_text(result.stderr)
        os.chmod(private / 'docker-error.private.log', 0o600)
        raise RuntimeError('Local Docker operation failed; raw diagnostics kept private.')
    return result.stdout

for port in [urlparse(plan[k]).port for k in ('apiUrl','appUrl','proxyUrl','mailUrl')]:
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', port))
assert not json.loads(run(['ps', '-aq', '--filter', 'label=fitness.g53.run=' + plan['runId'], '--format', 'json']) or '[]')
source = json.loads(run(['inspect','--format','{"Config":{"Image":{{json .Config.Image}},"Entrypoint":{{json .Config.Entrypoint}},"Cmd":{{json .Config.Cmd}}}}', 'supabase_db_fitness-os-phase2-local']))
assert source['Config']['Image'] == 'supabase/postgres:17.11.0.011'
assert source['Config']['Entrypoint'] == ['sh']
bootstrap = source['Config']['Cmd']
assert bootstrap[0] == '-c' and 'docker-entrypoint.sh postgres' in bootstrap[1]
assert 'public.user_media' not in bootstrap[1] and 'account_foundation' not in bootstrap[1]

password = secrets.token_hex(24)
jwt_secret = secrets.token_hex(32)
def encode(value):
    return base64.urlsafe_b64encode(json.dumps(value, separators=(',', ':')).encode()).decode().rstrip('=')
def token(role):
    body = encode({'alg': 'HS256', 'typ': 'JWT'}) + '.' + encode({'iss': 'supabase-demo', 'role': role, 'iat': int(time.time()), 'exp': int(time.time()) + 86400})
    return body + '.' + base64.urlsafe_b64encode(hmac.new(jwt_secret.encode(), body.encode(), hashlib.sha256).digest()).decode().rstrip('=')
anon, service = token('anon'), token('service_role')
network = 'fitness_g53_' + plan['runId']
labels = ['--label', 'fitness.g53.run=' + plan['runId'], '--label', 'com.supabase.cli.project=' + project]
run(['network', 'create', '--internal', *labels, network])
front = 'fitness_g53_front_' + plan['runId']
run(['network', 'create', *labels, front])
owned = []
def launch(kind, image, values, extra=None, entry=None, command=None):
    name = 'supabase_' + kind + '_' + project
    path = private / (kind + '.private.env')
    values = {'NO_PROXY': 'localhost,127.0.0.1,::1,db,auth,rest,storage,kong,mail', 'no_proxy': 'localhost,127.0.0.1,::1,db,auth,rest,storage,kong,mail', **values}
    path.write_text(''.join(k + '=' + str(v) + '\n' for k, v in values.items()))
    os.chmod(path, 0o600)
    args = ['run', '--pull=never', '-d', '--name', name, '--network', network, '--network-alias', kind if kind != 'inbucket' else 'mail', *labels, '--env-file', str(path)]
    if extra: args.extend(extra)
    if entry: args.extend(['--entrypoint', entry])
    args.append(image)
    if command: args.extend(command)
    cid = run(args).strip()
    if kind in ('kong', 'inbucket'):
        run(['network', 'connect', front, cid])
    owned.append({'kind': kind, 'name': name, 'id': cid, 'image': image})
    (private / 'owned-containers.json').write_text(json.dumps(owned, indent=2))
    return cid

db_volume = 'fitness_g53_db_' + plan['runId']
storage_volume = 'fitness_g53_storage_' + plan['runId']
for volume in (db_volume, storage_volume): run(['volume', 'create', *labels, volume])
db = launch('db', 'supabase/postgres:17.11.0.011', {'POSTGRES_PASSWORD': password, 'JWT_SECRET': jwt_secret, 'JWT_EXP': 3600},
            ['--mount', 'type=volume,src=' + db_volume + ',dst=/var/lib/postgresql/data'], 'sh', bootstrap)
deadline = time.monotonic() + 55
while True:
    r = subprocess.run(docker + ['exec', db, 'pg_isready', '-h', '/var/run/postgresql', '-U', 'postgres', '-d', 'postgres'], env=env, capture_output=True, text=True, timeout=5)
    if r.returncode == 0:
        # Initialization can temporarily accept connections before final restart.
        time.sleep(2)
        check = subprocess.run(docker + ['exec', db, 'psql', '-X', '-U', 'postgres', '-d', 'postgres', '-Atqc', "select count(*) from pg_catalog.pg_roles where rolname in ('authenticator','supabase_auth_admin','supabase_storage_admin')"], env=env, capture_output=True, text=True, timeout=5)
        if check.returncode == 0 and check.stdout.strip() == '3': break
    if time.monotonic() > deadline: raise RuntimeError('Fresh local database startup timeout; no application SQL applied.')
    time.sleep(1)
launch('inbucket', 'axllent/mailpit:v1.31.3', {'MP_SMTP_DISABLE_RDNS': 'true'}, ['-p', '127.0.0.1:'+str(urlparse(plan['mailUrl']).port)+':8025'])
launch('auth', 'supabase/gotrue:v2.197.0', {
    'GOTRUE_API_HOST': '0.0.0.0', 'GOTRUE_API_PORT': 9999, 'API_EXTERNAL_URL': plan['apiUrl'],
    'GOTRUE_SITE_URL': plan['appUrl'], 'GOTRUE_URI_ALLOW_LIST': plan['appUrl'] + '/**',
    'GOTRUE_DB_DRIVER': 'postgres', 'GOTRUE_DB_DATABASE_URL': 'postgres://supabase_auth_admin:' + password + '@db:5432/postgres',
    'GOTRUE_JWT_SECRET': jwt_secret, 'GOTRUE_JWT_EXP': 3600, 'GOTRUE_JWT_AUD': 'authenticated',
    'GOTRUE_JWT_DEFAULT_GROUP_NAME': 'authenticated', 'GOTRUE_JWT_ADMIN_ROLES': 'service_role',
    'GOTRUE_JWT_ISSUER': plan['apiUrl'] + '/auth/v1', 'GOTRUE_DISABLE_SIGNUP': 'false',
    'GOTRUE_EXTERNAL_EMAIL_ENABLED': 'true', 'GOTRUE_MAILER_AUTOCONFIRM': 'true',
    'GOTRUE_SMTP_HOST': 'mail', 'GOTRUE_SMTP_PORT': 1025, 'GOTRUE_SMTP_ADMIN_EMAIL': 'noreply@example.invalid',
    'GOTRUE_SECURITY_REFRESH_TOKEN_ROTATION_ENABLED': 'true', 'GOTRUE_RATE_LIMIT_TOKEN_REFRESH': 500,
})
launch('rest', 'postgrest/postgrest:v16.5', {
    'PGRST_DB_URI': 'postgres://authenticator:' + password + '@db:5432/postgres',
    'PGRST_DB_SCHEMAS': 'public,graphql_public', 'PGRST_DB_EXTRA_SEARCH_PATH': 'public,extensions',
    'PGRST_DB_ANON_ROLE': 'anon', 'PGRST_DB_MAX_ROWS': 1000, 'PGRST_JWT_SECRET': jwt_secret,
})
launch('storage', 'supabase/storage-api:v1.88.0', {
    'DATABASE_URL': 'postgres://supabase_storage_admin:' + password + '@db:5432/postgres',
    'ANON_KEY': anon, 'SERVICE_KEY': service, 'AUTH_JWT_SECRET': jwt_secret,
    'STORAGE_BACKEND': 'file', 'FILE_STORAGE_BACKEND_PATH': '/mnt', 'TENANT_ID': 'stub',
    'GLOBAL_S3_BUCKET': 'stub', 'STORAGE_S3_REGION': 'local', 'FILE_SIZE_LIMIT': 52428800,
    'ENABLE_IMAGE_TRANSFORMATION': 'false', 'IMAGE_TRANSFORMATION_ENABLED': 'false', 'S3_PROTOCOL_ENABLED': 'false',
    'TUS_URL_PATH': '/storage/v1/upload/resumable',
}, ['--mount', 'type=volume,src=' + storage_volume + ',dst=/mnt'])
config = {'_format_version': '2.1', 'services': [], 'consumers': [
    {'username': 'anon', 'keyauth_credentials': [{'key': anon}]},
    {'username': 'service_role', 'keyauth_credentials': [{'key': service}]},
]}
for kind, prefix, port in [('auth', '/auth/v1/', 9999), ('rest', '/rest/v1/', 3000), ('storage', '/storage/v1/', 5000)]:
    config['services'].append({'name': kind, 'url': 'http://' + kind + ':' + str(port) + '/',
        'routes': [{'name': kind, 'paths': [prefix], 'strip_path': True}],
        'plugins': [{'name': 'cors'}, {'name': 'key-auth', 'config': {'key_names': ['apikey'], 'hide_credentials': False}}]})
gateway = private / 'kong.private.json'; gateway.write_text(json.dumps(config)); os.chmod(gateway, 0o600)
launch('kong', 'kong:2.8.1', {'KONG_DATABASE': 'off', 'KONG_DECLARATIVE_CONFIG': '/private/kong.json',
    'KONG_PLUGINS': 'cors,key-auth', 'KONG_DNS_ORDER': 'LAST,A,CNAME', 'KONG_NGINX_WORKER_PROCESSES': 1,
    'KONG_PROXY_LISTEN': '0.0.0.0:8000', 'KONG_ADMIN_LISTEN': 'off',
}, ['--user', '0', '-p', '127.0.0.1:'+str(urlparse(plan['apiUrl']).port)+':8000', '--mount', 'type=bind,src=' + str(gateway) + ',dst=/private/kong.json,readonly'])
actual = json.loads(run(['inspect', db]))[0]
profile = {**plan, 'environment': 'isolated-local-supabase-acl-audit', 'dockerHost': 'unix:///var/run/docker.sock',
    'containerName': actual['Name'][1:], 'containerId': actual['Id'], 'database': 'postgres',
    'requiredContainerLabels': actual['Config']['Labels'], 'anonKey': anon, 'serviceRoleKey': service,
    'productionCredentialsLoaded': False, 'workerToken': secrets.token_hex(32), 'candidateSha256': hashlib.sha256((Path(plan['app'])/plan['candidatePath']).read_bytes()).hexdigest(), 'network': network, 'dbVolume': db_volume, 'storageVolume': storage_volume}
storage_row=next(x for x in owned if x['kind']=='storage')
sa=json.loads(run(['inspect',storage_row['id']]))[0]
profile.update({'storageContainerId':sa['Id'],'storageContainerName':sa['Name'][1:],'storageContainerLabels':sa['Config']['Labels'],'storageMountDestinations':[m['Destination'] for m in sa['Mounts']]})
profile_path = private / 'local-audit-config.json'; profile_path.write_text(json.dumps(profile)); os.chmod(profile_path, 0o600)
print(json.dumps({'status': 'STARTED_FRESH_LOCAL_SERVICES', 'project': project, 'databaseContainerId': db,
    'apiUrl': plan['apiUrl'], 'coreNetworkInternal': True, 'gatewayMailFrontBridge': True, 'hostBindings': '127.0.0.1', 'profile': str(profile_path),
    'existingContainersModified': False, 'applicationSqlApplied': False}))
