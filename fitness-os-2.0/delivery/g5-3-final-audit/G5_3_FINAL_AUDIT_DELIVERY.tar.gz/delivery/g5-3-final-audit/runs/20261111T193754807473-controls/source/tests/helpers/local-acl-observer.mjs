/**
 * Test-only physical-row observer for the explicitly selected fresh local stack.
 * This does not exercise anon/authenticated/service_role authorization: callers
 * must keep those assertions on real SDK/JWT requests.
 */
import { minimalChildEnv, runObservedChild } from './g53-process.mjs';
import { readFileSync, statSync } from 'node:fs';
import { isAbsolute } from 'node:path';


const runFile=async(command,args,options={})=>{const r=await runObservedChild(command,args,options);if(r.code!==0)throw Object.assign(new Error('Local observer command failed'),{result:r});return r;};
const ENVIRONMENT = 'isolated-local-supabase-acl-audit';
const DOCKER_HOST = 'unix:///var/run/docker.sock';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const TABLES = Object.freeze({
  profiles: ['public', 'id'],
  user_preferences: ['public', 'user_id'],
  user_consents: ['public', 'user_id'],
  sync_metadata: ['public', 'user_id'],
  user_data_exports: ['public', 'user_id'],
  user_media: ['public', 'user_id'],
  account_deletion_jobs: ['public', 'user_id'],
  account_mutation_receipts: ['app_private', 'user_id'],
  rate_limit_counters: ['app_private', 'user_id'],
});

export function isLocalAclAuditMode() {
  return Boolean(process.env.FITNESS_ACL_AUDIT_CONFIG?.trim());
}

function fail() {
  // Never print config contents, Docker errors, credentials or SQL output.
  throw new Error('Local ACL observer target/configuration check failed; no fallback observer is permitted.');
}

function record(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function labels(value) {
  if (!record(value) || Object.keys(value).length === 0) fail();
  const pairs = Object.entries(value);
  if (pairs.some(([key, item]) => !key || typeof item !== 'string')) fail();
  return pairs.sort(([a], [b]) => a.localeCompare(b));
}

function localApiOrigin(raw) {
  if (typeof raw !== 'string') fail();
  let value;
  try { value = new URL(raw); } catch { fail(); }
  if (!['http:', 'https:'].includes(value.protocol)
    || !['127.0.0.1', 'localhost', '[::1]'].includes(value.hostname)
    || value.username || value.password || value.search || value.hash
    || !['', '/'].includes(value.pathname)) fail();
  return value.origin;
}

function readConfig() {
  const path = process.env.FITNESS_ACL_AUDIT_CONFIG?.trim();
  if (!path || !isAbsolute(path)) fail();
  let config;
  try {
    const info = statSync(path);
    if (!info.isFile() || info.size > 65_536 || (info.mode & 0o077) !== 0) fail();
    config = JSON.parse(readFileSync(path, 'utf8'));
  } catch { fail(); }
  if (!record(config) || config.environment !== ENVIRONMENT || config.dockerHost !== DOCKER_HOST
    || typeof config.containerName !== 'string'
    || !/^supabase_db_fitness-os-acl-audit-[a-z0-9][a-z0-9_.-]{0,127}$/.test(config.containerName)
    || typeof config.containerId !== 'string' || !/^[0-9a-f]{64}$/.test(config.containerId)
    || (config.database ?? config.db) !== 'postgres'
    || (config.database !== undefined && config.database !== 'postgres')
    || (config.db !== undefined && config.db !== 'postgres')) fail();
  const expectedLabels = labels(config.requiredContainerLabels);
  const apiOrigin = localApiOrigin(config.apiUrl ?? config.supabaseUrl);
  if (apiOrigin !== localApiOrigin(process.env.NEXT_PUBLIC_SUPABASE_URL)) fail();
  return { ...config, expectedLabels };
}

function dockerEnv() { return minimalChildEnv(); }

async function checkedConfig() {
  const config = readConfig();
  const format = '{"Id":{{json .Id}},"Name":{{json .Name}},"Config":{"Labels":{{json .Config.Labels}}},"State":{"Running":{{json .State.Running}}}}';
  let actual;
  try {
    const result = await runFile('docker', ['--host', DOCKER_HOST, 'inspect', '--type', 'container', '--format', format, config.containerId], {
      env: dockerEnv(), encoding: 'utf8', timeout: 15_000, maxBuffer: 262_144,
    });
    actual = JSON.parse(result.stdout.trim());
  } catch { fail(); }
  if (!record(actual) || actual.Id !== config.containerId || actual.Name !== `/${config.containerName}`
    || actual.State?.Running !== true
    || JSON.stringify(labels(actual.Config?.Labels)) !== JSON.stringify(config.expectedLabels)) fail();
  return config;
}

/** Validate the exact fresh stack before any SDK fixture creation. No SQL runs. */
export async function assertLocalAclAuditTarget() {
  await checkedConfig();
}

/** Read only this fixture user's rows from one of nine fixed application tables. */
export async function observeUserRows(table, userId) {
  if (typeof table !== 'string' || !Object.hasOwn(TABLES, table)
    || typeof userId !== 'string' || !UUID.test(userId)) fail();
  const config = await checkedConfig();
  const [schema, owner] = TABLES[table];
  const sql = `begin read only;\nselect coalesce(pg_catalog.jsonb_agg(pg_catalog.to_jsonb(observed)), '[]'::jsonb)::text from (select * from ${schema}.${table} where ${owner} = '${userId.toLowerCase()}'::uuid) observed;\ncommit;\n`;
  try {
    const result = await runFile('docker', ['--host', DOCKER_HOST, 'exec', '-i',
      '--env', 'PGOPTIONS=-c default_transaction_read_only=on -c statement_timeout=10000 -c search_path=pg_catalog',
      config.containerId, 'psql', '-X', '-v', 'ON_ERROR_STOP=1', '-At', '-q', '-U', 'postgres', '-d', 'postgres'],
      {env:dockerEnv(),timeout:20000,input:sql});
    const rows = JSON.parse(result.stdout.trim());
    if (!Array.isArray(rows)) fail();
    return rows;
  } catch {
    throw new Error('Local read-only ACL observer failed; no database output or credential was logged.');
  }
}
