/** Targeted real controls before full regression. No production destination. */
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { createClient } from '@supabase/supabase-js';
import { beginEvidence, cleanupFixtures, checkedSql, strictSqlDenied, minimalChildEnv, runChild, localMailCount, auditedFetch, registerSecret } from '../helpers/g53-evidence.mjs';
const cfg=JSON.parse(readFileSync(process.env.FITNESS_ACL_AUDIT_CONFIG,'utf8'));
const admin=createClient(cfg.apiUrl,cfg.serviceRoleKey,{auth:{persistSession:false,autoRefreshToken:false},global:{fetch:auditedFetch}});
const checks=[],actors=[],audit=beginEvidence('current audit live negative and environment controls',checks);let phase='initialization';
function check(ok,label){phase=label;assert.ok(ok,label);checks.push({label,status:'PASS'});}
try{
 const permission=await checkedSql("\\set VERBOSITY verbose\nbegin;set local role anon;select * from public.profiles;rollback;");strictSqlDenied(permission,'actual direct anon permission');check(true,'actual psql primary 42501 is classified as permission');
 const internal=await checkedSql("\\set VERBOSITY verbose\nbegin;do $$begin raise exception using errcode='XX000',message='diagnostic includes 42501 permission denied';end;$$;rollback;");
 check(internal.code===3&&/ERROR:\s+XX000:/.test(internal.stderr),'actual SQL internal error includes misleading permission text');
 let accepted=false;try{strictSqlDenied(internal,'must reject internal error');accepted=true;}catch{}check(!accepted,'internal XX000 containing 42501 cannot become permission PASS');
 const marker='LOCAL_AUDIT_UNRELATED_PRODUCTION_TOKEN';process.env[marker]='synthetic-only';
 try{const child=await runChild('node',['-e',"console.log(JSON.stringify({leaked:Object.hasOwn(process.env,'LOCAL_AUDIT_UNRELATED_PRODUCTION_TOKEN')}))"],{env:minimalChildEnv()});check(child.code===0&&!JSON.parse(child.stdout).leaked,'actual child does not inherit unrelated environment secret sentinel');}finally{delete process.env[marker];}
 let timeout;try{await runChild('node',['-e','setInterval(()=>{},1000)'],{timeout:100});}catch(e){timeout=e.result;}check(timeout?.timedOut&&timeout.signal==='SIGKILL','actual timed-out child is killed, reaped and has exit evidence');
 check(new URL(cfg.mailUrl).port==='60324','current Mailpit URL comes from this run profile, distinct from 58324 and 59324');
 check(await localMailCount()===0,'running owned Mailpit verified by ID/labels/binding and actual HTTP count');
 let wrongEndpointAccepted=false;try{await auditedFetch('http://127.0.0.1:59324/api/v1/messages');wrongEndpointAccepted=true;}catch{}check(!wrongEndpointAccepted,'old Mailpit endpoint rejected before sending a request');
 const client=createClient(cfg.apiUrl,cfg.anonKey,{auth:{persistSession:false,autoRefreshToken:false},global:{fetch:auditedFetch}});const password='AuditRegistration!'+randomUUID()+'Aa9';registerSecret(password);
 const signup=await client.auth.signUp({email:'user-a@example.invalid',password});if(signup.error)throw signup.error;actors.push({id:signup.data.user.id,email:'user-a@example.invalid',password});check(Boolean(signup.data.user&&signup.data.session),'real public local Auth signup works with synthetic address and local auto-confirm');
 const profile=await client.from('profiles').select('*');check(!profile.error&&profile.data.length===1&&profile.data[0].id===signup.data.user.id,'public registration creates own account defaults with real RLS session');
 check(await localMailCount()===0,'local auto-confirm registration sends no real or captured email');
}catch(error){audit.fail(error,phase);}finally{await audit.finish(()=>cleanupFixtures(admin,actors));}
