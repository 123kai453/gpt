import { beginEvidence, cleanupFixtures, strictDenied, registerSecret, runChild, minimalChildEnv, killOwnedServer, auditedFetch, strictSqlDenied, localMailCount, captureOwnedSupervisor, waitOwnedSupervisor } from '../helpers/g53-evidence.mjs';
/** Real Next HTTP + isolated Supabase. No mocks and no hosted target. */
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { randomUUID, createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { createClient } from '@supabase/supabase-js';
import { createServerClient } from '@supabase/ssr';
import sharp from 'sharp';
import { assertLocalAclAuditTarget, observeUserRows } from '../helpers/local-acl-observer.mjs';
import { setLocalStorageDeleteFault, countLocalStorageBinaryFiles } from '../helpers/local-acl-faults.mjs';

await assertLocalAclAuditTarget();
const cfg = JSON.parse(readFileSync(process.env.FITNESS_ACL_AUDIT_CONFIG, 'utf8'));
assert.equal(cfg.productionCredentialsLoaded, false);
assert.equal(new URL(cfg.appUrl).hostname, '127.0.0.1');
const origin = cfg.appUrl;
const admin = createClient(cfg.apiUrl, cfg.serviceRoleKey, { auth: { persistSession: false, autoRefreshToken: false }, global:{fetch:auditedFetch} });
const actors = [], checks = [], knownGaps = [], ownedPaths = [];
const evidence=beginEvidence('g53-final-security',checks);
let fault = false, readyFault = false, current = 'initialization';
assert.match(cfg.runId, /^[a-f0-9]{8}$/);
const readyFaultName = 'g52_ready_fault_' + cfg.runId;
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
function check(condition, label) { current = label; assert.ok(condition, label); checks.push({ label, status: 'PASS' }); }
function db(result, label) { current = label; assert.equal(result.error, null, label); checks.push({ label, status: 'PASS' }); return result.data; }
function denied(result, label) { current=label;strictDenied(result,label,{kind:label==='client cannot read private journal'?'schema-not-exposed':'database'});check(true,label); }
async function request(actor, path, method = 'GET', body, extraHeaders = {}) {
  assert.ok(path.startsWith('/api/account/'));
  const headers = { Origin: origin, ...extraHeaders };
  if (actor) headers.Cookie = [...actor.cookies].map(([name, value]) => `${name}=${value}`).join('; ');
  if (body && !(body instanceof FormData)) headers['Content-Type'] = 'application/json';
  return auditedFetch(origin + path, { method, headers, body: body instanceof FormData ? body : body ? JSON.stringify(body) : undefined, redirect: 'error' });
}
async function jsonRequest(actor, path, method, body, expected, label) {
  const response = await request(actor, path, method, body);
  check(response.status === expected, label);
  return response.json();
}
const png = await sharp({ create: { width: 3, height: 2, channels: 3, background: 'green' } }).png().toBuffer();
async function upload(actor, bytes = png, mime = 'image/png', expected = 201, extra, idempotencyKey) {
  const form = new FormData(); form.append('file', new File([bytes], 'local.png', { type: mime }));
  if (extra) form.append('status', extra);
  const r = await request(actor, '/api/account/media', 'POST', form, { 'Idempotency-Key': idempotencyKey ?? randomUUID() });
  check(r.status === expected, `Next upload ${mime} returns ${expected}`);
  const data = await r.json();
  if (data.media) ownedPaths.push(['private-media', data.media.object_path]);
  return data.media;
}
const docker = ['--host=unix:///var/run/docker.sock'];
async function rawSql(query, role = 'postgres', claims = {}, commit = false) {
  await assertLocalAclAuditTarget();
  assert.ok(['postgres','anon','authenticated','service_role'].includes(role));
  const claimText = JSON.stringify(claims).replaceAll("'", "''");
  const result=await runChild('docker', [...docker, 'exec', '-i', cfg.containerId, 'psql', '-X', '-w', '-U', 'postgres', '-d', 'postgres', '-v', 'ON_ERROR_STOP=1', '-Atq'], {
    env: minimalChildEnv(), input: `\\set VERBOSITY verbose\nbegin; set local role ${role}; set local request.jwt.claims='${claimText}';\n${query}\n${commit ? 'commit' : 'rollback'};\n`,  timeout: 15000,
  });
  return {...result,status:result.code};
}
async function sqlDenied(query, role, claims, label) {
  const r = await rawSql(query, role, claims);
  strictSqlDenied(r,label);check(true,label);
}
// Appended to the actual HTTP helper prefix. All calls use real isolated services.
import { spawn } from 'node:child_process';
import { openSync, closeSync } from 'node:fs';
const privateRoot = new URL('.', 'file://' + process.env.FITNESS_ACL_AUDIT_CONFIG).pathname;
const control = privateRoot + 'proxy-control.json', eventFile = privateRoot + 'proxy-events.jsonl';
const eventOffset = readFileSync(eventFile,'utf8').length;
const phaseFile = privateRoot + 'reliability-progress.json';
let replacementServer;let replacementSpawnError;
function phase(name) { evidence.phase(name); writeFileSync(phaseFile, JSON.stringify({ phase:name, checks:checks.length, time:new Date().toISOString() })); }
const sleep = ms => new Promise(r=>setTimeout(r,ms));
async function poll(fn,label,timeout=10000) {
  const end=Date.now()+timeout;
  while(Date.now()<end){if(await fn())return;await sleep(100);}
  current=label;throw new Error(label);
}
function rule(id,action,path,method='POST',rpcAction) { writeFileSync(control,JSON.stringify({rules:[{id,action,path,method,rpcAction,remaining:1}],release:[]})); }
function release(id){const x=JSON.parse(readFileSync(control,'utf8'));x.release=[id];writeFileSync(control,JSON.stringify(x));}
function saw(id,stage) { return readFileSync(eventFile,'utf8').slice(eventOffset).split('\n').filter(Boolean).some(l=>{const e=JSON.parse(l);return e.id===id&&e.phase===stage;}); }
async function post(actor,key,bytes=png,mime='image/png') {
  const data=new FormData();data.set('file',new File([bytes],'synthetic.png',{type:mime}));
  const response=await request(actor,'/api/account/media','POST',data,{'Idempotency-Key':key});
  const body=await response.json();
  if(body.media)ownedPaths.push(['private-media',body.media.object_path],['private-media-staging',body.media.object_path]);
  return {status:response.status,body};
}
async function job(action,actor,id=null,key=null,lease=null,data={}) {
  return db(await admin.rpc('server_media_reliability',{p_action:action,p_owner:actor?.id??null,p_media:id,p_request:key,p_lease:lease,p_data:data}),`trusted ${action}`);
}
async function worker(token=cfg.workerToken,actor=null) {
  const headers={'Content-Type':'application/json'};if(token)headers.Authorization='Bearer '+token;
  if(actor)headers.Cookie=[...actor.cookies].map(([n,v])=>n+'='+v).join('; ');
  const response=await auditedFetch(origin+'/api/internal/media/reconcile',{method:'POST',headers,body:'{}'});
  return {status:response.status,body:await response.json()};
}
async function reserve(actor,key=randomUUID()) {
  const bytes=await sharp(png).rotate().png().toBuffer();
  const state=await job('reserve',actor,null,key,null,{request_sha:sha(png),expected_sha:sha(bytes),mime:'image/png',size:bytes.length});
  ownedPaths.push(['private-media',state.media.object_path],['private-media-staging',state.media.object_path]);
  return {...state,bytes,key};
}
async function stage(actor,state) { db(await admin.storage.from('private-media-staging').upload(state.media.object_path,state.bytes,{contentType:'image/png',upsert:false}),'persist real staged source'); }
async function query(text){const r=await rawSql(text);check(r.status===0,'local readonly evidence query');return r.stdout.trim();}
async function fixture(text){const r=await rawSql(text,'postgres',{},true);check(r.status===0,'local disposable fixture transaction');}
async function workerProcess(){
 return runChild('node',['scripts/media-reconcile-worker.mjs','--once'],{env:minimalChildEnv({MEDIA_WORKER_APP_ORIGIN:origin,FITNESS_MEDIA_WORKER_TOKEN:cfg.workerToken}),timeout:65000});
}
async function dockerChecked(args){
 await assertLocalAclAuditTarget();
 const probe=await runChild('docker',[...docker,'inspect','--format','{"Id":{{json .Id}},"Name":{{json .Name}},"Labels":{{json .Config.Labels}},"Mounts":{{json .Mounts}},"Running":{{json .State.Running}}}',cfg.storageContainerId],{env:minimalChildEnv(),timeout:20000});
 assert.equal(probe.code,0,probe.stderr);const actual=JSON.parse(probe.stdout);assert.deepEqual(actual.Labels,cfg.storageContainerLabels);assert.equal(actual.Id,cfg.storageContainerId);assert.equal(actual.Name,'/'+cfg.storageContainerName);assert.ok(actual.Mounts.some(m=>m.Destination==='/mnt'));if(args[0]!=='start')assert.ok(actual.Running);
 const result=await runChild('docker',[...docker,...args],{env:minimalChildEnv(),timeout:20000});assert.equal(result.code,0,result.stderr);return result.stdout;
}
async function binaryFault(media,version,mode='corrupt') {
 const code=`const fs=require('fs');let files=[];const key=process.argv[1],version=process.argv[2],parts=key.split('/');const uuid=/^[a-f0-9-]{36}$/;if(parts.length!==2||!uuid.test(parts[0])||!parts[1].endsWith('.png')||!uuid.test(parts[1].slice(0,-4))||!uuid.test(version))process.exit(2);function walk(p){for(const e of fs.readdirSync(p,{withFileTypes:true})){const q=p+'/'+e.name;if(e.isDirectory())walk(q);else if(q.includes('/private-media/'+key)&&q.endsWith(version))files.push(q)}}walk('/mnt');if(files.length!==1)process.exit(3);const f=files[0];let b=fs.readFileSync(f);b[b.length-1]^=1;fs.writeFileSync(f,b);`;

 check((await dockerChecked(['exec',cfg.storageContainerId,'node','-e',code,media.object_path,version])).length===0,'only synthetic real binary corrupted');void mode;
}
try {
 phase('fresh real A/B and real Next uploads');
 check(db(await admin.auth.admin.listUsers({perPage:2}),'fresh Auth for final suite').users.length===0,'final suite starts with zero users');
 for(const email of ['user-a@example.invalid','user-b@example.invalid']){
  const password='FinalG53!'+randomUUID()+'Aa9';registerSecret(password);
  const user=db(await admin.auth.admin.createUser({email,password,email_confirm:true}),'create final synthetic user').user;
  const cookies=new Map();const client=createServerClient(cfg.apiUrl,cfg.anonKey,{global:{fetch:auditedFetch},cookies:{getAll:()=>[...cookies].map(([name,value])=>({name,value})),setAll:values=>values.forEach(({name,value})=>cookies.set(name,value))}});
  const session=db(await client.auth.signInWithPassword({email,password}),'real final local Auth password session').session;
  actors.push({id:user.id,password,client,cookies,claims:JSON.parse(Buffer.from(session.access_token.split('.')[1],'base64url').toString())});
 }
 const [a,b]=actors;const ma=(await post(a,randomUUID())).body.media,mb=(await post(b,randomUUID())).body.media;
 check(ma.status==='ready'&&mb.status==='ready','A/B real upload ready before fault tests');
 if(process.env.FITNESS_EXPECTED_TEST_FAILURE==='1'){
  await setLocalStorageDeleteFault(a.id,true);fault=true;
  await fixture(`create sequence app_private.g53_late_seq_${cfg.runId};create function app_private.g53_late_fn_${cfg.runId}() returns trigger language plpgsql set search_path='' as $$begin return new;end;$$;revoke all on function app_private.g53_late_fn_${cfg.runId}() from public,anon,authenticated,service_role;create trigger a_g53_late before insert on storage.objects for each row execute function app_private.g53_late_fn_${cfg.runId}();`);
  current='intentional failure with live A/B files and trigger';check(false,'intentional failure with live A/B files and trigger');
 }
 phase('strict error classification against real database responses');
 const perm=await a.client.rpc('server_media_reliability',{p_action:'due'});strictDenied(perm,'genuine permission denial');check(true,'real 42501 denial correctly recognized');
 const internalName='g53_internal_'+cfg.runId;
 await fixture(`create function public.${internalName}() returns void language plpgsql security definer set search_path='' as $$begin raise exception using errcode='XX000',message='synthetic_internal_failure';end;$$;revoke all on function public.${internalName}() from public,anon,authenticated,service_role;grant execute on function public.${internalName}() to service_role;notify pgrst,'reload schema';`);
 await sleep(300);const internal=await admin.rpc(internalName);check(internal.error?.code==='XX000'&&internal.status===500,'real internal SQL exception reaches HTTP 500');
 check((()=>{try{strictDenied(internal,'must not pass internal failure');return false;}catch{return true;}})(),'internal XX000 is never accepted as permission PASS');
 const missing=await admin.rpc('g53_definitely_missing_'+cfg.runId);check(missing.error?.code==='PGRST202','real missing RPC classified separately');
 check((()=>{try{strictDenied(missing,'must not pass missing RPC');return false;}catch{return true;}})(),'missing RPC never accepted as permission PASS');
 await fixture(`drop function public.${internalName}();notify pgrst,'reload schema';`);
 phase('RLS on every application table with actual owner rows');
 for(const actor of actors){
  const snap=await jsonRequest(actor,'/api/account/snapshot','GET',undefined,200,'read own snapshot for full RLS fixture');
  await jsonRequest(actor,'/api/account/mutations','POST',{mutationId:randomUUID(),deviceId:randomUUID(),entity:'profile',baseVersion:snap.profile.version,patch:{display_name:actor===a?'A final':'B final'}},200,'normal profile and sync mutation');
  await jsonRequest(actor,'/api/account/consents','POST',{scope:'analytics',granted:true,policy_version:'final-v1'},201,'append real consent for owner isolation');
  const exp=await request(actor,'/api/account/export','POST',{format:'json'});check(exp.status===200,'normal final export works');
  await fixture(`insert into public.account_deletion_jobs(user_id) values('${actor.id}');`);
 }
 const tables=['profiles','user_preferences','user_consents','sync_metadata','user_data_exports','user_media','account_deletion_jobs'];
 for(const table of tables){const owner=table==='profiles'?'id':'user_id';
  for(const [actor,other] of [[a,b],[b,a]]){
   const own=await rawSql(`select count(*) from public.${table} where ${owner}='${actor.id}';`,'authenticated',actor.claims);check(own.status===0&&Number(own.stdout.trim())>0,`${table}: real owner can SELECT seeded own rows`);
   const cross=await rawSql(`select count(*) from public.${table} where ${owner}='${other.id}';`,'authenticated',actor.claims);check(cross.status===0&&cross.stdout.trim()==='0',`${table}: other owner invisible under RLS`);
  }
  const changes={profiles:"display_name='forged'",user_preferences:"theme='light'",user_consents:'granted=false',sync_metadata:"last_seen_at='2099-01-01T00:00:00Z'",user_data_exports:"status='completed'",user_media:"status='ready'",account_deletion_jobs:"status='completed'"};
  const beforeHash=await query(`select md5(coalesce(jsonb_agg(to_jsonb(t) order by to_jsonb(t)::text)::text,'[]')) from public.${table} t;`);
  await sqlDenied(`update public.${table} set ${changes[table]} where ${owner}='${a.id}';`,'authenticated',a.claims,`${table}: direct authenticated mutation returns 42501`);
  const afterHash=await query(`select md5(coalesce(jsonb_agg(to_jsonb(t) order by to_jsonb(t)::text)::text,'[]')) from public.${table} t;`);
  check(beforeHash===afterHash,`${table}: forbidden write left all actual rows unchanged`);
  for(const role of ['anon','service_role'])await sqlDenied(`select * from public.${table};`,role,{role},`${table}: ${role} direct SELECT is 42501`);
 }
 for(const table of ['account_mutation_receipts','rate_limit_counters','media_upload_jobs','media_job_events','media_orphan_claims','media_maintenance_state','account_cleanup_authorizations'])for(const role of ['anon','authenticated','service_role'])await sqlDenied(`select * from app_private.${table};`,role,role==='authenticated'?a.claims:{role},`${table}: ${role} private schema denied with 42501`);
 await fixture(`delete from public.account_deletion_jobs where user_id in ('${a.id}','${b.id}');`);
 phase('strict Storage denied mutations preserve exact bytes');
 const original=await request(a,'/api/account/media/'+ma.id);const originalHash=sha(new Uint8Array(await original.arrayBuffer()));
 const otherRead=await b.client.storage.from('private-media').download(ma.object_path);strictDenied(otherRead,'B direct private object read',{kind:'storage-read'});check(true,'B direct Storage read has expected private not-found error');
 const crossIntent=await reserve(a);
 const otherWrite=await b.client.storage.from('private-media').upload(crossIntent.media.object_path,png,{contentType:'image/png'});strictDenied(otherWrite,'B write A path',{kind:'storage-write'});check(true,'B direct Storage cross upload has actual RLS denial');
 await jsonRequest(a,'/api/account/media/'+crossIntent.media.id,'DELETE',undefined,200,'owner cancels unused cross-upload test intent');
 const otherUpdate=await b.client.storage.from('private-media').update(ma.object_path,png,{contentType:'image/png'});check(Boolean(otherUpdate.error)&&[400,403,404].includes(Number(otherUpdate.error.statusCode))&&/not found|row.level security|unauthorized/i.test(otherUpdate.error.message),'B update A fails with expected Storage denial');
 const otherDelete=await b.client.storage.from('private-media').remove([ma.object_path]);check(otherDelete.error?Number(otherDelete.error.statusCode)===403:otherDelete.data.length===0,'B direct removal rejects or returns precisely zero visible objects');
 check(sha(new Uint8Array(await (await request(a,'/api/account/media/'+ma.id)).arrayBuffer()))===originalHash,'all denied Storage mutations left A actual bytes unchanged');
 strictDenied(await a.client.storage.from('private-media').download(mb.object_path),'A direct read B private object',{kind:'storage-read'});check(true,'A cannot directly read B either');
 const bOriginalHash=sha(new Uint8Array(await (await request(b,'/api/account/media/'+mb.id)).arrayBuffer()));
 strictDenied(await a.client.storage.from('private-media').update(mb.object_path,png,{contentType:'image/png'}),'A cannot update B',{kind:'storage-update'});check(true,'A cannot directly update B');
 const removeB=await a.client.storage.from('private-media').remove([mb.object_path]);if(removeB.error)strictDenied(removeB,'A cannot remove B',{kind:'storage-write'});else assert.deepEqual(removeB.data,[]);check(true,'A cannot directly remove B');
 check(sha(new Uint8Array(await (await request(b,'/api/account/media/'+mb.id)).arrayBuffer()))===bOriginalHash,'reverse cross-user mutation attempts leave B real bytes unchanged');
 check((await request(a,'/api/account/media/'+mb.id)).status===404,'Next A cannot read B');
 check((await request(a,'/api/account/media/'+mb.id,'DELETE')).status===404,'Next A cannot delete B');
 phase('UUID, request tombstone and real image rejection');
 const tombKey=randomUUID();const tomb=await post(a,tombKey);check(tomb.status===201,'tombstone fixture uploaded');
 await jsonRequest(a,'/api/account/media/'+tomb.body.media.id,'DELETE',undefined,200,'logical upload deletion works');
 check((await post(a,tombKey)).status===409,'deleted idempotency tombstone cannot be silently reused');
 const upper=randomUUID();const lowerUpload=await post(a,upper);check((await post(a,upper.toUpperCase())).body.media.id===lowerUpload.body.media.id,'UUID case variants retain same logical request');
 for(const [bytes,mime,expected,label] of [[png.subarray(0,25),'image/png',415,'truncated PNG'],[new Uint8Array(5242881),'image/png',413,'over 5 MiB original'],[await sharp(png).jpeg().toBuffer(),'image/jpeg',201,'real JPEG'],[await sharp(png).webp().toBuffer(),'image/webp',201,'real WebP']])check((await post(a,randomUUID(),bytes,mime)).status===expected,label+' real Next validation');
 const huge=await sharp({create:{width:4001,height:4000,channels:3,background:'red'}}).png().toBuffer();check((await post(a,randomUUID(),huge,'image/png')).status===415,'over 16 million pixels rejected before decode output');
 // Two real raw pages with distinct pixels; the decoder must independently see two frames.
 const frames=Buffer.alloc(2*4*3);frames.fill(255,0,12);
 const animated=await sharp(frames,{raw:{width:2,height:4,channels:3,pageHeight:2}}).webp({loop:0,delay:[100,100]}).toBuffer();
 check((await sharp(animated,{animated:true}).metadata()).pages===2,'animated fixture really has two independently decoded frames');
 check((await post(a,randomUUID(),animated,'image/webp')).status===415,'real animated WebP rejected');
 phase('raw bytes identity even when normalized pixels match');
 const samePixelsKey=randomUUID(),rawA=await sharp(png).png({compressionLevel:0}).toBuffer(),rawB=await sharp(png).png({compressionLevel:9}).toBuffer();
 check(sha(rawA)!==sha(rawB),'raw PNG fixtures differ despite identical pixels');
 check((await post(a,samePixelsKey,rawA)).status===201,'first raw PNG identity accepted');
 check((await post(a,samePixelsKey,rawB)).status===409,'same key with different raw encoding is rejected despite normalization');
 const noKey=new FormData();noKey.set('file',new File([png],'image.png',{type:'image/png'}));
 check((await request(a,'/api/account/media','POST',noKey)).status===400,'missing Idempotency-Key is explicitly rejected');
 phase('staging cleanup failure and reliable retry');
 await admin.storage.from('private-media-staging').upload(ma.object_path,new Uint8Array(await (await request(a,'/api/account/media/'+ma.id)).arrayBuffer()),{contentType:'image/png'});
 await setLocalStorageDeleteFault(a.id,true,'private-media-staging');fault=true;await worker();
 check((await job('probe',a,ma.id)).staging!==null,'staging deletion failure preserves cleanup source');
 check((await request(a,'/api/account/media/'+ma.id)).status===200,'staging cleanup failure never destroys valid final media');
 await setLocalStorageDeleteFault(a.id,false);fault=false;
 for(let n=0;n<5&&(await job('probe',a,ma.id)).staging;n++)await worker();
 check((await job('probe',a,ma.id)).staging===null,'staging cleanup is actually retried successfully');
 phase('more than ten ready rows, persistent cursor across independent workers');
 for(let n=0;n<13;n++){const item=await reserve(a);await stage(a,item);}
 await fixture(`update app_private.media_upload_jobs set created_at=clock_timestamp()-interval '1 minute' where user_id='${a.id}' and status='pending' and attempts=0;`);
 for(let n=0;n<5;n++)await worker();
 const ready=JSON.parse(await query(`select json_agg(row_to_json(q)) from (select id,user_id,object_path from public.user_media where status='ready' order by id) q;`));check(ready.length>10,'paging fixture contains more than one real page');
 const last=ready.filter(row=>row.user_id===a.id&&row.id!==ma.id).at(-1),owner=a;check(ready.findIndex(row=>row.id===last.id)>=10,'corruption target really lies beyond the first ready page and belongs to A');const lastProbe=await job('probe',owner,last.id);await binaryFault(last,lastProbe.final.version);
 await fixture("update app_private.media_maintenance_state set cursor_id=null where name='ready';");
 check((await workerProcess()).code===0,'first independent worker batch exits zero');
 const cursor=JSON.parse(await query("select row_to_json(s) from app_private.media_maintenance_state s where name='ready';"));check(cursor.cursor_id!==null,'ready scan persists progress in SQL');
 for(let n=0;n<5&&(await job('probe',owner,last.id)).media.status==='ready';n++)check((await workerProcess()).code===0,'restarted independent worker continues persisted progress');
 check((await job('probe',owner,last.id)).media.status==='failed','later ready object cannot starve after worker restart');
 phase('more than ten failed orphan deletes cannot starve later owner');
 const orphanRows=[];
 for(let n=0;n<12;n++){const actor=n===11?b:a,id=randomUUID(),key=actor.id+'/'+id+'.png';db(await admin.rpc('server_media_write',{p_owner:actor.id,p_id:id,p_action:'begin',p_mime:'image/png',p_size:png.length}),'seed actual orphan intent');db(await admin.storage.from('private-media').upload(key,png,{contentType:'image/png'}),'seed actual orphan binary');const storageId=n===11?'ffffffff-ffff-4fff-8fff-ffffffffffff':`00000000-0000-4000-8000-${String(n+1).padStart(12,'0')}`;await fixture(`delete from public.user_media where id='${id}';update storage.objects set id='${storageId}' where bucket_id='private-media' and name='${key}';`);orphanRows.push({actor,key});}
 const bBefore=await countLocalStorageBinaryFiles(b.id);await fixture("update app_private.media_maintenance_state set cursor_id=null where name='orphan';");
 await setLocalStorageDeleteFault(a.id,true);fault=true;await worker();await worker();
 check((await admin.storage.from('private-media').download(orphanRows[11].key)).error!==null,'later B orphan cleaned while first page of A deletes fails');
 check(await countLocalStorageBinaryFiles(b.id)===bBefore-1,'orphan deletion removes exactly B orphan, retaining B registered files');
 check((await request(b,'/api/account/media/'+mb.id)).status===200,'B legitimate media survives other owner orphan failures');
 await setLocalStorageDeleteFault(a.id,false);fault=false;await sleep(4200);for(let n=0;n<5;n++)await worker();
 const remaining=await query(`select count(*) from storage.objects where bucket_id='private-media' and name in (${orphanRows.map(x=>"'"+x.key+"'").join(',')});`);check(remaining==='0','all transient orphan failures later cleaned without hidden ten-page cap');
 phase('real account Storage delete failure, receipt and automatic trusted retry');
 const beforeB=await countLocalStorageBinaryFiles(b.id);await setLocalStorageDeleteFault(a.id,true);fault=true;
 await jsonRequest(a,'/api/account/delete','POST',{confirmation:'DELETE',password:a.password},503,'deletion failure never reports successful account removal');
 const still=await admin.auth.admin.getUserById(a.id);check(still.error===null&&still.data.user?.id===a.id,'Auth user definitely retained while private binaries remain');
 check(await countLocalStorageBinaryFiles(a.id)>0,'actual A binaries retained under injected delete failure');
 const retained=await observeUserRows('account_deletion_jobs',a.id);check(retained.length===1&&retained[0].status==='failed','failed deletion job persists for retry');
 check((await query(`select count(*) from app_private.account_cleanup_authorizations where user_id='${a.id}';`))==='1','password-verified narrow recovery authorization remains');
 const premature=await admin.auth.admin.deleteUser(a.id,false);check(premature.error?.status===500&&premature.error?.name==='AuthRetryableFetchError'&&premature.error?.message==='Database error deleting user','Auth guard prevents even Admin premature deletion with exact observed GoTrue database-error response and separate SQLSTATE proof');
 const blockedAuth=await rawSql(`delete from auth.users where id='${a.id}';`);check(blockedAuth.status!==0&&/42501/.test(blockedAuth.stderr)&&/media_cleanup_required/.test(blockedAuth.stderr),'direct Auth trigger returns exact 42501/media_cleanup_required rather than an unrelated server error');
 check((await admin.auth.admin.getUserById(a.id)).data.user?.id===a.id,'premature delete failure did not remove Auth user');
 check(await countLocalStorageBinaryFiles(b.id)===beforeB,'A delete failure leaves B physical files unchanged');
 await setLocalStorageDeleteFault(a.id,false);fault=false;await sleep(2200);
 for(let n=0;n<5;n++){await worker();const q=await admin.auth.admin.getUserById(a.id);if(q.error?.code==='user_not_found')break;await sleep(1200);}
 const gone=await admin.auth.admin.getUserById(a.id);check(gone.error?.status===404&&gone.error?.code==='user_not_found','trusted automatic retry actually removes Auth A');
 check(await countLocalStorageBinaryFiles(a.id)===0,'automatic retry removes A real binaries from both buckets');
 for(const table of tables.concat(['account_mutation_receipts','rate_limit_counters']))check((await observeUserRows(table,a.id)).length===0,table+' actual A cascade verified');
 for(const table of ['media_upload_jobs','media_job_events','account_cleanup_authorizations'])check(await query(`select count(*) from app_private.${table} where user_id='${a.id}';`)==='0',table+' private A cascade verified');
 check(await countLocalStorageBinaryFiles(b.id)===beforeB,'automatic A cleanup preserved every B binary');
 check((await request(b,'/api/account/media/'+mb.id)).status===200,'B remains normally authenticated after automatic A deletion');
 // Mere user RPC intent never authorizes automatic cleanup or skips password verification.
 db(await b.client.rpc('request_account_deletion'),'B standalone delete request');await worker();
 check((await admin.auth.admin.getUserById(b.id)).data.user?.id===b.id,'mere user deletion RPC does not authorize background Auth deletion');
 await jsonRequest(b,'/api/account/delete','POST',{confirmation:'DELETE',password:b.password},200,'normal password-verified B cleanup still works');
 const goneB=await admin.auth.admin.getUserById(b.id);check(goneB.error?.code==='user_not_found'&&goneB.error?.status===404,'Auth B absence independently verified');
 const mail={total:await localMailCount()};check(mail.total===0,'final suite sends no real or captured mail');
}catch(error){evidence.fail(error,current);}finally{
 await evidence.finish(()=>cleanupFixtures(admin,actors,{stopServer:true}));
}
