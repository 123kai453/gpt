/** Minimal environment and durable process evidence; no production fallback. */
import { spawn } from 'node:child_process';
import { readFileSync, appendFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
export function minimalChildEnv(extra={}) {
 const out={};for(const key of ['PATH','HOME','USER','LANG','LC_ALL','TZ','TMPDIR','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','DOCKER_CONFIG'])if(process.env[key])out[key]=process.env[key];
 return {...out,...extra};
}
export function redactProcess(value){
 let s=String(value??'');
 if(process.env.FITNESS_ACL_AUDIT_CONFIG){const c=JSON.parse(readFileSync(process.env.FITNESS_ACL_AUDIT_CONFIG,'utf8'));for(const key of ['anonKey','serviceRoleKey','workerToken'])if(c[key])s=s.split(c[key]).join('[REDACTED]');}
 return s.replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g,'[REDACTED_JWT]').replace(/(Bearer\s+)[^\s"']+/gi,'$1[REDACTED]').replace(/postgres(?:ql)?:\/\/[^\s"']+/gi,'[REDACTED_CONNECTION]').replace(/((?:password|secret|token|apikey)["']?\s*[:=]\s*)["']?[^\s,}"']+/gi,'$1[REDACTED]');
}
export async function runObservedChild(command,args,{timeout=20000,env=minimalChildEnv(),cwd,input,redact=redactProcess}={}){
 const started_at=new Date().toISOString();
 return await new Promise((resolve,reject)=>{
  const child=spawn(command,args,{cwd,env,stdio:['pipe','pipe','pipe']});let stdout='',stderr='',spawnError=null,timedOut=false,stdout_truncated=false,stderr_truncated=false;
  child.stdout.on('data',b=>{if(stdout.length+b.length>2000000)stdout_truncated=true;else stdout+=b.toString();});
  child.stderr.on('data',b=>{if(stderr.length+b.length>2000000)stderr_truncated=true;else stderr+=b.toString();});
  child.once('error',e=>{spawnError=e;});const timer=setTimeout(()=>{timedOut=true;child.kill('SIGKILL');},timeout);
  child.once('close',(code,signal)=>{
   clearTimeout(timer);const result={command:[command,...args],stdin_sha256:input===undefined?null:createHash('sha256').update(input).digest('hex'),started_at,ended_at:new Date().toISOString(),code,signal,timedOut,stdout,stderr,stdout_truncated,stderr_truncated,spawnError:spawnError?{name:spawnError.name,message:redact(spawnError.message),stack:redact(spawnError.stack)}:null};
   const path=process.env.FITNESS_CHILD_RESULTS;
   if(path)appendFileSync(path,JSON.stringify({...result,command:result.command.map(redact),stdout:redact(stdout),stderr:redact(stderr)})+'\n',{mode:0o600});
   if(spawnError||timedOut||stdout_truncated||stderr_truncated)reject(Object.assign(new Error(timedOut?'Child process timed out':spawnError?'Child process failed to start':'Child output exceeded evidence budget'),{result}));else resolve(result);
  });child.stdin.on('error',()=>{});child.stdin.end(input);
 });
}
