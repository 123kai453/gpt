from urllib.parse import urlparse
"""Durable, sanitized command evidence. No production credential is inherited."""
from pathlib import Path
import datetime,hashlib,json,os,re,signal,subprocess,sys,time,shutil
from zoneinfo import ZoneInfo
plan_path=Path(os.environ.get('FITNESS_G53_FINAL_PLAN',os.environ.get('FITNESS_G53_FINAL_PLAN','/tmp/fitness-g53-current-audit-plan.json')))
p=json.loads(plan_path.read_text());app=Path(p['app']);private=Path(p['private']);out=app/'delivery/g5-3-final-audit'
c=json.loads((private/'local-audit-config.json').read_text())
assert c['productionCredentialsLoaded'] is False and all(urlparse(c[k]).hostname=='127.0.0.1' for k in ('apiUrl','appUrl','proxyUrl','mailUrl'))
mode=sys.argv[1];stamp=datetime.datetime.now(ZoneInfo('Asia/Shanghai')).strftime('%Y%m%dT%H%M%S%f');run=out/'runs'/(stamp+'-'+mode);run.mkdir(parents=True);os.chmod(run,0o700)
allowed=('PATH','HOME','USER','LOGNAME','LANG','LC_ALL','TZ','TMPDIR','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE','DOCKER_CONFIG')
e={k:os.environ[k] for k in allowed if k in os.environ};e.update({'FITNESS_G53_FINAL_PLAN':str(plan_path),'FITNESS_ACL_AUDIT_CONFIG':str(private/'local-audit-config.json'),'FITNESS_SOURCE_MANIFEST':str(out/'SOURCE_MANIFEST.json'),'FITNESS_SUITE_RESULT':str(run/'SUITE_RESULT.json'),'FITNESS_CHILD_RESULTS':str(run/'CHILD_RESULTS.jsonl'),'NEXT_TELEMETRY_DISABLED':'1','NEXT_PUBLIC_SUPABASE_URL':c['apiUrl']})
e['NO_PROXY']=e.get('NO_PROXY','')+',localhost,127.0.0.1,::1'
if mode!='roles':e.update({'NEXT_PUBLIC_APP_URL':c['appUrl'],'NEXT_PUBLIC_SUPABASE_ANON_KEY':c['anonKey'],'SUPABASE_SERVICE_ROLE_KEY':c['serviceRoleKey'],'FITNESS_MEDIA_WORKER_TOKEN':c['workerToken']})
if mode in ('build','start'):e['NEXT_PUBLIC_SUPABASE_URL']=c['proxyUrl']
if '--expected-failure' in sys.argv:e['FITNESS_EXPECTED_TEST_FAILURE']='1'
commands={
 'roles':['node','tests/integration/g53-role-regression.mjs'],
 'http':['node','tests/integration/g53-http.mjs'],
 'reliability':['node','tests/integration/g53-reliability.mjs'],
 'extra':['node','tests/integration/g53-final-security.mjs'],
 'boundary':['node','tests/integration/g53-guard-boundaries.mjs'],
 'unit':['node','node_modules/vitest/vitest.mjs','run','--reporter=json'],
 'typecheck':['node','node_modules/typescript/bin/tsc','--noEmit'],
 'lint':['node','node_modules/eslint/bin/eslint.js','.'],
 'build':['node','node_modules/next/dist/bin/next','build','--webpack'],
 'start':['node','node_modules/next/dist/bin/next','start','--hostname','127.0.0.1','--port',str(urlparse(c['appUrl']).port)],
 'browser':['node','tests/integration/g53-browser.mjs'],
 'proxy':['node',str(out/'fault-proxy.mjs'),str(private/'proxy-control.json'),str(private/'proxy-events.jsonl'),str(private/'local-audit-config.json')],
 'ui-lifecycle':['node','delivery/g5-3-final-audit/browser-session-lifecycle.mjs'],
 'controls':['node','tests/integration/g53-audit-controls.mjs'],
}
assert mode in commands
if '--missing-evidence-control' in sys.argv:
 assert mode=='controls';commands[mode]=['node','-e','process.exit(0)']
if mode=='unit':commands[mode].append('--outputFile='+str(run/'UNIT_RESULTS.raw.json'))
secrets=[c[x] for x in ('serviceRoleKey','anonKey','workerToken')]
def clean(value):
 for key in secrets:value=value.replace(key,'[REDACTED]')
 value=re.sub(r'\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+','[REDACTED_JWT]',value)
 value=re.sub(r'postgres(?:ql)?://[^\s"\']+','[REDACTED_CONNECTION]',value)
 value=re.sub(r'(Bearer\s+)[^\s"\']+',r'\1[REDACTED]',value,flags=re.I)
 return value

def hashes():
 m=json.loads((out/'SOURCE_MANIFEST.json').read_text());values={}
 for row in m['files']:
  h=hashlib.sha256((app/row['path']).read_bytes()).hexdigest();assert h==row['sha256'],'Source/SQL differs from manifest: '+row['path'];values[row['path']]=h
 return values
record={'mode':mode,'command':commands[mode],'cwd':str(app),'started_at':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'status':'RUNNING','expected_failure_probe':'--expected-failure' in sys.argv,'expected_missing_evidence_control':'--missing-evidence-control' in sys.argv,'environment':'ONLY_INDEPENDENT_LOCAL_SUPABASE','environment_id':'ccarenv_b64_Y2NhcmVudl85N2MzZGJlZTljZDQ4MTkxOGQzMjk1NTBiNWY1YWQ0YQ'}
record_file=run/'COMMAND.json';record_file.write_text(json.dumps(record,indent=2)+'\n')
stdout=stderr='';exit_code=None;timed_out=False;error=None;before=None;after=None
try:
 manifest_hash=hashlib.sha256((out/'SOURCE_MANIFEST.json').read_bytes()).hexdigest();before=hashes();archive=run/'source';archive.mkdir();
 for name,expected in before.items():
  target=archive/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(app/name,target);assert hashlib.sha256(target.read_bytes()).hexdigest()==expected
 record['source_archive']=str(archive);record['source_archive_files']=len(before);child=subprocess.Popen(commands[mode],cwd=app,env=e,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
 if mode in ('start','proxy'):
  (private/('app.pid' if mode=='start' else 'proxy.pid')).write_text(str(child.pid))
  # Capture exact identity once exec has produced the actual Next server title.
  deadline=time.monotonic()+20
  while time.monotonic()<deadline and child.poll() is None:
   cmd=Path('/proc/'+str(child.pid)+'/cmdline').read_bytes()
   if (mode=='start' and b'next-server' in cmd) or (mode=='proxy' and b'fault-proxy.mjs' in cmd):
    stat=Path('/proc/'+str(child.pid)+'/stat').read_text();ticks=stat[stat.rfind(')')+2:].split()[19]
    identity={'pid':child.pid,'start_ticks':ticks,'cmdline_base64':__import__('base64').b64encode(cmd).decode(),'source_root':str(app),'cwd':os.readlink('/proc/'+str(child.pid)+'/cwd'),'observed_at':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()}
    assert identity['cwd']==str(app);(private/('app-process.json' if mode=='start' else 'proxy-process.json')).write_text(json.dumps(identity));record['process_identity']={k:v for k,v in identity.items() if k!='cmdline_base64'};record_file.write_text(json.dumps(record,indent=2)+'\n');break
   time.sleep(.05)
 timeout=2400 if mode in ('start','proxy') else 480 if mode in ('reliability','extra','unit','build','browser') else 240
 try:stdout,stderr=child.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(child.pid,signal.SIGKILL);stdout,stderr=child.communicate(timeout=10)
 exit_code=child.returncode;after=hashes();assert before==after and hashlib.sha256((out/'SOURCE_MANIFEST.json').read_bytes()).hexdigest()==manifest_hash,'Source/manifest changed during execution'
except BaseException as exc:error={'name':type(exc).__name__,'message':clean(str(exc))}
record.update({'ended_at':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'exit_code':exit_code,'timed_out':timed_out,'error':error,'source_hashes_before':before,'source_hashes_after':after})
if mode=='unit' and exit_code==0:
 try:
  parsed=json.loads((run/'UNIT_RESULTS.raw.json').read_text());assert parsed['numTotalTests']>0 and parsed['numFailedTests']==0 and parsed['success'] is True,'Missing/nonpassing structured unit result';(run/'UNIT_RESULTS.json').write_text(clean(json.dumps(parsed,indent=2))+'\n')
 except (ValueError,KeyError,AssertionError,OSError) as exc:error={'name':type(exc).__name__,'message':clean(str(exc))}
record['error']=error
record['status']='PASS' if exit_code==0 and not timed_out and error is None else 'BLOCKED' if exit_code is None else 'FAIL'
if mode in ('start','proxy') and exit_code in (-9,-15,137,143) and error is None:record['status']='TERMINATED';record['signal']=-exit_code if exit_code<0 else exit_code-128
suite=run/'SUITE_RESULT.json'
if mode in ('roles','http','reliability','extra','boundary','browser','ui-lifecycle','controls') and not suite.exists():
 record['status']='FAIL';record['error']={'name':'MissingSuiteEvidence','message':'No structured suite result; inspect actual stdout/stderr and OS exit code'}
if suite.exists():
 j=json.loads(suite.read_text());record['suite_status']=j['status'];record['checks']=j['assertions'];record['cleanup_status']=j['cleanup']['status']
 if j['status']!='PASS':record['status']='FAIL'
for name,value in [('stdout.log',stdout),('stderr.log',stderr)]:
 (run/name).write_text(clean(value));os.chmod(run/name,0o600)
record['stdout_sha256']=hashlib.sha256((run/'stdout.log').read_bytes()).hexdigest();record['stderr_sha256']=hashlib.sha256((run/'stderr.log').read_bytes()).hexdigest()
record['driver_exit_code']=0 if record['status']=='PASS' else 1
record_file.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:record.get(k) for k in ['mode','status','exit_code','checks','cleanup_status','timed_out','error']}|{'evidence':str(record_file)},ensure_ascii=False))
raise SystemExit(0 if record['status']=='PASS' else 1)
