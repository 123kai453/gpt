# G5.3 业务与隔离回归

生成时间：2026-11-11T20:03:31.938730+08:00（北京时间）。

本轮副本：`/workspace/fitness-g53-audit-a4774697/fitness-os-2.0`；独立基准commit `6b86090beef3909efa90e0055b1268711b1d97a8`。原仓库仍为 `/workspace/fitness-os-phase2`，分支 `delivery/phase2-hosted-migration-plan`，HEAD `be66fc7a52dc35de9443419bba580845b530be4a`。上一轮独立副本 HEAD `cf75281e39fec4db623b163619db2fec5e14da12`；原447文件和上一轮3418文件本轮结束逐项哈希、分支/HEAD/status/diff/cached diff均未改变，旧6.6MB压缩包也未改变。

本轮使用全新本地 PostgreSQL17.11、Auth2.197.0、Storage1.88.0、PostgREST16.5、Kong2.8.1、Mailpit1.31.3官方缓存镜像，独立网络/卷/新UUID用户；API60321、代理60421、Next3553、Mailpit60324均只绑定127.0.0.1。Node/Next/TS/Chromium的实际版本见LOCAL_VERSIONS.json。未安装工具、升级依赖或连接生产。新本地注册启用自动确认，仅虚构 `.invalid` 地址；真实邮箱验证不在验收范围。

## 保留的业务行为

85个业务/worker文件与已交付最终版完全一致，未为适应测试撤销权限或删除功能。公开上传requireAccount确认本人后submitUpload；原始/规范化SHA由服务端计算，读取真实Storage字节再核验尺寸、MIME、对象ID/version、当前引用和摘要。下载返回已验证的内存快照，用户不能直接ready/completed或写删除状态。

仍保留独立I/O凭证和30秒租约：旧worker/旧token不能提交，未知写入不启动竞争写者；明确丢失/损坏安全失败，网络/5xx等暂不可用保持unavailable和原验证/头像引用，恢复后重新实际验证。五类数据库持久游标、CAS推进/尾页重扫和单项隔离保证后页不被前页失败饿死。

保留资料/偏好CAS、server同步时间、同意记录追加、数据流式导出、头像、密码复验、owner/job绑定cleanup authorization、失败重试和Auth Admin删除。导出completed是服务器完成内容生成，不证明用户磁盘保存。注册用本地公开Auth接口和自动确认，实际产生自己的默认资料及会话；未发送或验收真实邮箱。

## 实际安全与删除证明

本轮真实A/B、anon/authenticated/service_role完成角色、API、直接SQL、Storage和浏览器回归。7个public表的非空双方数据、7个private表、函数EXECUTE/owner/search_path由测试和目录双重核查。14表RLS，15函数owner postgres/固定空search_path，7触发器、9策略、2私有5MiB桶；没有增加service_role表ALL或对authenticated开放维护RPC。完整ACL/函数定义在LOCAL_CATALOG_SNAPSHOT.json。

A本人文件存在且可读，B404或Storage不可见；反向读写删同样核对，拒绝后实际字节/行未变，不能只看到404就当成功。真实Storage删除触发器故障使API503，Auth和重试信息保留；解除后后台重试，Admin404/user_not_found、两桶真实文件0、所属SQL/私有job审计级联0，B正常。用户仅调用删除申请RPC不等于获得后台Auth删除授权。

真实Chromium完成43个页面、深浅主题、390x844手机导航、资料保存、同意追加/撤回、上传/摘要下载/导出、PWA缓存隐私、注销后API401和IndexedDB清除、密码确认删除后的Auth404/文件0/SQL级联。页面路由200不代表训练/营养/AI/穿戴业务已经实现；PHASE1.1视觉未重做，后续产品功能和BRAND STUDIO仍保留。未声称真机手机/手表硬件验收完成。

## 遗留工具入口核查

createVerifiedMedia是历史报告用名，实际代码无此函数；实际uploadVerifiedMedia仍为server-only兼容工具。当前公开API不导入该旧上传工具，而是submitUpload/verifiedDownload；server_media_write在正常删除中仍有deleting/remove用途，保留它不会给浏览器开放begin/ready权限。后续新增服务器调用路径需再次审查，不能把旧工具当新I/O协议入口。

| 类别 | 实际结果 | 数量 | 命令退出码 | 北京时间开始 / 结束 | 证据 |
|---|---|---:|---:|---|---|
| unit | PASS | 108 | 0 | 2026-11-11T19:41:43.812978+08:00 / 2026-11-11T19:41:45.801906+08:00 | `delivery/g5-3-final-audit/runs/20261111T194143812656-unit/COMMAND.json` |
| controls | PASS | 11 | 0 | 2026-11-11T19:42:36.061903+08:00 / 2026-11-11T19:42:39.517970+08:00 | `delivery/g5-3-final-audit/runs/20261111T194236060882-controls/COMMAND.json` |
| roles | PASS | 70 | 0 | 2026-11-11T19:43:08.066011+08:00 / 2026-11-11T19:43:18.604027+08:00 | `delivery/g5-3-final-audit/runs/20261111T194308065598-roles/COMMAND.json` |
| http | PASS | 97 | 0 | 2026-11-11T19:44:31.932495+08:00 / 2026-11-11T19:44:53.518906+08:00 | `delivery/g5-3-final-audit/runs/20261111T194431928529-http/COMMAND.json` |
| reliability | PASS | 104 | 0 | 2026-11-11T19:46:04.468074+08:00 / 2026-11-11T19:47:24.630769+08:00 | `delivery/g5-3-final-audit/runs/20261111T194604467718-reliability/COMMAND.json` |
| extra | PASS | 268 | 0 | 2026-11-11T19:48:31.758849+08:00 / 2026-11-11T19:49:23.952574+08:00 | `delivery/g5-3-final-audit/runs/20261111T194831758502-extra/COMMAND.json` |
| boundary | PASS | 36 | 0 | 2026-11-11T19:44:53.586453+08:00 / 2026-11-11T19:45:08.222395+08:00 | `delivery/g5-3-final-audit/runs/20261111T194453586078-boundary/COMMAND.json` |
| browser | PASS | 62 | 0 | 2026-11-11T19:52:21.812959+08:00 / 2026-11-11T19:52:41.124114+08:00 | `delivery/g5-3-final-audit/runs/20261111T195221812359-browser/COMMAND.json` |
| ui-lifecycle | PASS | 18 | 0 | 2026-11-11T19:54:14.555221+08:00 / 2026-11-11T19:54:27.953076+08:00 | `delivery/g5-3-final-audit/runs/20261111T195414554867-ui-lifecycle/COMMAND.json` |
| typecheck | PASS | 检查命令 | 0 | 2026-11-11T19:41:45.864881+08:00 / 2026-11-11T19:41:51.978944+08:00 | `delivery/g5-3-final-audit/runs/20261111T194145864622-typecheck/COMMAND.json` |
| lint | PASS | 检查命令 | 0 | 2026-11-11T19:43:23.732895+08:00 / 2026-11-11T19:45:23.169366+08:00 | `delivery/g5-3-final-audit/runs/20261111T194323732581-lint/COMMAND.json` |
| build | PASS | 检查命令 | 0 | 2026-11-11T19:42:49.073494+08:00 / 2026-11-11T19:43:23.665058+08:00 | `delivery/g5-3-final-audit/runs/20261111T194249073060-build/COMMAND.json` |

## 保留的边界与生产门禁

租约过期不代表远端写入结束。未知I/O没有终止回应或匹配提交标记时，系统继续阻止删除，不能为了恢复可用性盲目释放屏障；若进程已消失且没有可核实终止证据，仍可能需要受控人工核实。已经验证“不误报成功”的安全合同，没有声称所有未知provider结果都能自动恢复。

当前Storage1.88.0为真实本地文件后端；托管版对象version/user_metadata/canUpload和删除补偿仍需独立只读核对及后续授权测试。没有将本地测试、事务回滚或浏览器路由200冒充生产验收、完整备份恢复，或训练/营养/AI/穿戴模块已完工。

生产门禁只能是PENDING：尚缺最新生产只读核查、托管Storage兼容性、生产凭据与worker配置、正式数据库备份、Storage文件备份、完整恢复演练、迁移审批、正式部署和真实用户验收。历史public-only归档/9个TOC/pg_restore --list不是完整数据库恢复证明；Windows私密原件和原始云端管理元数据的缺口不能由本轮补造。

本轮SQL哈希仍为 `56db7fe0b71ebfc2ffa5a6e6d7c57508da500014e8e6b185bc6db0334b96488d`，无新SQL候选或生产迁移。它是独立完整initial，只在本轮空白本地实例应用一次，不与旧initial连续执行；正式目标若已初始化，后续须根据新快照另做前向迁移。

没有生产连接/SQL、db push、dry-run、部署、Secret修改、真实邮件或购买。停止在G5.3；G5.4/G5.5/PHASE2.1 BRAND STUDIO/PHASE3均未启动，后续既定阶段保留。
