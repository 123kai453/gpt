from urllib.parse import urlparse
"""Read-only final evidence for this task's exact disposable stack, never hosted."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, urllib.request
from zoneinfo import ZoneInfo

app = Path(__file__).resolve().parents[2]
out = app / 'delivery/g5-3-final-audit'
plan = json.loads(Path(os.environ.get('FITNESS_G53_FINAL_PLAN','/tmp/fitness-g53-current-audit-plan.json')).read_text())
private = Path(plan['private'])
c = json.loads((private/'local-audit-config.json').read_text())
assert c['productionCredentialsLoaded'] is False and urlparse(c['apiUrl']).hostname=='127.0.0.1'
env = {k:os.environ[k] for k in ('PATH','HOME','LANG','DOCKER_CONFIG') if k in os.environ}
docker = ['docker','--host=unix:///var/run/docker.sock']
commands=[]
def run(args, data=None, timeout=30):
    start=datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()
    r=subprocess.run(args,env=env,input=data,text=True,capture_output=True,timeout=timeout)
    commands.append({'command':args,'stdin_sha256':hashlib.sha256(data.encode()).hexdigest() if data else None,
                     'started_at':start,'ended_at':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
                     'exit_code':r.returncode,'stderr':r.stderr})
    assert r.returncode==0,'Local evidence command failed; inspect recorded exit code'
    return r.stdout
def inspect(identity):
    v=json.loads(run(docker+['inspect','--format','{"Id":{{json .Id}},"Name":{{json .Name}},"Image":{{json .Image}},"Labels":{{json .Config.Labels}},"Running":{{json .State.Running}},"Ports":{{json .HostConfig.PortBindings}},"Mounts":{{json .Mounts}}}',identity]))
    assert v['Labels']['fitness.g53.run']==plan['runId'] and v['Id']==identity and v['Running']
    return v
db=inspect(c['containerId']);assert db['Name']=='/'+c['containerName'] and db['Labels']==c['requiredContainerLabels']
query="""begin read only;
set local statement_timeout='15s';
select json_build_object(
 'observed_at',clock_timestamp(),'server_version',current_setting('server_version'),
 'auth_users',(select count(*) from auth.users),'storage_objects',(select count(*) from storage.objects),
 'buckets',(select json_agg(json_build_object('id',id,'public',public,'limit',file_size_limit,'mimes',allowed_mime_types) order by id) from storage.buckets),
 'tables',(select json_agg(json_build_object('schema',n.nspname,'name',t.relname,'rls',t.relrowsecurity,'owner',pg_get_userbyid(t.relowner),'acl',t.relacl) order by n.nspname,t.relname) from pg_class t join pg_namespace n on n.oid=t.relnamespace where n.nspname in ('public','app_private') and t.relkind='r'),
 'columns',(select json_agg(json_build_object('schema',n.nspname,'table',t.relname,'column',a.attname,'type',format_type(a.atttypid,a.atttypmod),'not_null',a.attnotnull,'acl',a.attacl) order by n.nspname,t.relname,a.attnum) from pg_attribute a join pg_class t on t.oid=a.attrelid join pg_namespace n on n.oid=t.relnamespace where n.nspname in ('public','app_private') and t.relkind='r' and a.attnum>0 and not a.attisdropped),
 'functions',(select json_agg(json_build_object('schema',n.nspname,'name',f.proname,'signature',pg_get_function_identity_arguments(f.oid),'owner',pg_get_userbyid(f.proowner),'security_definer',f.prosecdef,'config',f.proconfig,'definition',pg_get_functiondef(f.oid),
 'public_execute',exists(select 1 from aclexplode(coalesce(f.proacl,acldefault('f',f.proowner))) a where a.grantee=0 and a.privilege_type='EXECUTE'),
 'anon_execute',has_function_privilege('anon',f.oid,'EXECUTE'),'authenticated_execute',has_function_privilege('authenticated',f.oid,'EXECUTE'),'service_execute',has_function_privilege('service_role',f.oid,'EXECUTE')) order by n.nspname,f.proname) from pg_proc f join pg_namespace n on n.oid=f.pronamespace where n.nspname in ('public','app_private')),
 'triggers',(select json_agg(json_build_object('schema',n.nspname,'name',t.tgname,'table',r.relname,'definition',pg_get_triggerdef(t.oid)) order by n.nspname,t.tgname) from pg_trigger t join pg_class r on r.oid=t.tgrelid join pg_namespace n on n.oid=r.relnamespace where not t.tgisinternal and (n.nspname in ('public','app_private') or t.tgname in ('fitness_os_account_defaults','fitness_media_auth_delete_guard','fitness_media_storage_guard'))),
 'policies',(select json_agg(to_jsonb(p) order by schemaname,policyname) from pg_policies p where schemaname in ('public','app_private','storage')),
 'constraints',(select json_agg(json_build_object('schema',n.nspname,'table',t.relname,'name',q.conname,'type',q.contype,'definition',pg_get_constraintdef(q.oid)) order by n.nspname,t.relname,q.conname) from pg_constraint q join pg_class t on t.oid=q.conrelid join pg_namespace n on n.oid=t.relnamespace where n.nspname in ('public','app_private')),
 'indexes',(select json_agg(to_jsonb(i) order by schemaname,tablename,indexname) from pg_indexes i where schemaname in ('public','app_private')),
 'storage_rls',(select json_agg(json_build_object('table',relname,'rls',relrowsecurity,'acl',relacl)) from pg_class where oid in ('storage.objects'::regclass,'storage.buckets'::regclass)),
 'role_flags',(select json_agg(json_build_object('role',rolname,'super',rolsuper,'bypass_rls',rolbypassrls,'inherit',rolinherit)) from pg_roles where rolname in ('postgres','anon','authenticated','service_role')),
 'schema_acl',(select json_agg(json_build_object('schema',nspname,'acl',nspacl,'owner',pg_get_userbyid(nspowner))) from pg_namespace where nspname in ('public','app_private','auth','storage')),
 'default_acl',(select json_agg(json_build_object('owner',pg_get_userbyid(defaclrole),'schema',coalesce(n.nspname,'*'),'kind',defaclobjtype,'acl',defaclacl)) from pg_default_acl d left join pg_namespace n on n.oid=d.defaclnamespace),
 'migration_history_exists',to_regclass('supabase_migrations.schema_migrations') is not null);
commit;"""
def sql(query):
    inspect(c['containerId'])
    return run(docker+['exec','-i',c['containerId'],'psql','-X','-w','-h','/var/run/postgresql','-U','postgres','-d','postgres','-Atq','-v','ON_ERROR_STOP=1'],query)
catalog=json.loads(sql(query))
assert len(catalog['tables'])==14 and all(t['rls'] for t in catalog['tables'])
assert len(catalog['functions'])==15 and len(catalog['triggers'])==7 and len(catalog['policies'])==9
for f in catalog['functions']:
    assert f['owner']=='postgres' and f['security_definer'] and f['config']==['search_path=""']
    assert not f['public_execute'] and not f['anon_execute']
    trusted=f['name'] in ('server_media_write','server_export_write','server_deletion_progress','server_media_reliability')
    assert f['service_execute']==trusted and f['authenticated_execute']==(f['schema']=='public' and not trusted)
assert catalog['auth_users']==catalog['storage_objects']==0
assert len(catalog['buckets'])==2 and all(not b['public'] and b['limit']==5242880 for b in catalog['buckets'])
rows={}
for table in catalog['tables']:
    name=table['schema']+'.'+table['name'];rows[name]=int(sql('begin read only; set local statement_timeout=\'5s\'; select count(*) from '+name+'; commit;').strip())
assert rows['app_private.media_maintenance_state']==5
assert all(v==0 for k,v in rows.items() if k!='app_private.media_maintenance_state')
catalog['row_counts']=rows
(out/'LOCAL_CATALOG_SNAPSHOT.json').write_text(json.dumps({'scope':'ONLY_THIS_DISPOSABLE_LOCAL_STACK','container_id':c['containerId'],**catalog},indent=2)+'\n')
owned=json.loads((private/'owned-containers.json').read_text());versions=[]
for item in owned:
    actual=inspect(item['id']);assert actual['Name']=='/'+item['name']
    versions.append({**item,'image_id':actual['Image'],'ports':actual['Ports'],'labels':actual['Labels']})
for item in versions:
    for port,binding in (item['ports'] or {}).items():
        assert all(b['HostIp']=='127.0.0.1' for b in binding)
pkg={}
for name in ['next','typescript','vitest','sharp','@playwright/test','@supabase/supabase-js']:
    pkg[name]=json.loads((app/'node_modules'/name/'package.json').read_text())['version']
runtime={'observed_at':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'os':run(['uname','-srm']).strip(),'node':run(['node','--version']).strip(),'docker':run(docker+['version','--format','{{.Server.Version}}']).strip(),'chromium':run(['/usr/bin/chromium','--version']).strip(),'packages':pkg,'containers':versions,'host_supabase_cli':'NOT_INSTALLED; manually orchestrated real official Supabase services','production_access':'NOT_USED'}
(out/'LOCAL_VERSIONS.json').write_text(json.dumps(runtime,indent=2)+'\n')
storage=inspect(c['storageContainerId']);assert storage['Name']=='/'+c['storageContainerName'] and storage['Labels']==c['storageContainerLabels']
code="""const fs=require('fs');let counts={'private-media':0,'private-media-staging':0};function walk(p){for(const e of fs.readdirSync(p,{withFileTypes:true})){const q=p+'/'+e.name;if(e.isDirectory())walk(q);else if(e.isFile())for(const b of Object.keys(counts))if(q.includes('/'+b+'/'))counts[b]++;}}walk('/mnt');console.log(JSON.stringify({counts,root:'/mnt',allOwners:true}));"""
physical=json.loads(run(docker+['exec',c['storageContainerId'],'node','-e',code]));assert all(v==0 for v in physical['counts'].values())
(out/'PHYSICAL_STORAGE_CHECK.json').write_text(json.dumps({'status':'PASS','scope':'real file backend in owned Storage container; all owners, both buckets',**physical},indent=2)+'\n')
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
with opener.open(c['mailUrl']+'/api/v1/messages',timeout=8) as response:mail=json.load(response)
assert mail['total']==0
(out/'MAIL_CHECK.json').write_text(json.dumps({'status':'PASS','localMailpitTotal':mail['total'],'externalSMTP':False},indent=2)+'\n')
browser=list((app/'.next/static').rglob('*'));browser=[f for f in browser if f.is_file()]
matches=[str(f.relative_to(app)) for f in browser if any(c[k].encode() in f.read_bytes() for k in ('serviceRoleKey','workerToken'))]
assert not matches
(out/'BROWSER_SECRET_SCAN.json').write_text(json.dumps({'status':'PASS','files_scanned':len(browser),'service_key_or_worker_token_matches':matches,'scope':'this run local bindings in generated browser static assets'},indent=2)+'\n')
(out/'CANDIDATE_APPLICATION.json').write_bytes((private/'candidate-apply.json').read_bytes())
(out/'NETWORK_FAULT_EVIDENCE.jsonl').write_bytes((private/'proxy-events.jsonl').read_bytes())
(out/'CATALOG_COMMANDS.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps({'catalog':'PASS','tables':14,'functions':15,'auth_users':0,'objects':0,'physical_files':physical['counts'],'mail_count':0,'browser_secret_matches':0}))
