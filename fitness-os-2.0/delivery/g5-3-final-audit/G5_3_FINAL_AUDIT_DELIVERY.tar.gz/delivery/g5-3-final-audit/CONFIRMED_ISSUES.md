# G5.3 已确认问题与归类

生成时间：2026-11-11T20:03:31.938730+08:00（北京时间）。

本轮副本：`/workspace/fitness-g53-audit-a4774697/fitness-os-2.0`；独立基准commit `6b86090beef3909efa90e0055b1268711b1d97a8`。原仓库仍为 `/workspace/fitness-os-phase2`，分支 `delivery/phase2-hosted-migration-plan`，HEAD `be66fc7a52dc35de9443419bba580845b530be4a`。上一轮独立副本 HEAD `cf75281e39fec4db623b163619db2fec5e14da12`；原447文件和上一轮3418文件本轮结束逐项哈希、分支/HEAD/status/diff/cached diff均未改变，旧6.6MB压缩包也未改变。

本轮使用全新本地 PostgreSQL17.11、Auth2.197.0、Storage1.88.0、PostgREST16.5、Kong2.8.1、Mailpit1.31.3官方缓存镜像，独立网络/卷/新UUID用户；API60321、代理60421、Next3553、Mailpit60324均只绑定127.0.0.1。Node/Next/TS/Chromium的实际版本见LOCAL_VERSIONS.json。未安装工具、升级依赖或连接生产。新本地注册启用自动确认，仅虚构 `.invalid` 地址；真实邮箱验证不在验收范围。

## 已交付版本已修复的能力

| 编号 | 项目 | 初查分类 | 当前验证 |
|---|---|---|---|
| T01 | worker/replacement child environment | ALREADY_FIXED | PASS（本轮重验） |
| T02 | REST/Storage denial distinctions | ALREADY_FIXED | PASS（本轮重验） |
| T03 | paged teardown/Auth and physical file checks | ALREADY_FIXED | PASS（本轮重验） |
| T04 | owned Next identity before kill | ALREADY_FIXED | PASS（本轮重验） |
| T05 | actual before/after source hashes | ALREADY_FIXED | PASS（本轮重验） |
| B01 | upload idempotency, raw bytes conflict and tombstone | ALREADY_FIXED | PASS（本轮重验） |
| B02 | same request concurrency and A/B scoping | ALREADY_FIXED | PASS（本轮重验） |
| B03 | actual PNG/JPEG/WebP decode and limits | ALREADY_FIXED | PASS（本轮重验） |
| B04 | server-computed raw and normalized SHA256 | ALREADY_FIXED | PASS（本轮重验） |
| B05 | Storage object id/version/current reference | ALREADY_FIXED | PASS（本轮重验） |
| B06 | pending/processing/ready/unavailable/failed/deleting transitions | ALREADY_FIXED | PASS（本轮重验） |
| B07 | independent I/O operation receipts | ALREADY_FIXED | PASS（本轮重验） |
| B08 | 30s lease, expired lease and old worker fencing | ALREADY_FIXED | PASS（本轮重验） |
| B09 | lost Storage/DB acknowledgement recovery | ALREADY_FIXED | PASS（本轮重验） |
| B10 | durable sweep cursor and retry fairness | ALREADY_FIXED | PASS（本轮重验） |
| B11 | orphan/staging retries and owner isolation | ALREADY_FIXED | PASS（本轮重验） |
| B12 | media/account cancellation and deletion barrier | ALREADY_FIXED | PASS（本轮重验） |
| B13 | password reauthentication before trusted cleanup authorization | ALREADY_FIXED | PASS（本轮重验） |
| B14 | owner/job-bound cleanup authorization and retry | ALREADY_FIXED | PASS（本轮重验） |
| B15 | actual Auth Admin deletion plus binary/SQL verification | ALREADY_FIXED | PASS（本轮重验） |
| B16 | real A/B RLS and file isolation | ALREADY_FIXED | PASS（本轮重验） |
| B17 | RLS/ACL/SECURITY DEFINER and server-only RPC scope | ALREADY_FIXED | PASS（本轮重验） |

## 本轮确认并修复的5组工具问题

### C01 legacy observer/fault subprocess boundary and diagnostics

位置：`tests/helpers/local-acl-observer.mjs; local-acl-faults.mjs`。初查：CONFIRMED_ISSUE；结束：FIXED_THIS_ROUND。

The main runner was sanitized, but direct legacy helper calls used process.env minus a blacklist and discarded useful child errors.

g53-process.mjs central whitelist, bounded child execution, actual exit/stdout/stderr and append-only redacted JSONL. No actual production credential leakage was observed.

### C02 raw SQL permission substring accepted false proof

位置：`tests/integration/g53-http.mjs and g53-final-security.mjs sqlDenied`。初查：CONFIRMED_ISSUE；结束：FIXED_THIS_ROUND。

Nonzero psql plus any occurrence of 42501 could accept primary XX000 with misleading text.

Require psql exit3, no timeout/signal and primary verbose ERROR SQLSTATE42501. Actual XX000 containing42501 is rejected.

### C03 hardcoded Mailpit endpoint and incomplete ownership binding

位置：`mail checks and auditedFetch in tests/helpers/g53-evidence.mjs`。初查：CONFIRMED_ISSUE；结束：FIXED_THIS_ROUND。

58324 and59324 belong to different historical instances; no evidence the prior59324 result was fabricated. Current helpers nevertheless hardcoded it instead of current config.

Current mailUrl60324, owned Mailpit ID/name/labels/running/port binding checked; reject old endpoint before request.

### C04 final PASS generated before replacement supervisor termination

位置：`tests/integration/g53-reliability.mjs finally`。初查：CONFIRMED_ISSUE；结束：FIXED_THIS_ROUND。

finish wrote the result before waiting for the replacement runner; a later failure could escape final status.

Wait/capture supervisor inside the cleanup callback, before finish decides status; actual exit operation timestamp precedes suite result.

### C05 zero child exit without result could become driver PASS

位置：`delivery/g5-3-final/run-command.py`。初查：CONFIRMED_ISSUE；结束：FIXED_THIS_ROUND。

A suite exiting0 without SUITE_RESULT could satisfy the generic driver success condition.

Mandatory structured result for integration modes; actual child exit0/no output is FAIL with driver exit1.

## 本轮开发错误与未验证事项

新增测试漏minimalChildEnv的.d.mts声明，首次typecheck/build实际失败；同时编译器收录了历史失败TS快照。已补声明、只排除delivery/**/runs/**/source/**；strict、当前src、当前tests仍检查，新增单元断言保护该范围。失败原件未删除。末尾进程清点第一次把Codex sandbox启动祖先识别为残留，已按真实/proc祖先链排除检查器自身；两个清点均未杀未知进程，FINAL_PROCESS_CHECK有说明。

追加式JSONL避免多个测试进程对同一日志做读改写；这是结构加固，未声称观察到旧日志已丢行。未发现当前业务源码需要重写的已证实新缺陷。生产相关项及无终止证据的未知I/O自动最终恢复标记UNVERIFIED/生产PENDING，不夸大为已利用漏洞。

## 保留的边界与生产门禁

租约过期不代表远端写入结束。未知I/O没有终止回应或匹配提交标记时，系统继续阻止删除，不能为了恢复可用性盲目释放屏障；若进程已消失且没有可核实终止证据，仍可能需要受控人工核实。已经验证“不误报成功”的安全合同，没有声称所有未知provider结果都能自动恢复。

当前Storage1.88.0为真实本地文件后端；托管版对象version/user_metadata/canUpload和删除补偿仍需独立只读核对及后续授权测试。没有将本地测试、事务回滚或浏览器路由200冒充生产验收、完整备份恢复，或训练/营养/AI/穿戴模块已完工。

生产门禁只能是PENDING：尚缺最新生产只读核查、托管Storage兼容性、生产凭据与worker配置、正式数据库备份、Storage文件备份、完整恢复演练、迁移审批、正式部署和真实用户验收。历史public-only归档/9个TOC/pg_restore --list不是完整数据库恢复证明；Windows私密原件和原始云端管理元数据的缺口不能由本轮补造。

本轮SQL哈希仍为 `56db7fe0b71ebfc2ffa5a6e6d7c57508da500014e8e6b185bc6db0334b96488d`，无新SQL候选或生产迁移。它是独立完整initial，只在本轮空白本地实例应用一次，不与旧initial连续执行；正式目标若已初始化，后续须根据新快照另做前向迁移。

没有生产连接/SQL、db push、dry-run、部署、Secret修改、真实邮件或购买。停止在G5.3；G5.4/G5.5/PHASE2.1 BRAND STUDIO/PHASE3均未启动，后续既定阶段保留。
