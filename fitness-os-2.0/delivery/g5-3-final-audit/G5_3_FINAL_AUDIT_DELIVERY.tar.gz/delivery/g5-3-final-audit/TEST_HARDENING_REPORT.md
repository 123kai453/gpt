# G5.3 测试可信度修复报告

生成时间：2026-11-11T20:03:31.938730+08:00（北京时间）。

本轮副本：`/workspace/fitness-g53-audit-a4774697/fitness-os-2.0`；独立基准commit `6b86090beef3909efa90e0055b1268711b1d97a8`。原仓库仍为 `/workspace/fitness-os-phase2`，分支 `delivery/phase2-hosted-migration-plan`，HEAD `be66fc7a52dc35de9443419bba580845b530be4a`。上一轮独立副本 HEAD `cf75281e39fec4db623b163619db2fec5e14da12`；原447文件和上一轮3418文件本轮结束逐项哈希、分支/HEAD/status/diff/cached diff均未改变，旧6.6MB压缩包也未改变。

本轮使用全新本地 PostgreSQL17.11、Auth2.197.0、Storage1.88.0、PostgREST16.5、Kong2.8.1、Mailpit1.31.3官方缓存镜像，独立网络/卷/新UUID用户；API60321、代理60421、Next3553、Mailpit60324均只绑定127.0.0.1。Node/Next/TS/Chromium的实际版本见LOCAL_VERSIONS.json。未安装工具、升级依赖或连接生产。新本地注册启用自动确认，仅虚构 `.invalid` 地址；真实邮箱验证不在验收范围。

## 本轮实际修改

- 新g53-process.mjs统一子进程白名单、超时、回收、真实退出码、stdout/stderr、脱敏、明确输出预算与截断失败；旧observer/fault helpers也使用此路径，不再仅删几个已知变量。保留HOME/DOCKER_CONFIG原值，不改全局设置。
- rawSql在每次SQL前核对本次容器；权限断言读取psql verbose ERROR主SQLSTATE，不匹配任意消息里的42501。真实XX000含42501的反例已执行，不能误报PASS。
- Mailpit完全从当前profile取地址；检查本次容器ID/name/labels/running、真实8025映射，再请求计数。未启动服务时不会凭空报0。
- Next杀进程保留PID/start_ticks/完整cmdline/cwd检查；替代监督进程退出现在纳入cleanup，先完成退出观察再决定PASS。所有worker/SQL/Docker子命令有界、记录退出；JSONL追加取代易竞态的日志读改写。
- 集成模式缺少结构化结果时，即使子进程exit0也FAIL。真实负向控制child0/driver1保留，不伪造异常堆栈。
- 新增4个离线单元、11个真实定向断言；保留此前全部测试名称/断言。新测试声明和历史证据快照的编译范围已修正，未关掉strict、未排除当前测试。

## 实际结果

| 类别 | 实际结果 | 数量 | 命令退出码 | 北京时间开始 / 结束 | 证据 |
|---|---|---:|---:|---|---|
| unit | PASS | 108 | 0 | 2026-11-11T19:41:43.812978+08:00 / 2026-11-11T19:41:45.801906+08:00 | `delivery/g5-3-final-audit/runs/20261111T194143812656-unit/COMMAND.json` |
| controls | PASS | 11 | 0 | 2026-11-11T19:42:36.061903+08:00 / 2026-11-11T19:42:39.517970+08:00 | `delivery/g5-3-final-audit/runs/20261111T194236060882-controls/COMMAND.json` |
| roles | PASS | 70 | 0 | 2026-11-11T19:43:08.066011+08:00 / 2026-11-11T19:43:18.604027+08:00 | `delivery/g5-3-final-audit/runs/20261111T194308065598-roles/COMMAND.json` |
| http | PASS | 97 | 0 | 2026-11-11T19:44:31.932495+08:00 / 2026-11-11T19:44:53.518906+08:00 | `delivery/g5-3-final-audit/runs/20261111T194431928529-http/COMMAND.json` |
| reliability | PASS | 104 | 0 | 2026-11-11T19:46:04.468074+08:00 / 2026-11-11T19:47:24.630769+08:00 | `delivery/g5-3-final-audit/runs/20261111T194604467718-reliability/COMMAND.json` |
| extra | PASS | 268 | 0 | 2026-11-11T19:48:31.758849+08:00 / 2026-11-11T19:49:23.952574+08:00 | `delivery/g5-3-final-audit/runs/20261111T194831758502-extra/COMMAND.json` |
| boundary | PASS | 36 | 0 | 2026-11-11T19:44:53.586453+08:00 / 2026-11-11T19:45:08.222395+08:00 | `delivery/g5-3-final-audit/runs/20261111T194453586078-boundary/COMMAND.json` |
| browser | PASS | 62 | 0 | 2026-11-11T19:52:21.812959+08:00 / 2026-11-11T19:52:41.124114+08:00 | `delivery/g5-3-final-audit/runs/20261111T195221812359-browser/COMMAND.json` |
| ui-lifecycle | PASS | 18 | 0 | 2026-11-11T19:54:14.555221+08:00 / 2026-11-11T19:54:27.953076+08:00 | `delivery/g5-3-final-audit/runs/20261111T195414554867-ui-lifecycle/COMMAND.json` |
| typecheck | PASS | 检查命令 | 0 | 2026-11-11T19:41:45.864881+08:00 / 2026-11-11T19:41:51.978944+08:00 | `delivery/g5-3-final-audit/runs/20261111T194145864622-typecheck/COMMAND.json` |
| lint | PASS | 检查命令 | 0 | 2026-11-11T19:43:23.732895+08:00 / 2026-11-11T19:45:23.169366+08:00 | `delivery/g5-3-final-audit/runs/20261111T194323732581-lint/COMMAND.json` |
| build | PASS | 检查命令 | 0 | 2026-11-11T19:42:49.073494+08:00 / 2026-11-11T19:43:23.665058+08:00 | `delivery/g5-3-final-audit/runs/20261111T194249073060-build/COMMAND.json` |

774项最终通过包括108个离线单元和666个真实集成/浏览器登记断言，包含夹具/观察断言，不是774个互不重复业务场景。负向控制2项保持FAIL：真实断言失败child1/driver1/cleanup PASS；空结果控制child0/driver1，无资源可清理所以N/A。SQL权限和内部异常的预期exit3、超时子进程SIGKILL以及服务有意停止的143/监督进程1不当作业务断言失败，原始命令均可查。

失败记录有阶段/断言/错误名/信息/脱敏堆栈；编译器诊断保留真实文件行号。正常exit0的空结果子进程本来没有异常栈，不补造；驱动错误名、源码SHA和命令/时间足以追溯。每个测试套件前后134个实际文件SHA一致，SQL/核心TS/测试/helper/执行器纳入；不是复制cfg.candidateSha256。时间字段assertion_result_recorded只代表记录断言完成的时间，不虚构逐用例耗时；HTTP与子命令另有真实起止，Vitest有实际duration。

完整逐项名称、目标、命令、退出码见FINAL_TEST_RESULTS.json。所有旧失败、首次类型/构建失败、预期控制和服务生命周期见EXECUTION_TIMELINE.json与runs/；没有删除失败测试、扩大授权或用Mock冒充集成。离线资源fetch模拟仅标为离线；定向控制的SQL/注册/Mailpit/子进程为真实执行。

## 保留的边界与生产门禁

租约过期不代表远端写入结束。未知I/O没有终止回应或匹配提交标记时，系统继续阻止删除，不能为了恢复可用性盲目释放屏障；若进程已消失且没有可核实终止证据，仍可能需要受控人工核实。已经验证“不误报成功”的安全合同，没有声称所有未知provider结果都能自动恢复。

当前Storage1.88.0为真实本地文件后端；托管版对象version/user_metadata/canUpload和删除补偿仍需独立只读核对及后续授权测试。没有将本地测试、事务回滚或浏览器路由200冒充生产验收、完整备份恢复，或训练/营养/AI/穿戴模块已完工。

生产门禁只能是PENDING：尚缺最新生产只读核查、托管Storage兼容性、生产凭据与worker配置、正式数据库备份、Storage文件备份、完整恢复演练、迁移审批、正式部署和真实用户验收。历史public-only归档/9个TOC/pg_restore --list不是完整数据库恢复证明；Windows私密原件和原始云端管理元数据的缺口不能由本轮补造。

本轮SQL哈希仍为 `56db7fe0b71ebfc2ffa5a6e6d7c57508da500014e8e6b185bc6db0334b96488d`，无新SQL候选或生产迁移。它是独立完整initial，只在本轮空白本地实例应用一次，不与旧initial连续执行；正式目标若已初始化，后续须根据新快照另做前向迁移。

没有生产连接/SQL、db push、dry-run、部署、Secret修改、真实邮件或购买。停止在G5.3；G5.4/G5.5/PHASE2.1 BRAND STUDIO/PHASE3均未启动，后续既定阶段保留。
